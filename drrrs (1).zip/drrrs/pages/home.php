<?php

/**
 * Home Page
 * Displays statistics and recent reports
 */

require_once __DIR__ . '/../includes/models/RoadReport.php';
require_once __DIR__ . '/../includes/models/User.php';
require_once __DIR__ . '/../includes/models/WorkCrew.php';

$roadReport = new RoadReport();
$user = new User();
$workCrew = new WorkCrew();

// Get statistics
$stats = $roadReport->getCountByStatus();
$recent_reports = $roadReport->getRecent(5);
$total_reports = array_sum($stats);
$stats['total'] = $total_reports;

// Start output buffering to capture content
ob_start();
?>

<!-- Hero Section -->
<section class="pt-24 pb-20 bg-gray-50 min-h-screen flex items-center">
    <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid lg:grid-cols-2 gap-12 items-center">
            <!-- Left Content -->
            <div>
                <div class="inline-flex items-center px-4 py-2 bg-green-100 text-green-800 rounded-full text-sm font-medium mb-6">
                    🇧🇩 Serving Bangladesh • All 8 Divisions
                </div>

                <h1 class="text-4xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight">
                    <span class="group" onmouseover="this.querySelector('.bangladesh-text').style.transform='rotate(0deg) translateX(-0.5rem)'" onmouseout="this.querySelector('.bangladesh-text').style.transform='rotate(-3deg)'">
                        <span class="inline-block">Better Roads,</span> <br>
                        <span class="bangladesh-text bg-gradient-to-r from-green-600 to-green-800 bg-clip-text text-transparent transition-transform duration-300" style="transform: rotate(-3deg); display: inline-block; padding: 0.5rem;">
                            Better Bangladesh
                        </span>
                    </span>
                </h1>

                <p class="text-xl text-gray-600 mb-8 leading-relaxed">
                    Report road issues in seconds, track real-time progress, and help build safer infrastructure across Bangladesh.
                </p>

                <!-- Action Buttons -->
                <div class="flex flex-col sm:flex-row gap-4 mb-8">
                    <a href="index.php?page=report/create"
                        class="group flex items-center justify-center px-8 py-4 bg-green-600 text-white font-semibold rounded-2xl shadow-lg hover:shadow-xl hover:bg-green-700 transform hover:-translate-y-0.5 transition-all duration-300">
                        <svg class="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v3m0 0v3m0-3h3m-3 0H9" />
                        </svg>
                        Report Road Issue
                    </a>

                    <a href="index.php?page=report/track"
                        class="group flex items-center justify-center px-8 py-4 bg-white text-gray-700 font-semibold rounded-2xl border-2 border-gray-200 hover:border-gray-300 hover:bg-gray-50 hover:text-gray-900 transform hover:-translate-y-0.5 transition-all duration-300">
                        <svg class="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                        </svg>
                        Track Progress
                    </a>
                </div>

                <!-- Quick Stats -->
                <div class="grid grid-cols-3 gap-6 pt-6 border-t border-gray-200 justify-start">
                    <div class="text-center">
                        <div class="flex items-center justify-center mb-2">
                            <svg class="w-5 h-5 text-green-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                            </svg>
                            <div class="text-2xl font-bold text-green-600"><?php echo $stats['total'] ?? 0; ?>+</div>
                        </div>
                        <div class="text-sm text-gray-600">Reports</div>
                    </div>
                    <div class="text-center">
                        <div class="flex items-center justify-center mb-2">
                            <svg class="w-5 h-5 text-green-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                            </svg>
                            <div class="text-2xl font-bold text-green-600"><?php echo $stats['completed'] ?? 0; ?>+</div>
                        </div>
                        <div class="text-sm text-gray-600">Fixed</div>
                    </div>
                    <div class="text-center">
                        <div class="flex items-center justify-center mb-2">
                            <svg class="w-5 h-5 text-green-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                            </svg>
                            <div class="text-2xl font-bold text-green-600"><?php echo $stats['in_progress'] ?? 0; ?></div>
                        </div>
                        <div class="text-sm text-gray-600">In Progress</div>
                    </div>
                </div>
            </div>

            <!-- Right Visual -->
            <div class="relative">
                <div class="relative">
                    <!-- Background Blur Elements -->
                    <div class="absolute -top-4 -right-4 w-72 h-72 bg-green-400 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
                    <div class="absolute -bottom-8 -left-4 w-72 h-72 bg-green-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse delay-300"></div>

                    <!-- Main Card -->
                    <div class="relative bg-white rounded-3xl shadow-2xl p-8 border border-gray-100">
                        <div class="flex items-start space-x-4 mb-6">
                            <div class="p-3 bg-green-600 rounded-2xl">
                                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                                </svg>
                            </div>
                            <div>
                                <h3 class="font-semibold text-gray-900 text-lg">How It Works</h3>
                                <p class="text-gray-600 text-sm">Simple process for reporting issues</p>
                            </div>
                        </div>

                        <div class="space-y-4">
                            <div class="flex items-center space-x-3">
                                <div class="w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-sm font-bold">1</div>
                                <span class="text-gray-700">Report the road issue with location</span>
                            </div>
                            <div class="flex items-center space-x-3">
                                <div class="w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-sm font-bold">2</div>
                                <span class="text-gray-700">Admin reviews and approves</span>
                            </div>
                            <div class="flex items-center space-x-3">
                                <div class="w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-sm font-bold">3</div>
                                <span class="text-gray-700">Track repair progress in real-time</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
// Get the captured content
$content = ob_get_clean();

// Use centralized layout
require_once __DIR__ . '/../includes/layout.php';
renderPage('DRRRS - Digital Road Repair Request System Bangladesh', $content);
?>