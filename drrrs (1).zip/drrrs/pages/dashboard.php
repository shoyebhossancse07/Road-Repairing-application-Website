<?php

/**
 * Dashboard Page
 * Role-based dashboard for admin and citizen users
 */

requireAuth();

require_once 'includes/auth.php';
require_once 'includes/models/RoadReport.php';
require_once 'includes/models/User.php';
require_once 'includes/models/WorkCrew.php';
require_once 'includes/models/Division.php';

$currentUser = getUserById(getCurrentUserId());
$userRole = getCurrentUserRole();

// Redirect admins to admin dashboard
if ($userRole === 'admin') {
  header('Location: index.php?page=admin/dashboard');
  exit;
}

// Citizen Dashboard Logic
$roadReport = new RoadReport();
$user = new User();
$workCrew = new WorkCrew();
$division = new Division();

$my_reports = $roadReport->getByEmail($currentUser['email']);
$stats = [
  'my_reports' => count($my_reports),
  'pending' => 0,
  'approved' => 0,
  'completed' => 0
];

foreach ($my_reports as $report) {
  switch ($report['status']) {
    case 'pending':
      $stats['pending']++;
      break;
    case 'approved':
      $stats['approved']++;
      break;
    case 'completed':
      $stats['completed']++;
      break;
  }
}

// Start output buffering to capture content
ob_start();
?>

<!-- Hero Section -->
<section class="pt-32 pb-8">
  <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="text-center mb-8">
      <h1 class="text-4xl lg:text-5xl font-bold text-gray-900 mb-6 leading-tight">
        Welcome back,
        <span class="text-green-600"><?php echo htmlspecialchars($currentUser['name']); ?></span>
      </h1>
      <p class="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
        Track your road repair reports and stay updated on their progress.
      </p>
    </div>
  </div>
</section>

<!-- Statistics Cards -->
<section class="pb-8">
  <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <!-- Total Reports -->
      <div class="bg-white rounded-2xl shadow-lg border border-gray-200 p-6 hover:shadow-xl transition-all duration-300">
        <div class="flex items-center">
          <div class="flex-shrink-0">
            <div class="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
              <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
          </div>
          <div class="ml-4">
            <p class="text-sm font-medium text-gray-600">Total Reports</p>
            <p class="text-3xl font-bold text-gray-900"><?php echo $stats['my_reports']; ?></p>
          </div>
        </div>
      </div>

      <!-- Pending Reports -->
      <div class="bg-white rounded-2xl shadow-lg border border-gray-200 p-6 hover:shadow-xl transition-all duration-300">
        <div class="flex items-center">
          <div class="flex-shrink-0">
            <div class="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
              <svg class="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
          </div>
          <div class="ml-4">
            <p class="text-sm font-medium text-gray-600">Pending</p>
            <p class="text-3xl font-bold text-gray-900"><?php echo $stats['pending'] ?? 0; ?></p>
          </div>
        </div>
      </div>

      <!-- Approved Reports -->
      <div class="bg-white rounded-2xl shadow-lg border border-gray-200 p-6 hover:shadow-xl transition-all duration-300">
        <div class="flex items-center">
          <div class="flex-shrink-0">
            <div class="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
              <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
          </div>
          <div class="ml-4">
            <p class="text-sm font-medium text-gray-600">Approved</p>
            <p class="text-3xl font-bold text-gray-900"><?php echo $stats['approved'] ?? 0; ?></p>
          </div>
        </div>
      </div>

      <!-- Completed Reports -->
      <div class="bg-white rounded-2xl shadow-lg border border-gray-200 p-6 hover:shadow-xl transition-all duration-300">
        <div class="flex items-center">
          <div class="flex-shrink-0">
            <div class="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
              <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
              </svg>
            </div>
          </div>
          <div class="ml-4">
            <p class="text-sm font-medium text-gray-600">Completed</p>
            <p class="text-3xl font-bold text-gray-900"><?php echo $stats['completed'] ?? 0; ?></p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- My Reports Section -->
<section class="pb-12">
  <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
      <div class="flex items-center justify-between mb-8">
        <div>
          <h2 class="text-2xl font-bold text-gray-900">My Reports</h2>
          <p class="text-gray-600 mt-1">Track the status of your submitted road repair reports</p>
        </div>
        <a href="index.php?page=report/create" class="inline-flex items-center px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300">
          <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
          </svg>
          New Report
        </a>
      </div>

      <?php if (!empty($my_reports)): ?>
        <div class="space-y-4">
          <?php foreach ($my_reports as $report): ?>
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
              <div class="p-6">
                <div class="flex items-start justify-between">
                  <div class="flex-1">
                    <div class="flex items-center space-x-3 mb-3">
                      <!-- Status Badge -->
                      <?php
                      $statusClass = 'bg-gray-100 text-gray-800';
                      $statusText = ucfirst(str_replace('_', ' ', $report['status']));

                      switch ($report['status']) {
                        case 'pending':
                          $statusClass = 'bg-yellow-100 text-yellow-800';
                          break;
                        case 'approved':
                          $statusClass = 'bg-blue-100 text-blue-800';
                          break;
                        case 'in_progress':
                          $statusClass = 'bg-orange-100 text-orange-800';
                          break;
                        case 'completed':
                          $statusClass = 'bg-green-100 text-green-800';
                          break;
                        case 'rejected':
                          $statusClass = 'bg-red-100 text-red-800';
                          break;
                      }
                      ?>
                      <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium <?php echo $statusClass; ?>">
                        <?php echo $statusText; ?>
                      </span>

                      <!-- Report ID -->
                      <span class="text-sm font-medium text-gray-500">#<?php echo htmlspecialchars($report['report_id']); ?></span>

                      <!-- Priority Badge -->
                      <?php if ($report['priority'] == 'urgent'): ?>
                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-bold bg-red-500 text-white">
                          URGENT
                        </span>
                      <?php elseif ($report['priority'] == 'high'): ?>
                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                          High
                        </span>
                      <?php endif; ?>
                    </div>

                    <h3 class="text-lg font-semibold text-gray-900 mb-2"><?php echo htmlspecialchars($report['title']); ?></h3>
                    <p class="text-gray-600 mb-3"><?php echo htmlspecialchars(substr($report['description'], 0, 120)) . (strlen($report['description']) > 120 ? '...' : ''); ?></p>

                    <div class="flex flex-wrap items-center gap-4 text-sm text-gray-500">
                      <span><?php echo htmlspecialchars($report['division']); ?>, <?php echo htmlspecialchars($report['location']); ?></span>
                      <span>•</span>
                      <span><?php echo date('M d, Y', strtotime($report['created_at'])); ?></span>
                      <?php if ($report['crew_name']): ?>
                        <span>•</span>
                        <span>Crew: <?php echo htmlspecialchars($report['crew_name']); ?></span>
                      <?php endif; ?>
                    </div>

                    <?php if ($report['status'] == 'in_progress' && $report['started_at']): ?>
                      <div class="mt-4 bg-green-50 rounded-xl p-4">
                        <div class="flex items-center">
                          <svg class="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                          </svg>
                          <span class="text-sm font-medium text-green-800">Work started on <?php echo date('M d, Y', strtotime($report['started_at'])); ?></span>
                        </div>
                      </div>
                    <?php elseif ($report['status'] == 'completed' && $report['completed_at']): ?>
                      <div class="mt-4 bg-green-50 rounded-xl p-4">
                        <div class="flex items-center">
                          <svg class="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span class="text-sm font-medium text-green-800">Completed on <?php echo date('M d, Y', strtotime($report['completed_at'])); ?></span>
                          <?php if ($report['actual_cost']): ?>
                            <span class="text-sm text-green-800 ml-2">• Final Cost: ৳<?php echo number_format($report['actual_cost']); ?></span>
                          <?php endif; ?>
                        </div>
                      </div>
                    <?php endif; ?>

                    <?php if ($report['admin_notes']): ?>
                      <div class="mt-4 bg-gray-50 rounded-xl p-4">
                        <p class="text-sm text-gray-700"><strong>Admin Notes:</strong> <?php echo htmlspecialchars($report['admin_notes']); ?></p>
                      </div>
                    <?php endif; ?>
                  </div>

                  <div class="ml-6 text-right space-y-2">
                    <?php if ($report['estimated_cost']): ?>
                      <p class="text-lg font-semibold text-gray-900">৳<?php echo number_format($report['estimated_cost']); ?></p>
                    <?php else: ?>
                      <p class="text-sm text-gray-500">Cost: N/A</p>
                    <?php endif; ?>

                    <a href="index.php?page=report/show&id=<?php echo $report['id']; ?>"
                      class="inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white text-sm font-medium rounded-lg transition-colors">
                      View Details
                    </a>
                  </div>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <!-- No Reports Found -->
        <div class="bg-white rounded-2xl shadow-lg border border-gray-200 p-12 text-center">
          <div class="max-w-md mx-auto">
            <div class="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <h3 class="text-2xl font-bold text-gray-900 mb-4">No Reports Yet</h3>
            <p class="text-gray-600 mb-8 leading-relaxed">You haven't submitted any road repair reports yet. Start by reporting your first issue.</p>

            <a href="index.php?page=report/create" class="inline-flex items-center px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300">
              <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
              </svg>
              Submit Your First Report
            </a>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php
// Get the captured content
$content = ob_get_clean();

// Use centralized layout
require_once 'includes/layout.php';
renderPage('Dashboard - DRRS', $content);
?>