<?php

/**
 * Report Create Page
 * Public page for creating road repair reports
 */

require_once 'includes/auth.php';
require_once 'includes/models/Division.php';

$error = '';
$success = '';

// Check if user is logged in
$isLoggedIn = isLoggedIn();
$currentUser = null;

if ($isLoggedIn) {
  $currentUser = getUserById(getCurrentUserId());
}

// Get divisions for the dropdown
$divisionModel = new Division();
$divisions = $divisionModel->getAll();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_once 'includes/models/RoadReport.php';

  // Validate required fields
  $requiredFields = ['title', 'issue_type', 'description', 'priority', 'division', 'district', 'location'];

  // If not logged in, also require contact fields
  if (!$isLoggedIn) {
    $requiredFields = array_merge($requiredFields, ['reporter_name', 'reporter_email', 'reporter_phone']);
  }

  $errors = [];

  foreach ($requiredFields as $field) {
    if (empty($_POST[$field])) {
      $errors[] = ucfirst(str_replace('_', ' ', $field)) . ' is required.';
    }
  }

  if (empty($errors)) {
    try {
      $reportModel = new RoadReport();

      // Generate unique report ID
      $reportId = $reportModel->generateReportId();

      // Prepare report data
      $reportData = [
        'report_id' => $reportId,
        'title' => $_POST['title'],
        'description' => $_POST['description'],
        'issue_type' => $_POST['issue_type'],
        'priority' => $_POST['priority'],
        'status' => 'pending',
        'division' => $_POST['division'],
        'district' => $_POST['district'],
        'upazila' => $_POST['upazila'] ?? null,
        'location' => $_POST['location'],
        'detailed_location' => $_POST['detailed_location'] ?? null,
        'latitude' => !empty($_POST['latitude']) ? (float)$_POST['latitude'] : null,
        'longitude' => !empty($_POST['longitude']) ? (float)$_POST['longitude'] : null,
        'reporter_name' => $isLoggedIn ? $currentUser['name'] : $_POST['reporter_name'],
        'reporter_email' => $isLoggedIn ? $currentUser['email'] : $_POST['reporter_email'],
        'reporter_phone' => $isLoggedIn ? ($_POST['reporter_phone'] ?? 'N/A') : $_POST['reporter_phone'],
        'estimated_cost' => !empty($_POST['estimated_cost']) ? (float)$_POST['estimated_cost'] : null
      ];

      // Create the report
      $newReportId = $reportModel->create($reportData);

      if ($newReportId) {
        // Handle photo uploads if any
        if (!empty($_FILES['photos']['name'][0])) {
          require_once 'includes/models/ReportPhoto.php';
          $photoModel = new ReportPhoto();

          // Create uploads directory with absolute path
          $uploadDir = __DIR__ . '/../../uploads/reports/';
          if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
          }

          foreach ($_FILES['photos']['tmp_name'] as $key => $tmpName) {
            if ($_FILES['photos']['error'][$key] === UPLOAD_ERR_OK) {
              $fileName = uniqid() . '_' . $_FILES['photos']['name'][$key];
              $filePath = $uploadDir . $fileName;
              $relativePath = 'uploads/reports/' . $fileName;

              if (move_uploaded_file($tmpName, $filePath)) {
                $photoModel->create([
                  'report_id' => $newReportId,
                  'file_path' => $relativePath,
                  'description' => 'Report photo'
                ]);
              }
            }
          }
        }

        $success = 'Report submitted successfully! Your report ID is: ' . $reportId . '. We will review and update you on the progress.';

        // Redirect to the report details page after successful submission
        header('Location: index.php?page=report/show&id=' . $newReportId);
        exit;
      } else {
        $error = 'Failed to submit report. Please try again.';
      }
    } catch (Exception $e) {
      $error = 'An error occurred while submitting the report. Please try again.';
    }
  } else {
    $error = implode(' ', $errors);
  }
}

// Start output buffering
ob_start();
?>

<!-- Hero Section -->
<section class="pt-32">
  <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="text-center mb-12">
      <!-- Badge -->
      <div class="inline-flex items-center px-4 py-2 bg-green-100 text-green-800 rounded-full text-sm font-medium mb-6">
        📢 Help Us Build Better Roads • Report Issues
      </div>

      <!-- Title -->
      <h1 class="text-4xl lg:text-5xl font-bold text-gray-900 mb-6 leading-tight">
        Report a Road
        <span class="text-green-700">Issue</span>
      </h1>

      <!-- Subtitle -->
      <p class="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
        Help us improve Bangladesh's road infrastructure by reporting issues. Your report makes a difference!
      </p>
    </div>
  </div>
</section>

<!-- Messages -->
<div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
  <?php if ($success): ?>
    <div class="mb-8 animate-fade-in-up">
      <div class="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-2xl p-6 shadow-sm">
        <div class="flex items-start">
          <div class="flex-shrink-0">
            <div class="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
              <svg class="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
              </svg>
            </div>
          </div>
          <div class="ml-4">
            <h3 class="text-lg font-semibold text-green-800">Report Submitted Successfully! 🎉</h3>
            <p class="text-green-700 mt-1"><?php echo htmlspecialchars($success); ?></p>
            <p class="text-sm text-green-600 mt-2">We'll review your report and update you on the progress.</p>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <?php if ($error): ?>
    <div class="mb-8 animate-fade-in-up">
      <div class="bg-gradient-to-r from-red-50 to-pink-50 border border-red-200 rounded-2xl p-6 shadow-sm">
        <div class="flex items-start">
          <div class="flex-shrink-0">
            <div class="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center">
              <svg class="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
              </svg>
            </div>
          </div>
          <div class="ml-4">
            <h3 class="text-lg font-semibold text-red-800">Please Fix These Issues</h3>
            <p class="text-red-700 mt-1"><?php echo htmlspecialchars($error); ?></p>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>
</div>

<!-- Multi-Step Form -->
<section class="pb-12">
  <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="bg-white rounded-3xl shadow-2xl overflow-hidden border border-gray-100 animate-fade-in-up">
      <!-- Step Progress Header -->
      <div class="bg-green-700 px-8 py-6">
        <div class="flex items-center justify-between">
          <h2 class="text-2xl font-bold text-white">Report Road Issue</h2>
          <div class="flex items-center space-x-2">
            <span class="text-green-100 text-sm font-medium">Step</span>
            <span id="currentStep" class="text-white text-lg font-bold">1</span>
            <span class="text-green-100 text-sm">of</span>
            <span class="text-white text-lg font-bold">4</span>
          </div>
        </div>

        <!-- Progress Bar -->
        <div class="mt-4">
          <div class="flex space-x-2">
            <div class="step-indicator active" data-step="1">
              <div class="w-8 h-8 rounded-full bg-white text-green-700 flex items-center justify-center text-sm font-bold">1</div>
              <span class="text-xs text-white mt-1">Issue</span>
            </div>
            <div class="flex-1 h-1 bg-green-400 rounded-full mt-4"></div>
            <div class="step-indicator" data-step="2">
              <div class="w-8 h-8 rounded-full bg-green-400 text-white flex items-center justify-center text-sm font-bold">2</div>
              <span class="text-xs text-green-100 mt-1">Location</span>
            </div>
            <div class="flex-1 h-1 bg-green-400 rounded-full mt-4"></div>
            <div class="step-indicator" data-step="3">
              <div class="w-8 h-8 rounded-full bg-green-400 text-white flex items-center justify-center text-sm font-bold">3</div>
              <span class="text-xs text-green-100 mt-1">Contact</span>
            </div>
            <div class="flex-1 h-1 bg-green-400 rounded-full mt-4"></div>
            <div class="step-indicator" data-step="4">
              <div class="w-8 h-8 rounded-full bg-green-400 text-white flex items-center justify-center text-sm font-bold">4</div>
              <span class="text-xs text-green-100 mt-1">Details</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Form Content -->
      <div class="p-8">
        <form method="POST" enctype="multipart/form-data" id="multiStepForm" class="space-y-6">
          <!-- Step 1: Issue Information -->
          <div class="form-step active" id="step1">
            <div class="mb-8">
              <div class="flex items-center space-x-3 mb-4">
                <div class="w-12 h-12 bg-green-700 rounded-xl flex items-center justify-center">
                  <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v3m0 0v3m0-3h3m-3 0H9" />
                  </svg>
                </div>
                <div>
                  <h3 class="text-2xl font-bold text-gray-900">What's the Issue?</h3>
                  <p class="text-gray-600">Tell us about the road problem you've encountered</p>
                </div>
              </div>
            </div>

            <div class="space-y-6">
              <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label for="title" class="block text-sm font-medium text-gray-700 mb-2">Issue Title *</label>
                  <input type="text" id="title" name="title" required
                    class="w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200"
                    placeholder="Brief description of the issue">
                </div>

                <div>
                  <label for="issue_type" class="block text-sm font-medium text-gray-700 mb-2">Issue Type *</label>
                  <select id="issue_type" name="issue_type" required
                    class="w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
                    <option value="">Select Issue Type</option>
                    <option value="pothole">🕳️ Pothole</option>
                    <option value="crack">🔧 Road Crack</option>
                    <option value="debris">🚧 Debris/Obstruction</option>
                    <option value="lighting">💡 Street Lighting</option>
                    <option value="signage">🪧 Road Signage</option>
                    <option value="other">📝 Other</option>
                  </select>
                </div>
              </div>

              <div>
                <label for="description" class="block text-sm font-medium text-gray-700 mb-2">Detailed Description *</label>
                <textarea id="description" name="description" rows="4" required
                  class="w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200"
                  placeholder="Describe the issue in detail... What exactly did you observe? How severe is it?"></textarea>
              </div>

              <div>
                <label class="block text-sm font-medium text-gray-700 mb-3">Priority Level *</label>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <label class="priority-option cursor-pointer">
                    <input type="radio" name="priority" value="low" class="sr-only" required>
                    <div class="border-2 border-gray-200 rounded-xl p-4 hover:border-green-300 hover:bg-green-50 transition-all duration-200">
                      <div class="flex items-center space-x-3">
                        <div class="w-3 h-3 bg-green-500 rounded-full"></div>
                        <div>
                          <div class="font-medium text-gray-900">Low Priority</div>
                          <div class="text-sm text-gray-600">Minor issue, no immediate safety concern</div>
                        </div>
                      </div>
                    </div>
                  </label>

                  <label class="priority-option cursor-pointer">
                    <input type="radio" name="priority" value="medium" class="sr-only" required>
                    <div class="border-2 border-gray-200 rounded-xl p-4 hover:border-green-300 hover:bg-green-50 transition-all duration-200">
                      <div class="flex items-center space-x-3">
                        <div class="w-3 h-3 bg-yellow-500 rounded-full"></div>
                        <div>
                          <div class="font-medium text-gray-900">Medium Priority</div>
                          <div class="text-sm text-gray-600">Moderate concern, should be addressed</div>
                        </div>
                      </div>
                    </div>
                  </label>

                  <label class="priority-option cursor-pointer">
                    <input type="radio" name="priority" value="high" class="sr-only" required>
                    <div class="border-2 border-gray-200 rounded-xl p-4 hover:border-green-300 hover:bg-green-50 transition-all duration-200">
                      <div class="flex items-center space-x-3">
                        <div class="w-3 h-3 bg-orange-500 rounded-full"></div>
                        <div>
                          <div class="font-medium text-gray-900">High Priority</div>
                          <div class="text-sm text-gray-600">Safety concern, needs attention soon</div>
                        </div>
                      </div>
                    </div>
                  </label>

                  <label class="priority-option cursor-pointer">
                    <input type="radio" name="priority" value="urgent" class="sr-only" required>
                    <div class="border-2 border-gray-200 rounded-xl p-4 hover:border-red-300 hover:bg-red-50 transition-all duration-200">
                      <div class="flex items-center space-x-3">
                        <div class="w-3 h-3 bg-red-500 rounded-full"></div>
                        <div>
                          <div class="font-medium text-gray-900">Urgent</div>
                          <div class="text-sm text-gray-600">Immediate danger, emergency response</div>
                        </div>
                      </div>
                    </div>
                  </label>
                </div>
              </div>
            </div>
          </div>

          <!-- Step 2: Location Information -->
          <div class="form-step" id="step2">
            <div class="mb-8">
              <div class="flex items-center space-x-3 mb-4">
                <div class="w-12 h-12 bg-green-700 rounded-xl flex items-center justify-center">
                  <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                </div>
                <div>
                  <h3 class="text-2xl font-bold text-gray-900">Where is the Issue?</h3>
                  <p class="text-gray-600">Help us locate the exact problem area</p>
                </div>
              </div>
            </div>

            <div class="space-y-6">
              <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label for="division" class="block text-sm font-medium text-gray-700 mb-2">Division *</label>
                  <select id="division" name="division" required
                    class="w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
                    <option value="">Select Division</option>
                    <?php foreach ($divisions as $division): ?>
                      <option value="<?php echo htmlspecialchars($division['name']); ?>">
                        <?php echo htmlspecialchars($division['name']); ?> (<?php echo htmlspecialchars($division['name_bn'] ?? ''); ?>)
                      </option>
                    <?php endforeach; ?>
                  </select>
                </div>

                <div>
                  <label for="district" class="block text-sm font-medium text-gray-700 mb-2">District *</label>
                  <input type="text" id="district" name="district" required
                    class="w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200"
                    placeholder="Enter district name">
                </div>

                <div>
                  <label for="upazila" class="block text-sm font-medium text-gray-700 mb-2">Upazila/Thana</label>
                  <input type="text" id="upazila" name="upazila"
                    class="w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200"
                    placeholder="Enter upazila/thana">
                </div>
              </div>

              <div>
                <label for="location" class="block text-sm font-medium text-gray-700 mb-2">Street/Road Name *</label>
                <input type="text" id="location" name="location" required
                  class="w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200"
                  placeholder="Enter street or road name">
              </div>

              <div>
                <label for="detailed_location" class="block text-sm font-medium text-gray-700 mb-2">Detailed Location & Landmarks</label>
                <textarea id="detailed_location" name="detailed_location" rows="3"
                  class="w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200"
                  placeholder="Provide landmarks, nearby buildings, or specific directions... e.g., 'Near Shaheed Minar', 'In front of XYZ School'"></textarea>
              </div>

              <!-- GPS Coordinates -->
              <div class="bg-green-50 border border-green-200 rounded-2xl p-6">
                <div class="flex items-center space-x-3 mb-4">
                  <div class="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                    <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    </svg>
                  </div>
                  <h4 class="font-medium text-green-900">GPS Location (Optional but Helpful)</h4>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label for="latitude" class="block text-sm font-medium text-green-700 mb-2">Latitude</label>
                    <input type="number" step="any" id="latitude" name="latitude"
                      class="w-full px-4 py-3 border border-green-200 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200"
                      placeholder="e.g., 23.8103">
                  </div>

                  <div>
                    <label for="longitude" class="block text-sm font-medium text-green-700 mb-2">Longitude</label>
                    <input type="number" step="any" id="longitude" name="longitude"
                      class="w-full px-4 py-3 border border-green-200 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200"
                      placeholder="e.g., 90.4125">
                  </div>
                </div>

                <button type="button" id="get-location" class="inline-flex items-center px-6 py-3 bg-green-700 hover:bg-green-800 text-white font-medium rounded-xl shadow-sm hover:shadow-md transition-all duration-200">
                  <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                  Get My Current Location
                </button>
              </div>
            </div>
          </div>

          <!-- Step 3: Contact Information -->
          <div class="form-step" id="step3">
            <div class="mb-8">
              <div class="flex items-center space-x-3 mb-4">
                <div class="w-12 h-12 bg-green-700 rounded-xl flex items-center justify-center">
                  <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                  </svg>
                </div>
                <div>
                  <h3 class="text-2xl font-bold text-gray-900">Your Contact Information</h3>
                  <p class="text-gray-600">So we can keep you updated on progress</p>
                </div>
              </div>
            </div>

            <div class="space-y-6">
              <?php if ($isLoggedIn): ?>
                <!-- Logged in user -->
                <div class="bg-green-50 border border-green-200 rounded-2xl p-6">
                  <div class="flex items-center space-x-3 mb-4">
                    <div class="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                      <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                      </svg>
                    </div>
                    <h4 class="font-medium text-green-900">Reporting as <?php echo htmlspecialchars($currentUser['name']); ?></h4>
                  </div>
                  <p class="text-green-700 text-sm">Your contact information will be automatically filled from your profile.</p>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <label for="reporter_name" class="block text-sm font-medium text-gray-700 mb-2">Your Name</label>
                    <input type="text" id="reporter_name" name="reporter_name"
                      value="<?php echo htmlspecialchars($currentUser['name']); ?>"
                      class="w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm bg-gray-50 text-gray-600 cursor-not-allowed"
                      disabled>
                    <!-- Hidden field to ensure value is submitted -->
                    <input type="hidden" name="reporter_name" value="<?php echo htmlspecialchars($currentUser['name']); ?>">
                  </div>

                  <div>
                    <label for="reporter_email" class="block text-sm font-medium text-gray-700 mb-2">Your Email</label>
                    <input type="email" id="reporter_email" name="reporter_email"
                      value="<?php echo htmlspecialchars($currentUser['email']); ?>"
                      class="w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm bg-gray-50 text-gray-600 cursor-not-allowed"
                      disabled>
                    <!-- Hidden field to ensure value is submitted -->
                    <input type="hidden" name="reporter_email" value="<?php echo htmlspecialchars($currentUser['email']); ?>">
                  </div>

                  <div>
                    <label for="reporter_phone" class="block text-sm font-medium text-gray-700 mb-2">Your Phone</label>
                    <input type="tel" id="reporter_phone" name="reporter_phone"
                      value="N/A"
                      class="w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm bg-gray-50 text-gray-600 cursor-not-allowed"
                      disabled>
                    <!-- Hidden field to ensure value is submitted -->
                    <input type="hidden" name="reporter_phone" value="N/A">
                  </div>
                </div>
              <?php else: ?>
                <!-- Guest user -->
                <div class="bg-green-50 border border-green-200 rounded-2xl p-6">
                  <div class="flex items-center space-x-3 mb-4">
                    <div class="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                      <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <h4 class="font-medium text-green-900">Reporting as Guest</h4>
                  </div>
                  <p class="text-green-700 text-sm">No account needed! Just provide your contact information so we can update you on the progress.</p>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <label for="reporter_name" class="block text-sm font-medium text-gray-700 mb-2">Your Name *</label>
                    <input type="text" id="reporter_name" name="reporter_name" required
                      class="w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200"
                      placeholder="Enter your full name">
                  </div>

                  <div>
                    <label for="reporter_email" class="block text-sm font-medium text-gray-700 mb-2">Your Email *</label>
                    <input type="email" id="reporter_email" name="reporter_email" required
                      class="w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200"
                      placeholder="Enter your email address">
                  </div>

                  <div>
                    <label for="reporter_phone" class="block text-sm font-medium text-gray-700 mb-2">Your Phone *</label>
                    <input type="tel" id="reporter_phone" name="reporter_phone" required
                      class="w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200"
                      placeholder="01XXXXXXXXX">
                  </div>
                </div>
              <?php endif; ?>
            </div>
          </div>

          <!-- Step 4: Additional Information -->
          <div class="form-step" id="step4">
            <div class="mb-8">
              <div class="flex items-center space-x-3 mb-4">
                <div class="w-12 h-12 bg-green-700 rounded-xl flex items-center justify-center">
                  <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                </div>
                <div>
                  <h3 class="text-2xl font-bold text-gray-900">Additional Details</h3>
                  <p class="text-gray-600">Optional information that helps us understand better</p>
                </div>
              </div>
            </div>

            <div class="space-y-6">
              <!-- Estimated Cost -->
              <div class="bg-green-50 border border-green-200 rounded-2xl p-6">
                <label for="estimated_cost" class="block text-sm font-medium text-green-800 mb-3">
                  <span class="flex items-center">
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
                    </svg>
                    Estimated Repair Cost (Optional)
                  </span>
                </label>
                <div class="relative">
                  <span class="absolute left-4 top-3 text-green-600 font-medium">৳</span>
                  <input type="number" id="estimated_cost" name="estimated_cost"
                    class="w-full pl-8 pr-4 py-3 border border-green-200 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200"
                    placeholder="Enter estimated cost in Taka">
                </div>
                <p class="text-sm text-green-700 mt-2">If you have experience with similar repairs, your cost estimate helps with budget planning</p>
              </div>

              <!-- Photo Upload -->
              <div class="bg-green-50 border border-green-200 rounded-2xl p-6">
                <label for="photos" class="block text-sm font-medium text-green-800 mb-3">
                  <span class="flex items-center">
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    Upload Photos (Optional)
                  </span>
                </label>
                <div class="border-2 border-dashed border-green-300 rounded-xl p-6 text-center hover:border-green-400 transition-colors">
                  <input type="file" id="photos" name="photos[]" multiple accept="image/*" class="hidden">
                  <label for="photos" class="cursor-pointer">
                    <div class="text-green-500 mb-2">
                      <svg class="w-12 h-12 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                      </svg>
                    </div>
                    <div class="text-green-700 font-medium">Click to upload photos</div>
                    <div class="text-sm text-green-600 mt-1">PNG, JPG up to 5 images</div>
                  </label>
                </div>
                <p class="text-sm text-green-700 mt-3">Photos help our teams understand the severity and scope of the issue. Clear photos speed up the approval process!</p>
              </div>
            </div>
          </div>

          <!-- Step Navigation -->
          <div class="flex items-center justify-between mt-8 pt-6 border-t border-gray-200">
            <button type="button" id="prevBtn" class="inline-flex items-center px-6 py-3 bg-gray-600 hover:bg-gray-700 text-white font-medium rounded-xl transition-all duration-200 shadow-sm hover:shadow-md" style="display: none;">
              <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
              <span>Previous</span>
            </button>

            <div class="flex space-x-4">
              <a href="index.php" class="px-6 py-3 bg-gray-200 hover:bg-gray-300 text-gray-700 font-medium rounded-xl transition-all duration-200">
                Cancel
              </a>

              <button type="button" id="nextBtn" class="inline-flex items-center px-8 py-3 bg-green-700 hover:bg-green-800 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-300">
                <span>Next</span>
                <svg class="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </button>

              <button type="submit" id="submitBtn" class="inline-flex items-center px-8 py-3 bg-green-700 hover:bg-green-800 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-300" style="display: none;">
                <span>Submit Report</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    let currentStep = 1;
    const totalSteps = 4;

    // Form steps
    const formSteps = document.querySelectorAll('.form-step');
    const stepIndicators = document.querySelectorAll('.step-indicator');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const submitBtn = document.getElementById('submitBtn');
    const currentStepSpan = document.getElementById('currentStep');

    // Multi-step form navigation
    function showStep(step) {
      // Hide all steps
      formSteps.forEach(stepEl => {
        stepEl.classList.remove('active');
        stepEl.style.display = 'none';
      });

      // Show current step
      document.getElementById(`step${step}`).style.display = 'block';
      document.getElementById(`step${step}`).classList.add('active');

      // Update step indicators
      stepIndicators.forEach((indicator, index) => {
        const stepNum = index + 1;
        const circle = indicator.querySelector('div');
        const text = indicator.querySelector('span');

        if (stepNum < step) {
          // Completed steps
          circle.className = 'w-8 h-8 rounded-full bg-green-500 text-white flex items-center justify-center text-sm font-bold';
          circle.innerHTML = '✓';
          text.className = 'text-xs text-white mt-1';
        } else if (stepNum === step) {
          // Current step
          circle.className = 'w-8 h-8 rounded-full bg-white text-green-700 flex items-center justify-center text-sm font-bold';
          circle.innerHTML = stepNum;
          text.className = 'text-xs text-white mt-1';
        } else {
          // Future steps
          circle.className = 'w-8 h-8 rounded-full bg-green-400 text-white flex items-center justify-center text-sm font-bold';
          circle.innerHTML = stepNum;
          text.className = 'text-xs text-green-100 mt-1';
        }
      });

      // Update current step display
      currentStepSpan.textContent = step;

      // Show/hide navigation buttons
      prevBtn.style.display = step === 1 ? 'none' : 'inline-flex';
      nextBtn.style.display = step === totalSteps ? 'none' : 'inline-flex';
      submitBtn.style.display = step === totalSteps ? 'inline-flex' : 'none';

      // Focus first input of current step
      const firstInput = document.querySelector(`#step${step} input, #step${step} select, #step${step} textarea`);
      if (firstInput) {
        setTimeout(() => firstInput.focus(), 100);
      }
    }

    // Validate current step
    function validateStep(step) {
      const stepElement = document.getElementById(`step${step}`);
      const requiredInputs = stepElement.querySelectorAll('input[required], select[required], textarea[required]');

      for (let input of requiredInputs) {
        if (!input.value.trim()) {
          input.focus();
          input.classList.add('border-red-500', 'ring-2', 'ring-red-200');
          setTimeout(() => {
            input.classList.remove('border-red-500', 'ring-2', 'ring-red-200');
          }, 3000);
          return false;
        }
      }

      // Special validation for priority radio buttons
      if (step === 1) {
        const prioritySelected = document.querySelector('input[name="priority"]:checked');
        if (!prioritySelected) {
          alert('Please select a priority level for the issue.');
          return false;
        }
      }

      return true;
    }

    // Navigation event listeners
    nextBtn.addEventListener('click', () => {
      if (validateStep(currentStep)) {
        if (currentStep < totalSteps) {
          currentStep++;
          showStep(currentStep);
        }
      }
    });

    prevBtn.addEventListener('click', () => {
      if (currentStep > 1) {
        currentStep--;
        showStep(currentStep);
      }
    });

    // Priority selection enhancement
    const priorityOptions = document.querySelectorAll('.priority-option');
    const priorityInputs = document.querySelectorAll('input[name="priority"]');

    priorityInputs.forEach((input, index) => {
      input.addEventListener('change', function() {
        priorityOptions.forEach(option => {
          const div = option.querySelector('div');
          div.classList.remove('border-green-500', 'bg-green-50', 'border-red-500', 'bg-red-50', 'ring-2', 'ring-green-200', 'ring-red-200');
          div.classList.add('border-gray-200');
        });

        if (this.checked) {
          const div = priorityOptions[index].querySelector('div');
          div.classList.remove('border-gray-200');
          if (this.value === 'urgent') {
            div.classList.add('border-red-500', 'bg-red-50', 'ring-2', 'ring-red-200');
          } else {
            div.classList.add('border-green-500', 'bg-green-50', 'ring-2', 'ring-green-200');
          }
        }
      });
    });

    // Enhanced location services
    document.getElementById('get-location').addEventListener('click', function() {
      const button = this;
      const originalText = button.innerHTML;

      button.innerHTML = '<svg class="w-5 h-5 mr-2 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg>Getting Location...';
      button.disabled = true;

      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(position) {
          document.getElementById('latitude').value = position.coords.latitude.toFixed(6);
          document.getElementById('longitude').value = position.coords.longitude.toFixed(6);

          button.innerHTML = '<svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>Location Updated!';
          button.className = button.className.replace('from-blue-600 to-indigo-600 hover:bg-green-700', 'from-green-600 to-emerald-600 hover:bg-green-700');

          setTimeout(() => {
            button.innerHTML = originalText;
            button.className = button.className.replace('from-green-600 to-emerald-600 hover:bg-green-700', 'from-blue-600 to-indigo-600 hover:bg-green-700');
            button.disabled = false;
          }, 3000);
        }, function(error) {
          let errorMessage = 'Unable to get your location. Please enter coordinates manually.';
          alert(errorMessage);

          button.innerHTML = originalText;
          button.disabled = false;
        });
      } else {
        alert('Geolocation is not supported by this browser.');
        button.innerHTML = originalText;
        button.disabled = false;
      }
    });

    // Form submission
    document.getElementById('multiStepForm').addEventListener('submit', function(e) {
      const submitButton = this.querySelector('button[type="submit"]');
      const originalText = submitButton.innerHTML;

      submitButton.innerHTML = '<svg class="w-5 h-5 mr-2 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg>Submitting Report...';
      submitButton.disabled = true;
    });

    // Auto-resize textareas
    const textareas = document.querySelectorAll('textarea');
    textareas.forEach(textarea => {
      textarea.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = this.scrollHeight + 'px';
      });
    });

    // Photo upload feedback
    const photoInput = document.getElementById('photos');
    photoInput.addEventListener('change', function() {
      const files = this.files;
      const label = this.nextElementSibling;
      if (files.length > 0) {
        label.querySelector('.text-green-700').textContent = `${files.length} file(s) selected`;
      }
    });

    // Initialize first step
    showStep(1);
  });
</script>

<style>
  .form-step {
    display: none;
  }

  .form-step.active {
    display: block;
  }

  .priority-option div {
    transition: all 0.2s ease-in-out;
  }

  .priority-option:hover div {
    transform: translateY(-1px);
  }

  .step-indicator {
    display: flex;
    flex-direction: column;
    align-items: center;
  }

  input:focus,
  select:focus,
  textarea:focus {
    transform: scale(1.01);
  }
</style>

<?php
// Get the captured content
$content = ob_get_clean();

// Use centralized layout
require_once 'includes/layout.php';
renderPage('Report Road Issue - DRRRS', $content);
?>