<?php

/**
 * Track Progress Page
 * Public page for tracking road repair reports
 */

require_once 'includes/auth.php';
require_once 'includes/models/RoadReport.php';
require_once 'includes/models/Division.php';

// Get search parameters
$search = $_GET['search'] ?? '';
$status = $_GET['status'] ?? '';
$division = $_GET['division'] ?? '';
$priority = $_GET['priority'] ?? '';

// Get divisions for filter
$divisionModel = new Division();
$divisions = $divisionModel->getAll();

// Get reports with filters
$reportModel = new RoadReport();
$reports = $reportModel->getPublicReports($search, $status, $division, $priority);

// Start output buffering
ob_start();
?>

<!-- Hero Section -->
<section class="pt-32 pb-8">
  <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="text-center mb-8">
      <h1 class="text-4xl lg:text-5xl font-bold text-gray-900 mb-6 leading-tight">
        Track Your
        <span class="text-green-600">Progress</span>
      </h1>
      <p class="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
        Monitor the status of road repair reports across Bangladesh.
      </p>
    </div>
  </div>
</section>

<!-- Search and Filters -->
<section class="pb-8 mt-8">
  <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
      <h2 class="text-2xl font-bold text-gray-900 mb-6">Search & Filter Reports</h2>

      <form method="GET" action="index.php?page=report/track" class="space-y-6">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label for="search" class="block text-sm font-medium text-gray-700 mb-2">Search</label>
            <input type="text" id="search" name="search" value="<?php echo htmlspecialchars($search); ?>"
              class="w-full px-4 py-3 border border-gray-300 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200"
              placeholder="Report ID, Title, or Location">
          </div>

          <div>
            <label for="status" class="block text-sm font-medium text-gray-700 mb-2">Status</label>
            <select id="status" name="status"
              class="w-full px-4 py-3 border border-gray-300 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
              <option value="">All Statuses</option>
              <option value="pending" <?php echo $status === 'pending' ? 'selected' : ''; ?>>Pending</option>
              <option value="approved" <?php echo $status === 'approved' ? 'selected' : ''; ?>>Approved</option>
              <option value="in_progress" <?php echo $status === 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
              <option value="completed" <?php echo $status === 'completed' ? 'selected' : ''; ?>>Completed</option>
              <option value="rejected" <?php echo $status === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
            </select>
          </div>

          <div>
            <label for="division" class="block text-sm font-medium text-gray-700 mb-2">Division</label>
            <select id="division" name="division"
              class="w-full px-4 py-3 border border-gray-300 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
              <option value="">All Divisions</option>
              <?php foreach ($divisions as $div): ?>
                <option value="<?php echo htmlspecialchars($div['name']); ?>" <?php echo $division === $div['name'] ? 'selected' : ''; ?>>
                  <?php echo htmlspecialchars($div['name']); ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div>
            <label for="priority" class="block text-sm font-medium text-gray-700 mb-2">Priority</label>
            <select id="priority" name="priority"
              class="w-full px-4 py-3 border border-gray-300 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
              <option value="">All Priorities</option>
              <option value="low" <?php echo $priority === 'low' ? 'selected' : ''; ?>>Low</option>
              <option value="medium" <?php echo $priority === 'medium' ? 'selected' : ''; ?>>Medium</option>
              <option value="high" <?php echo $priority === 'high' ? 'selected' : ''; ?>>High</option>
              <option value="urgent" <?php echo $priority === 'urgent' ? 'selected' : ''; ?>>Urgent</option>
            </select>
          </div>
        </div>

        <div class="flex flex-col sm:flex-row items-center justify-between space-y-4 sm:space-y-0">
          <div class="text-sm text-gray-600 bg-gray-50 px-4 py-2 rounded-xl">
            Showing <span class="font-medium text-gray-900"><?php echo count($reports); ?></span> reports
          </div>
          <div class="flex space-x-3">
            <a href="index.php?page=report/track" class="inline-flex items-center px-6 py-3 bg-red-600 hover:bg-red-700 text-white font-medium rounded-xl transition-all duration-200">
              Clear Filters
            </a>
            <button type="submit" class="inline-flex items-center px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300">
              Search Reports
            </button>
          </div>
        </div>
      </form>
    </div>
  </div>
</section>

<!-- Reports List -->
<section class="pb-12 mt-8">
  <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
    <?php if (count($reports) > 0): ?>
      <div class="space-y-4">
        <?php foreach ($reports as $report): ?>
          <div class="bg-white rounded-2xl shadow-lg border border-gray-200 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
            <div class="p-8">
              <div class="flex items-start justify-between">
                <div class="flex-1">
                  <div class="flex items-center space-x-3 mb-4">
                    <!-- Status Badge -->
                    <span class="inline-flex items-center px-4 py-2 rounded-full text-sm font-semibold
                    <?php
                    if ($report['status'] == 'pending') echo 'bg-yellow-100 text-yellow-800';
                    elseif ($report['status'] == 'approved') echo 'bg-blue-100 text-blue-800';
                    elseif ($report['status'] == 'in_progress') echo 'bg-orange-100 text-orange-800';
                    elseif ($report['status'] == 'completed') echo 'bg-green-100 text-green-800';
                    elseif ($report['status'] == 'rejected') echo 'bg-red-100 text-red-800';
                    else echo 'bg-gray-100 text-gray-800';
                    ?>">
                      <?php echo ucfirst(str_replace('_', ' ', $report['status'])); ?>
                    </span>

                    <!-- Report ID -->
                    <span class="text-sm font-semibold text-gray-600 bg-gray-100 px-3 py-1 rounded-lg">#<?php echo htmlspecialchars($report['report_id']); ?></span>

                    <!-- Priority Badge -->
                    <?php if ($report['priority'] == 'urgent'): ?>
                      <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-red-500 text-white shadow-sm">
                        URGENT
                      </span>
                    <?php elseif ($report['priority'] == 'high'): ?>
                      <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-orange-100 text-orange-800">
                        High
                      </span>
                    <?php endif; ?>
                  </div>

                  <h3 class="text-xl font-bold text-gray-900 mb-3"><?php echo htmlspecialchars($report['title']); ?></h3>
                  <p class="text-gray-600 mb-4 text-base leading-relaxed"><?php echo htmlspecialchars(substr($report['description'], 0, 120)) . (strlen($report['description']) > 120 ? '...' : ''); ?></p>

                  <div class="flex flex-wrap items-center gap-4 text-sm text-gray-500 bg-gray-50 px-4 py-3 rounded-xl">
                    <div class="flex items-center space-x-1">
                      <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                      </svg>
                      <span><?php echo htmlspecialchars($report['division']); ?>, <?php echo htmlspecialchars($report['district']); ?></span>
                    </div>
                    <span class="text-gray-300">•</span>
                    <div class="flex items-center space-x-1">
                      <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3a1 1 0 011-1h6a1 1 0 011 1v4h3a1 1 0 011 1v9a2 2 0 01-2 2H5a2 2 0 01-2-2V8a1 1 0 011-1h3z" />
                      </svg>
                      <span><?php echo date('M d, Y', strtotime($report['created_at'])); ?></span>
                    </div>
                    <?php if (!empty($report['crew_name'])): ?>
                      <span class="text-gray-300">•</span>
                      <div class="flex items-center space-x-1">
                        <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                        </svg>
                        <span>Crew: <?php echo htmlspecialchars($report['crew_name']); ?></span>
                      </div>
                    <?php endif; ?>
                  </div>
                </div>

                <div class="ml-8 text-center space-y-3">
                  <?php if (!empty($report['estimated_cost'])): ?>
                    <div class="bg-green-50 border border-green-200 rounded-xl p-4">
                      <p class="text-2xl font-bold text-green-700">৳<?php echo number_format($report['estimated_cost']); ?></p>
                      <p class="text-xs text-green-600">Estimated Cost</p>
                    </div>
                  <?php else: ?>
                    <div class="bg-gray-50 border border-gray-200 rounded-xl p-4">
                      <p class="text-sm text-gray-500">Cost: N/A</p>
                    </div>
                  <?php endif; ?>

                  <a href="index.php?page=report/show&id=<?php echo $report['id']; ?>"
                    class="inline-flex items-center px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-0.5">
                    <span>View Details</span>
                    <svg class="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                    </svg>
                  </a>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <!-- No Reports Found -->
      <div class="bg-white rounded-2xl shadow-lg border border-gray-200 p-12 text-center">
        <div class="max-w-md mx-auto">
          <div class="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
          </div>
          <h3 class="text-2xl font-bold text-gray-900 mb-4">No Reports Found</h3>
          <p class="text-gray-600 mb-8 leading-relaxed">No road repair reports match your search criteria. Try adjusting your filters or search terms.</p>

          <div class="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="index.php?page=report/track" class="inline-flex items-center px-6 py-3 bg-red-600 hover:bg-red-700 text-white font-medium rounded-xl transition-colors">
              Clear All Filters
            </a>
            <a href="index.php?page=report/create" class="inline-flex items-center px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300">
              Report New Issue
            </a>
          </div>
        </div>
      </div>
    <?php endif; ?>
  </div>
</section>

<?php
// Get the captured content
$content = ob_get_clean();

// Use centralized layout
require_once 'includes/layout.php';
renderPage('Track Progress - DRRRS', $content);
?>