<?php

/**
 * Report Show Page
 * Public page for viewing road repair report details
 */

require_once 'includes/auth.php';
require_once 'includes/models/RoadReport.php';

$error = '';
$report = null;

// Get report ID from URL parameter
$reportId = $_GET['id'] ?? null;

if (!$reportId) {
    $error = 'Report ID is required.';
} else {
    $reportModel = new RoadReport();
    $report = $reportModel->getById($reportId);
    
    if (!$report) {
        $error = 'Report not found.';
    }
}

// Start output buffering
ob_start();
?>

<?php if ($error): ?>
<!-- Error Message -->
<section class="pt-32">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="bg-red-50 border border-red-200 rounded-2xl p-8 text-center">
            <div class="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
                </svg>
            </div>
            <h2 class="text-2xl font-bold text-red-800 mb-2">Report Not Found</h2>
            <p class="text-red-700 mb-6"><?php echo htmlspecialchars($error); ?></p>
            <a href="index.php?page=report/track" class="inline-flex items-center px-6 py-3 bg-red-600 hover:bg-red-700 text-white font-medium rounded-xl transition-colors">
                ← Back to Track Progress
            </a>
        </div>
    </div>
</section>
<?php else: ?>

<!-- Navigation Breadcrumb -->
<section class="pt-24 pb-6">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <nav class="flex items-center space-x-2 text-sm text-gray-500 mb-6">
            <a href="index.php" class="hover:text-gray-700">Home</a>
            <span>•</span>
            <a href="index.php?page=report/track" class="hover:text-gray-700">Track Progress</a>
            <span>•</span>
            <span class="text-gray-900 font-medium">Report #<?php echo htmlspecialchars($report['report_id']); ?></span>
        </nav>
    </div>
</section>

<!-- Report Details -->
<section class="pb-12">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden">
            <!-- Header -->
            <div class="bg-gray-50 px-8 py-6 border-b border-gray-200">
                <div class="flex flex-col lg:flex-row lg:items-center justify-between space-y-4 lg:space-y-0">
                    <div>
                        <div class="flex items-center space-x-3 mb-2">
                            <!-- Status Badge -->
                            <?php
                            $statusClass = 'bg-gray-100 text-gray-800';
                            $statusText = ucfirst(str_replace('_', ' ', $report['status']));
                            
                            switch ($report['status']) {
                                case 'pending':
                                    $statusClass = 'bg-yellow-100 text-yellow-800';
                                    break;
                                case 'approved':
                                    $statusClass = 'bg-blue-100 text-blue-800';
                                    break;
                                case 'in_progress':
                                    $statusClass = 'bg-orange-100 text-orange-800';
                                    break;
                                case 'completed':
                                    $statusClass = 'bg-green-100 text-green-800';
                                    break;
                                case 'rejected':
                                    $statusClass = 'bg-red-100 text-red-800';
                                    break;
                            }
                            ?>
                            <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium <?php echo $statusClass; ?>">
                                <?php echo $statusText; ?>
                            </span>

                            <!-- Priority Badge -->
                            <?php if ($report['priority'] == 'urgent'): ?>
                                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-500 text-white">
                                    URGENT
                                </span>
                            <?php elseif ($report['priority'] == 'high'): ?>
                                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                                    High Priority
                                </span>
                            <?php endif; ?>
                        </div>
                        <h1 class="text-2xl font-bold text-gray-900"><?php echo htmlspecialchars($report['title']); ?></h1>
                        <p class="text-gray-600">Report #<?php echo htmlspecialchars($report['report_id']); ?></p>
                    </div>
                    <div class="text-right">
                        <?php if ($report['estimated_cost']): ?>
                            <p class="text-2xl font-bold text-gray-900">৳<?php echo number_format($report['estimated_cost']); ?></p>
                            <p class="text-sm text-gray-500">Estimated Cost</p>
                        <?php else: ?>
                            <p class="text-lg text-gray-500">Cost: N/A</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Content -->
            <div class="p-8 space-y-8">
                <!-- Description -->
                <div>
                    <h2 class="text-lg font-semibold text-gray-900 mb-3">Issue Description</h2>
                    <p class="text-gray-700 leading-relaxed"><?php echo htmlspecialchars($report['description']); ?></p>
                </div>

                <!-- Details Grid -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- Location -->
                    <div class="bg-gray-50 rounded-xl p-6">
                        <h3 class="font-medium text-gray-900 mb-4">Location Details</h3>
                        <div class="space-y-2 text-sm">
                            <p><span class="font-medium">Division:</span> <?php echo htmlspecialchars($report['division']); ?></p>
                            <p><span class="font-medium">District:</span> <?php echo htmlspecialchars($report['district']); ?></p>
                            <?php if ($report['upazila']): ?>
                                <p><span class="font-medium">Upazila:</span> <?php echo htmlspecialchars($report['upazila']); ?></p>
                            <?php endif; ?>
                            <p><span class="font-medium">Road/Street:</span> <?php echo htmlspecialchars($report['location']); ?></p>
                            <?php if ($report['detailed_location']): ?>
                                <div class="mt-3">
                                    <span class="font-medium">Detailed Location:</span>
                                    <p class="text-gray-600 mt-1"><?php echo htmlspecialchars($report['detailed_location']); ?></p>
                                </div>
                            <?php endif; ?>
                            <?php if ($report['latitude'] && $report['longitude']): ?>
                                <div class="mt-3">
                                    <span class="font-medium">GPS Coordinates:</span>
                                    <p class="text-gray-600"><?php echo htmlspecialchars($report['latitude']); ?>, <?php echo htmlspecialchars($report['longitude']); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Issue Info -->
                    <div class="bg-gray-50 rounded-xl p-6">
                        <h3 class="font-medium text-gray-900 mb-4">Issue Information</h3>
                        <div class="space-y-2 text-sm">
                            <p><span class="font-medium">Type:</span> <?php echo ucfirst(str_replace('_', ' ', $report['issue_type'])); ?></p>
                            <p><span class="font-medium">Priority:</span> <?php echo ucfirst($report['priority']); ?></p>
                            <p><span class="font-medium">Reported:</span> <?php echo date('M d, Y \a\t g:i A', strtotime($report['created_at'])); ?></p>
                            <?php if ($report['crew_name']): ?>
                                <p><span class="font-medium">Assigned Crew:</span> <?php echo htmlspecialchars($report['crew_name']); ?></p>
                            <?php else: ?>
                                <p><span class="font-medium">Assigned Crew:</span> Not assigned</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Contact Information -->
                <div class="bg-gray-50 rounded-xl p-6">
                    <h3 class="font-medium text-gray-900 mb-4">Reporter Information</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                        <p><span class="font-medium">Name:</span> <?php echo htmlspecialchars($report['reporter_name']); ?></p>
                        <p><span class="font-medium">Email:</span> <?php echo htmlspecialchars($report['reporter_email']); ?></p>
                        <p><span class="font-medium">Phone:</span> <?php echo htmlspecialchars($report['reporter_phone']); ?></p>
                    </div>
                </div>

                <!-- Progress Timeline -->
                <?php if ($report['status'] != 'pending'): ?>
                <div>
                    <h2 class="text-lg font-semibold text-gray-900 mb-6">Progress Timeline</h2>
                    <div class="space-y-4">
                        <!-- Submitted -->
                        <div class="flex items-start space-x-4">
                            <div class="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0">
                                <svg class="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd" />
                                </svg>
                            </div>
                            <div class="bg-white border border-gray-200 rounded-lg p-4 flex-1">
                                <h4 class="font-medium text-gray-900">Report Submitted</h4>
                                <p class="text-sm text-gray-600"><?php echo date('M d, Y \a\t g:i A', strtotime($report['created_at'])); ?></p>
                                <p class="text-xs text-green-600 mt-1">✓ Completed</p>
                            </div>
                        </div>

                        <!-- Approved -->
                        <div class="flex items-start space-x-4">
                            <div class="w-8 h-8 <?php echo $report['approved_at'] ? 'bg-green-500' : 'bg-gray-300'; ?> rounded-full flex items-center justify-center flex-shrink-0">
                                <?php if ($report['approved_at']): ?>
                                <svg class="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd" />
                                </svg>
                                <?php else: ?>
                                <div class="w-2 h-2 bg-gray-500 rounded-full"></div>
                                <?php endif; ?>
                            </div>
                            <div class="bg-white border border-gray-200 rounded-lg p-4 flex-1">
                                <h4 class="font-medium text-gray-900">Admin Review & Approval</h4>
                                <?php if ($report['approved_at']): ?>
                                <p class="text-sm text-gray-600"><?php echo date('M d, Y \a\t g:i A', strtotime($report['approved_at'])); ?></p>
                                <p class="text-xs text-green-600 mt-1">✓ Approved</p>
                                <?php else: ?>
                                <p class="text-sm text-gray-500">Awaiting admin review</p>
                                <p class="text-xs text-yellow-600 mt-1">⏳ In Progress</p>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Work Started -->
                        <div class="flex items-start space-x-4">
                            <div class="w-8 h-8 <?php echo $report['started_at'] ? 'bg-green-500' : 'bg-gray-300'; ?> rounded-full flex items-center justify-center flex-shrink-0">
                                <?php if ($report['started_at']): ?>
                                <svg class="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd" />
                                </svg>
                                <?php else: ?>
                                <div class="w-2 h-2 bg-gray-500 rounded-full"></div>
                                <?php endif; ?>
                            </div>
                            <div class="bg-white border border-gray-200 rounded-lg p-4 flex-1">
                                <h4 class="font-medium text-gray-900">Work Started</h4>
                                <?php if ($report['started_at']): ?>
                                <p class="text-sm text-gray-600"><?php echo date('M d, Y \a\t g:i A', strtotime($report['started_at'])); ?></p>
                                <p class="text-xs text-green-600 mt-1">✓ Work in Progress</p>
                                <?php else: ?>
                                <p class="text-sm text-gray-500">Work not yet started</p>
                                <p class="text-xs text-gray-500 mt-1">⏳ Awaiting Work Start</p>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Completed -->
                        <div class="flex items-start space-x-4">
                            <div class="w-8 h-8 <?php echo $report['completed_at'] ? 'bg-green-500' : 'bg-gray-300'; ?> rounded-full flex items-center justify-center flex-shrink-0">
                                <?php if ($report['completed_at']): ?>
                                <svg class="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd" />
                                </svg>
                                <?php else: ?>
                                <div class="w-2 h-2 bg-gray-500 rounded-full"></div>
                                <?php endif; ?>
                            </div>
                            <div class="bg-white border border-gray-200 rounded-lg p-4 flex-1">
                                <h4 class="font-medium text-gray-900">Work Completed</h4>
                                <?php if ($report['completed_at']): ?>
                                <p class="text-sm text-gray-600"><?php echo date('M d, Y \a\t g:i A', strtotime($report['completed_at'])); ?></p>
                                <p class="text-xs text-green-600 mt-1">✓ All Done!</p>
                                <?php else: ?>
                                <p class="text-sm text-gray-500">Work not yet completed</p>
                                <p class="text-xs text-gray-500 mt-1">⏳ In Progress</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <div class="bg-yellow-50 border border-yellow-200 rounded-xl p-6">
                    <div class="flex items-center space-x-3">
                        <div class="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
                            <div class="w-2 h-2 bg-white rounded-full"></div>
                        </div>
                        <div>
                            <h4 class="font-medium text-yellow-800">Pending Review</h4>
                            <p class="text-yellow-700">Your report is waiting for admin review. This usually takes 24-48 hours.</p>
                            <p class="text-sm text-yellow-600 mt-1">Submitted <?php echo date('M d, Y \a\t g:i A', strtotime($report['created_at'])); ?></p>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Admin Notes -->
                <?php if ($report['admin_notes']): ?>
                <div>
                    <h2 class="text-lg font-semibold text-gray-900 mb-3">Admin Notes</h2>
                    <div class="bg-blue-50 border border-blue-200 rounded-xl p-6">
                        <p class="text-blue-900"><?php echo htmlspecialchars($report['admin_notes']); ?></p>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Action Buttons -->
                <div class="flex justify-between items-center pt-6 border-t border-gray-200">
                    <a href="index.php?page=report/track" class="inline-flex items-center px-6 py-3 bg-gray-600 hover:bg-gray-700 text-white font-medium rounded-xl transition-colors">
                        ← Back to Track Progress
                    </a>

                    <?php if ($report['status'] == 'pending'): ?>
                    <div class="text-sm text-gray-500">
                        Report is under review
                    </div>
                    <?php elseif ($report['status'] == 'completed'): ?>
                    <div class="text-sm text-green-600 font-medium">
                        ✓ Issue resolved
                    </div>
                    <?php else: ?>
                    <div class="text-sm text-orange-600 font-medium">
                        Work in progress
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<?php endif; ?>

<?php
// Get the captured content
$content = ob_get_clean();

// Use centralized layout
require_once 'includes/layout.php';
renderPage('Report #' . ($report ? $report['report_id'] : 'Not Found') . ' - DRRRS', $content);
?>
