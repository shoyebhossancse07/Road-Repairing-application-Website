<?php

/**
 * 404 Error Page
 * Displays when a page is not found
 */

require_once 'includes/auth.php';

// Start output buffering to capture content
ob_start();
?>

<div class="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
    <div class="sm:mx-auto sm:w-full sm:max-w-md">
        <div class="text-center">
            <h1 class="text-9xl font-bold text-gray-300">404</h1>
            <h2 class="mt-6 text-3xl font-bold text-gray-900">Page Not Found</h2>
            <p class="mt-2 text-sm text-gray-600">
                The page you're looking for doesn't exist.
            </p>
        </div>
    </div>

    <div class="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div class="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
            <div class="text-center">
                <div class="mb-6">
                    <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 12h6m-6-4h6m2 5.291A7.962 7.962 0 0112 15c-2.34 0-4.47-.881-6.08-2.33" />
                    </svg>
                </div>
                
                <p class="text-gray-600 mb-6">
                    The page you requested could not be found. It might have been moved, deleted, or you entered the wrong URL.
                </p>
                
                <div class="space-y-3">
                    <a href="index.php" class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                        Go to Homepage
                    </a>
                    
                    <a href="javascript:history.back()" class="w-full flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                        Go Back
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Get the captured content
$content = ob_get_clean();

// Use centralized layout
require_once 'includes/layout.php';
renderPage('Page Not Found - DRRRS', $content);
?>
