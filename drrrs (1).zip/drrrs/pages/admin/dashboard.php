<?php

/**
 * Admin Dashboard Page
 * Displays admin statistics and management interface
 */

require_once 'includes/auth.php';
require_once 'includes/models/RoadReport.php';
require_once 'includes/models/WorkCrew.php';
require_once 'includes/models/User.php';
require_once 'includes/models/Division.php';

// Check if user is admin
if (!isAdmin()) {
  header('Location: index.php?page=dashboard&error=access_denied');
  exit;
}

// Get statistics
$roadReport = new RoadReport();
$stats = [
  'total_reports' => $roadReport->getTotalCount(),
  'pending_reviews' => $roadReport->getCountByStatusSingle('pending'),
  'in_progress' => $roadReport->getCountByStatusSingle('in_progress'),
  'completed' => $roadReport->getCountByStatusSingle('completed'),
];

// Get comprehensive data for charts
$allStatusCounts = $roadReport->getAllStatusCounts();
$divisionStats = $roadReport->getCountByDivision();
$monthlyTrends = $roadReport->getMonthlyTrends();
$priorityDistribution = $roadReport->getPriorityDistribution();

// Get recent reports
$recentReports = $roadReport->getRecentReports(5);

// Start output buffering to capture content
ob_start();
?>

<!-- Hero Section -->
<section class="pt-32 pb-8">
  <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="text-center mb-8">
      <h1 class="text-4xl lg:text-5xl font-bold text-gray-900 mb-6 leading-tight">
        Admin
        <span class="text-green-600">Dashboard</span>
      </h1>
      <p class="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
        Welcome back, <?php echo htmlspecialchars($_SESSION['user_name']); ?>! Monitor and manage road repairs across Bangladesh.
      </p>
    </div>
  </div>
</section>

<!-- Statistics Cards -->
<section class="pb-8">
  <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <!-- Total Reports -->
      <div class="bg-white rounded-2xl shadow-lg border border-gray-200 p-6 hover:shadow-xl transition-all duration-300">
        <div class="flex items-center">
          <div class="flex-shrink-0">
            <div class="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
              <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
          </div>
          <div class="ml-4">
            <p class="text-sm font-medium text-gray-600">Total Reports</p>
            <p class="text-3xl font-bold text-gray-900"><?php echo $stats['total_reports']; ?></p>
          </div>
        </div>
      </div>

      <!-- Pending Reviews -->
      <div class="bg-white rounded-2xl shadow-lg border border-gray-200 p-6 hover:shadow-xl transition-all duration-300">
        <div class="flex items-center">
          <div class="flex-shrink-0">
            <div class="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
              <svg class="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
          </div>
          <div class="ml-4">
            <p class="text-sm font-medium text-gray-600">Pending Review</p>
            <p class="text-3xl font-bold text-gray-900"><?php echo $stats['pending_reviews']; ?></p>
          </div>
        </div>
      </div>

      <!-- In Progress -->
      <div class="bg-white rounded-2xl shadow-lg border border-gray-200 p-6 hover:shadow-xl transition-all duration-300">
        <div class="flex items-center">
          <div class="flex-shrink-0">
            <div class="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
              <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
          </div>
          <div class="ml-4">
            <p class="text-sm font-medium text-gray-600">In Progress</p>
            <p class="text-3xl font-bold text-gray-900"><?php echo $stats['in_progress']; ?></p>
          </div>
        </div>
      </div>

      <!-- Completed -->
      <div class="bg-white rounded-2xl shadow-lg border border-gray-200 p-6 hover:shadow-xl transition-all duration-300">
        <div class="flex items-center">
          <div class="flex-shrink-0">
            <div class="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
              <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
              </svg>
            </div>
          </div>
          <div class="ml-4">
            <p class="text-sm font-medium text-gray-600">Completed</p>
            <p class="text-3xl font-bold text-gray-900"><?php echo $stats['completed']; ?></p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Analytics Charts -->
<section class="pb-12">
  <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <!-- Reports by Status Chart -->
      <div class="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
        <h3 class="text-xl font-bold text-gray-900 mb-6">Reports by Status</h3>
        <div class="relative h-80">
          <canvas id="statusChart"
            data-status-counts='<?php echo json_encode($allStatusCounts); ?>'></canvas>
        </div>
      </div>

      <!-- Reports by Division Chart -->
      <div class="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
        <h3 class="text-xl font-bold text-gray-900 mb-6">Reports by Division</h3>
        <div class="relative h-80">
          <canvas id="divisionChart"
            data-divisions='<?php echo json_encode(array_keys($divisionStats)); ?>'
            data-counts='<?php echo json_encode(array_values($divisionStats)); ?>'></canvas>
        </div>
      </div>

      <!-- Priority Distribution Chart -->
      <div class="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
        <h3 class="text-xl font-bold text-gray-900 mb-6">Reports by Priority</h3>
        <div class="relative h-80">
          <canvas id="priorityChart"
            data-priority-data='<?php echo json_encode($priorityDistribution); ?>'></canvas>
        </div>
      </div>

      <!-- Monthly Trend Chart -->
      <div class="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
        <h3 class="text-xl font-bold text-gray-900 mb-6">Monthly Report Trends (<?php echo date('Y'); ?>)</h3>
        <div class="relative h-80">
          <canvas id="trendChart"
            data-monthly-trends='<?php echo json_encode($monthlyTrends); ?>'
            data-current-year="<?php echo date('Y'); ?>"></canvas>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Recent Reports -->
<section class="pb-12">
  <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
      <div class="flex items-center justify-between mb-6">
        <h3 class="text-xl font-bold text-gray-900">Recent Reports</h3>
        <a href="index.php?page=admin/reports" class="text-green-600 hover:text-green-700 font-medium">
          View All Reports →
        </a>
      </div>

      <?php if (!empty($recentReports)): ?>
        <div class="overflow-x-auto">
          <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
              <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Report ID</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Title</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Location</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
              <?php foreach ($recentReports as $report): ?>
                <tr class="hover:bg-gray-50">
                  <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    #<?php echo htmlspecialchars($report['id']); ?>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    <?php echo htmlspecialchars($report['title']); ?>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <?php echo htmlspecialchars($report['location']); ?>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full 
                      <?php
                      switch ($report['status']) {
                        case 'pending':
                          echo 'bg-yellow-100 text-yellow-800';
                          break;
                        case 'in_progress':
                          echo 'bg-blue-100 text-blue-800';
                          break;
                        case 'completed':
                          echo 'bg-green-100 text-green-800';
                          break;
                        default:
                          echo 'bg-gray-100 text-gray-800';
                      }
                      ?>">
                      <?php echo ucfirst(str_replace('_', ' ', $report['status'])); ?>
                    </span>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <?php echo date('M d, Y', strtotime($report['created_at'])); ?>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <a href="index.php?page=report/show&id=<?php echo $report['id']; ?>" class="text-green-600 hover:text-green-900">View</a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <div class="text-center py-8">
          <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
          <h3 class="mt-2 text-sm font-medium text-gray-900">No reports</h3>
          <p class="mt-1 text-sm text-gray-500">No reports have been submitted yet.</p>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>

<!-- Quick Actions -->
<section class="pb-12">
  <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
      <h3 class="text-xl font-bold text-gray-900 mb-6">Quick Actions</h3>
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <a href="index.php?page=admin/reports" class="group relative bg-white p-6 focus-within:ring-2 focus-within:ring-inset focus-within:ring-green-500 rounded-lg border border-gray-200 hover:shadow-lg transition-all duration-200">
          <div>
            <span class="rounded-lg inline-flex p-3 bg-green-50 text-green-700 ring-4 ring-white">
              <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </span>
          </div>
          <div class="mt-8">
            <h3 class="text-lg font-medium">
              <span class="absolute inset-0" aria-hidden="true"></span>
              Manage Reports
            </h3>
            <p class="mt-2 text-sm text-gray-500">
              View, filter, and manage all road repair reports.
            </p>
          </div>
          <span class="pointer-events-none absolute top-6 right-6 text-gray-300 group-hover:text-gray-400" aria-hidden="true">
            <svg class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
              <path d="M20 4h1a1 1 0 00-1-1v1zm-1 12a1 1 0 102 0h-2zM8 3a1 1 0 000 2V3zM3.293 19.293a1 1 0 101.414 1.414l-1.414-1.414zM19 4v12h2V4h-2zm1-1H8v2h12V3zm-.707.293l-16 16 1.414 1.414 16-16-1.414-1.414z" />
            </svg>
          </span>
        </a>

        <a href="index.php?page=admin/crews" class="group relative bg-white p-6 focus-within:ring-2 focus-within:ring-inset focus-within:ring-green-500 rounded-lg border border-gray-200 hover:shadow-lg transition-all duration-200">
          <div>
            <span class="rounded-lg inline-flex p-3 bg-blue-50 text-blue-700 ring-4 ring-white">
              <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
            </span>
          </div>
          <div class="mt-8">
            <h3 class="text-lg font-medium">
              <span class="absolute inset-0" aria-hidden="true"></span>
              Manage Crews
            </h3>
            <p class="mt-2 text-sm text-gray-500">
              Create and manage work crews for road repairs.
            </p>
          </div>
          <span class="pointer-events-none absolute top-6 right-6 text-gray-300 group-hover:text-gray-400" aria-hidden="true">
            <svg class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
              <path d="M20 4h1a1 1 0 00-1-1v1zm-1 12a1 1 0 102 0h-2zM8 3a1 1 0 000 2V3zM3.293 19.293a1 1 0 101.414 1.414l-1.414-1.414zM19 4v12h2V4h-2zm1-1H8v2h12V3zm-.707.293l-16 16 1.414 1.414 16-16-1.414-1.414z" />
            </svg>
          </span>
        </a>

        <a href="index.php?page=admin/users" class="group relative bg-white p-6 focus-within:ring-2 focus-within:ring-inset focus-within:ring-green-500 rounded-lg border border-gray-200 hover:shadow-lg transition-all duration-200">
          <div>
            <span class="rounded-lg inline-flex p-3 bg-purple-50 text-purple-700 ring-4 ring-white">
              <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z" />
              </svg>
            </span>
          </div>
          <div class="mt-8">
            <h3 class="text-lg font-medium">
              <span class="absolute inset-0" aria-hidden="true"></span>
              Manage Users
            </h3>
            <p class="mt-2 text-sm text-gray-500">
              Manage user accounts and permissions.
            </p>
          </div>
          <span class="pointer-events-none absolute top-6 right-6 text-gray-300 group-hover:text-gray-400" aria-hidden="true">
            <svg class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
              <path d="M20 4h1a1 1 0 00-1-1v1zm-1 12a1 1 0 102 0h-2zM8 3a1 1 0 000 2V3zM3.293 19.293a1 1 0 101.414 1.414l-1.414-1.414zM19 4v12h2V4h-2zm1-1H8v2h12V3zm-.707.293l-16 16 1.414 1.414 16-16-1.414-1.414z" />
            </svg>
          </span>
        </a>
      </div>
    </div>
  </div>
</section>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    // Color palettes for charts
    const statusColors = {
      'pending': '#FCD34D',
      'approved': '#60A5FA',
      'in_progress': '#3B82F6',
      'completed': '#10B981',
      'rejected': '#EF4444'
    };

    const divisionColors = [
      '#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6',
      '#06B6D4', '#F97316', '#84CC16', '#EC4899', '#6366F1'
    ];

    const priorityColors = {
      'low': '#10B981',
      'medium': '#F59E0B',
      'high': '#EF4444',
      'urgent': '#DC2626'
    };

    // Status Chart - Dynamic data
    const statusCtx = document.getElementById('statusChart').getContext('2d');
    const statusCounts = JSON.parse(document.getElementById('statusChart').dataset.statusCounts);

    // Filter out statuses with 0 count for better visualization
    const activeStatuses = Object.entries(statusCounts).filter(([status, count]) => count > 0);
    const statusLabels = activeStatuses.map(([status, count]) =>
      status.charAt(0).toUpperCase() + status.slice(1).replace('_', ' ')
    );
    const statusData = activeStatuses.map(([status, count]) => count);
    const statusBackgroundColors = activeStatuses.map(([status, count]) => statusColors[status] || '#9CA3AF');

    new Chart(statusCtx, {
      type: 'doughnut',
      data: {
        labels: statusLabels,
        datasets: [{
          data: statusData,
          backgroundColor: statusBackgroundColors,
          borderWidth: 2,
          borderColor: '#ffffff'
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              padding: 20,
              usePointStyle: true
            }
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                const total = statusData.reduce((a, b) => a + b, 0);
                const percentage = Math.round((context.parsed / total) * 100);
                return `${context.label}: ${context.parsed} (${percentage}%)`;
              }
            }
          }
        }
      }
    });

    // Division Chart - Dynamic data with dynamic colors
    const divisionCtx = document.getElementById('divisionChart').getContext('2d');
    const divisions = JSON.parse(document.getElementById('divisionChart').dataset.divisions);
    const divisionCounts = JSON.parse(document.getElementById('divisionChart').dataset.counts);

    // Generate colors for all divisions
    const divisionBackgroundColors = divisions.map((_, index) =>
      divisionColors[index % divisionColors.length]
    );

    new Chart(divisionCtx, {
      type: 'bar',
      data: {
        labels: divisions,
        datasets: [{
          label: 'Reports',
          data: divisionCounts,
          backgroundColor: divisionBackgroundColors,
          borderColor: divisionBackgroundColors,
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                return `${context.label}: ${context.parsed.y} reports`;
              }
            }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              stepSize: 1
            }
          },
          x: {
            ticks: {
              maxRotation: 45
            }
          }
        }
      }
    });

    // Priority Chart - Dynamic data
    const priorityCtx = document.getElementById('priorityChart').getContext('2d');
    const priorityData = JSON.parse(document.getElementById('priorityChart').dataset.priorityData);

    const priorityLabels = Object.keys(priorityData).map(priority =>
      priority.charAt(0).toUpperCase() + priority.slice(1)
    );
    const priorityCounts = Object.values(priorityData);
    const priorityBackgroundColors = Object.keys(priorityData).map(priority =>
      priorityColors[priority] || '#9CA3AF'
    );

    new Chart(priorityCtx, {
      type: 'pie',
      data: {
        labels: priorityLabels,
        datasets: [{
          data: priorityCounts,
          backgroundColor: priorityBackgroundColors,
          borderWidth: 2,
          borderColor: '#ffffff'
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              padding: 20,
              usePointStyle: true
            }
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                const total = priorityCounts.reduce((a, b) => a + b, 0);
                const percentage = Math.round((context.parsed / total) * 100);
                return `${context.label}: ${context.parsed} (${percentage}%)`;
              }
            }
          }
        }
      }
    });

    // Monthly Trend Chart - Real dynamic data
    const trendCtx = document.getElementById('trendChart').getContext('2d');
    const monthlyTrends = JSON.parse(document.getElementById('trendChart').dataset.monthlyTrends);
    const currentYear = document.getElementById('trendChart').dataset.currentYear;

    const monthLabels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];

    new Chart(trendCtx, {
      type: 'line',
      data: {
        labels: monthLabels,
        datasets: [{
          label: `Reports in ${currentYear}`,
          data: monthlyTrends,
          borderColor: '#10B981',
          backgroundColor: 'rgba(16, 185, 129, 0.1)',
          tension: 0.4,
          fill: true,
          pointBackgroundColor: '#10B981',
          pointBorderColor: '#ffffff',
          pointBorderWidth: 2,
          pointRadius: 5
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: true,
            position: 'top'
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                return `${context.label} ${currentYear}: ${context.parsed.y} reports`;
              }
            }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              stepSize: 1
            }
          }
        },
        elements: {
          point: {
            hoverRadius: 8
          }
        }
      }
    });
  });
</script>

<?php
// Get the captured content
$content = ob_get_clean();

// Use centralized layout
require_once 'includes/layout.php';
renderPage('Admin Dashboard - DRRRS', $content);
?>