<?php
// This file should be included within the sidebar context where $selectedUser is available
// If accessed directly (not via AJAX), redirect back
if (!isset($selectedUser) || !$selectedUser) {
  // Only redirect if not an AJAX request
  if (!isset($_GET['ajax'])) {
    header('Location: index.php?page=admin/users');
    exit;
  } else {
    echo '<div class="p-8 text-center"><p class="text-red-600">User not found.</p></div>';
    return;
  }
}

$user = $selectedUser;
?>

<div class="text-base">
  <!-- User Header -->
  <div class="bg-gradient-to-r from-green-500 to-green-600 rounded-xl p-6 mb-6 text-white">
    <div class="flex items-center space-x-4">
      <div class="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
        </svg>
      </div>
      <div>
        <h2 class="text-2xl font-bold"><?php echo htmlspecialchars($user['name']); ?></h2>
        <p class="text-green-100"><?php echo htmlspecialchars($user['email']); ?></p>
        <div class="flex items-center space-x-2 mt-2">
          <?php if ($user['role'] === 'admin'): ?>
            <span class="px-3 py-1 bg-green-500 bg-opacity-20 text-green-100 rounded-full text-sm font-medium">
              Administrator
            </span>
          <?php else: ?>
            <span class="px-3 py-1 bg-gray-500 bg-opacity-20 text-gray-100 rounded-full text-sm font-medium">
              Citizen
            </span>
          <?php endif; ?>
          <span class="px-3 py-1 bg-white bg-opacity-20 text-white rounded-full text-sm">
            ID: <?php echo htmlspecialchars($user['id']); ?>
          </span>
        </div>
      </div>
    </div>
  </div>

  <!-- User Details -->
  <div class="space-y-6">
    <!-- Contact Information -->
    <div class="bg-white rounded-xl border border-gray-200 p-6">
      <h3 class="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
        <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
        </svg>
        <span>Contact Information</span>
      </h3>
      <div class="grid grid-cols-1 gap-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
          <p class="text-gray-900"><?php echo htmlspecialchars($user['email']); ?></p>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
          <p class="text-gray-900"><?php echo $user['phone'] ? htmlspecialchars($user['phone']) : 'Not provided'; ?></p>
        </div>
      </div>
    </div>

    <!-- Location Information -->
    <div class="bg-white rounded-xl border border-gray-200 p-6">
      <h3 class="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
        <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
        <span>Location</span>
      </h3>
      <div class="grid grid-cols-1 gap-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Division</label>
          <p class="text-gray-900"><?php echo $user['division'] ? htmlspecialchars($user['division']) : 'Not specified'; ?></p>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">District</label>
          <p class="text-gray-900"><?php echo $user['district'] ? htmlspecialchars($user['district']) : 'Not specified'; ?></p>
        </div>
      </div>
    </div>

    <!-- Account Information -->
    <div class="bg-white rounded-xl border border-gray-200 p-6">
      <h3 class="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
        <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <span>Account Information</span>
      </h3>
      <div class="grid grid-cols-1 gap-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Account Status</label>
          <span class="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">
            Active
          </span>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Member Since</label>
          <p class="text-gray-900"><?php echo date('F d, Y', strtotime($user['created_at'])); ?></p>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Last Updated</label>
          <p class="text-gray-900"><?php echo date('F d, Y', strtotime($user['updated_at'])); ?></p>
        </div>
      </div>
    </div>

    <!-- Activity Timeline -->
    <div class="bg-white rounded-xl border border-gray-200 p-6">
      <h3 class="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
        <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <span>Activity Timeline</span>
      </h3>
      <div class="space-y-4">
        <div class="flex items-start space-x-3">
          <div class="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
          <div>
            <p class="text-sm font-medium text-gray-900">Account Created</p>
            <p class="text-xs text-gray-500"><?php echo date('M d, Y \a\t g:i A', strtotime($user['created_at'])); ?></p>
          </div>
        </div>
        <?php if ($user['updated_at'] != $user['created_at']): ?>
          <div class="flex items-start space-x-3">
            <div class="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
            <div>
              <p class="text-sm font-medium text-gray-900">Profile Updated</p>
              <p class="text-xs text-gray-500"><?php echo date('M d, Y \a\t g:i A', strtotime($user['updated_at'])); ?></p>
            </div>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Sticky Action Buttons -->
  <div class="sticky bottom-0 bg-white border-t border-gray-200 pt-4 pb-2 -mx-6 px-6 space-y-3">
    <div class="flex items-center justify-between mb-3">
      <h4 class="text-sm font-semibold text-gray-700">Quick Actions</h4>
      <div class="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
    </div>

    <!-- Edit User Button -->
    <div class="relative group">
      <button
        onclick="openEditUserModal(<?php echo $user['id']; ?>)"
        class="w-full px-4 py-3 rounded-xl font-medium transition-all duration-200 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white shadow-lg hover:shadow-xl transform hover:-translate-y-0.5">
        <div class="flex items-center justify-center space-x-2">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
          </svg>
          <span>Edit User</span>
        </div>
      </button>
    </div>

    <!-- Delete User Button -->
    <?php if ($user['id'] != getCurrentUserId()): ?>
      <div class="relative group">
        <button
          onclick="showDeleteUserConfirmation(<?php echo $user['id']; ?>)"
          class="w-full px-4 py-3 rounded-xl font-medium transition-all duration-200 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white shadow-lg hover:shadow-xl transform hover:-translate-y-0.5">
          <div class="flex items-center justify-center space-x-2">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
            </svg>
            <span>Delete User</span>
          </div>
        </button>
      </div>

      <!-- Delete Confirmation Section (Hidden by default) -->
      <div id="deleteUserConfirmation" class="hidden">
        <div class="bg-red-50 border border-red-200 rounded-xl p-4">
          <div class="flex items-center space-x-3 mb-3">
            <div class="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
              <svg class="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
              </svg>
            </div>
            <h4 class="text-sm font-semibold text-red-800">Confirm Deletion</h4>
          </div>
          <p class="text-sm text-red-700 mb-4">Are you sure you want to delete <strong><?php echo htmlspecialchars($user['name']); ?></strong>? This action cannot be undone.</p>
          <div class="flex space-x-3">
            <button
              onclick="hideDeleteUserConfirmation()"
              class="flex-1 px-4 py-2 text-sm text-gray-700 border border-gray-300 rounded-lg font-medium hover:bg-gray-50 transition-colors">
              Cancel
            </button>
            <button
              onclick="confirmDeleteUser(<?php echo $user['id']; ?>)"
              class="flex-1 px-4 py-2 text-sm bg-gradient-to-r from-red-500 to-red-600 text-white rounded-lg font-medium hover:from-red-600 hover:to-red-700 transition-all duration-200">
              Delete User
            </button>
          </div>
        </div>
      </div>
    <?php else: ?>
      <div class="text-center py-3 text-gray-500 text-sm">
        Cannot delete your own account
      </div>
    <?php endif; ?>
  </div>
</div>

<script>
  function showDeleteUserConfirmation(userId) {
    document.getElementById('deleteUserConfirmation').classList.remove('hidden');
  }

  function hideDeleteUserConfirmation() {
    document.getElementById('deleteUserConfirmation').classList.add('hidden');
  }

  function confirmDeleteUser(userId) {
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = window.location.href;

    const actionField = document.createElement('input');
    actionField.type = 'hidden';
    actionField.name = 'action';
    actionField.value = 'delete';

    const userIdField = document.createElement('input');
    userIdField.type = 'hidden';
    userIdField.name = 'user_id';
    userIdField.value = userId;

    form.appendChild(actionField);
    form.appendChild(userIdField);
    document.body.appendChild(form);
    form.submit();
  }
</script>