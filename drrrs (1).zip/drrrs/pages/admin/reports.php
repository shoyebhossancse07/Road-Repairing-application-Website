<?php

/**
 * Admin Reports Management Page
 * Displays and manages all road repair reports
 */

require_once 'includes/auth.php';
require_once 'includes/models/RoadReport.php';
require_once 'includes/models/WorkCrew.php';
require_once 'includes/models/Division.php';

// Check if user is admin
if (!isAdmin()) {
  header('Location: index.php?page=dashboard&error=access_denied');
  exit;
}

// Initialize models
$roadReport = new RoadReport();
$workCrew = new WorkCrew();
$division = new Division();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';
  $reportId = $_POST['report_id'] ?? '';

  if ($action === 'review' && $reportId) {
    $status = $_POST['status'] ?? '';
    $adminNotes = $_POST['admin_notes'] ?? '';
    $estimatedCost = $_POST['estimated_cost'] ? floatval($_POST['estimated_cost']) : null;
    $reviewedBy = getCurrentUserId();

    if ($roadReport->updateReview($reportId, $status, $adminNotes, $estimatedCost, $reviewedBy)) {
      $successMessage = 'Report reviewed successfully!';
    } else {
      $errorMessage = 'Failed to update report review.';
    }
  } elseif ($action === 'assign' && $reportId) {
    $crewId = $_POST['assigned_crew_id'] ?? '';

    if ($roadReport->assignCrew($reportId, $crewId)) {
      $successMessage = 'Work crew assigned successfully!';
    } else {
      $errorMessage = 'Failed to assign crew.';
    }
  } elseif ($action === 'update_status' && $reportId) {
    $status = $_POST['status'] ?? '';
    $actualCost = $_POST['actual_cost'] ? floatval($_POST['actual_cost']) : null;

    if ($roadReport->updateReportStatus($reportId, $status, $actualCost)) {
      $successMessage = 'Report status updated successfully!';
    } else {
      $errorMessage = 'Failed to update status.';
    }
  }
}

// Get filters from URL
$filters = [
  'search' => $_GET['search'] ?? '',
  'status' => $_GET['status'] ?? '',
  'division' => $_GET['division'] ?? '',
  'priority' => $_GET['priority'] ?? ''
];

// Get sorting parameters
$sortBy = $_GET['sort_by'] ?? 'created_at';
$sortOrder = $_GET['sort_order'] ?? 'desc';
$page = max(1, intval($_GET['page'] ?? 1));

// Get reports with pagination
$reportsData = $roadReport->getAdminReports($filters, $sortBy, $sortOrder, $page, 15);
$reports = $reportsData['data'];
$pagination = $reportsData;

// Get divisions and crews for filters
$divisions = $division->getAll();
$crews = $workCrew->getActive();

// Handle AJAX request for report view
if (isset($_GET['ajax']) && $_GET['ajax'] == '1' && isset($_GET['report_id'])) {
  $selectedReport = $roadReport->getById($_GET['report_id']);
  if ($selectedReport) {
    // Include the report-view.php and output only its content
    include 'pages/admin/report-view.php';
  } else {
    echo '<div class="p-8 text-center"><p class="text-red-600">Report not found.</p></div>';
  }
  exit; // Stop execution for AJAX requests
}

// Check if a specific report should be shown in sidebar
$selectedReport = null;
if (isset($_GET['report_id']) && $_GET['report_id']) {
  $selectedReport = $roadReport->getById($_GET['report_id']);
}

// Success/error messages
$successMessage = $successMessage ?? ($_GET['success'] ?? '');
$errorMessage = $errorMessage ?? ($_GET['error'] ?? '');

// Start output buffering to capture content
ob_start();
?>

<!-- Hero Section -->
<section class="pt-32 pb-8">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="text-center mb-8">
      <h1 class="text-4xl lg:text-5xl font-bold text-gray-900 mb-6 leading-tight">
        Reports
        <span class="text-green-600">Management</span>
      </h1>
      <p class="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
        Manage and track all road repair reports across Bangladesh. Filter, review, and update report statuses.
      </p>
    </div>
  </div>
</section>

<!-- Messages -->
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
  <?php if ($successMessage): ?>
    <div class="mb-8">
      <div class="bg-green-50 border border-green-200 rounded-xl p-6 shadow-sm">
        <div class="flex items-start">
          <div class="flex-shrink-0">
            <div class="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
              <svg class="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
              </svg>
            </div>
          </div>
          <div class="ml-4">
            <h3 class="text-lg font-semibold text-green-800">Success!</h3>
            <p class="text-green-700 mt-1"><?php echo htmlspecialchars($successMessage); ?></p>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <?php if ($errorMessage): ?>
    <div class="mb-8">
      <div class="bg-red-50 border border-red-200 rounded-xl p-6 shadow-sm">
        <div class="flex items-start">
          <div class="flex-shrink-0">
            <div class="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center">
              <svg class="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
              </svg>
            </div>
          </div>
          <div class="ml-4">
            <h3 class="text-lg font-semibold text-red-800">Error!</h3>
            <p class="text-red-700 mt-1"><?php echo htmlspecialchars($errorMessage); ?></p>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>
</div>

<!-- Search and Filters -->
<section class="pb-8 mt-8">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
      <h2 class="text-2xl font-bold text-gray-900 mb-6">Search & Filter Reports</h2>

      <form method="GET" action="index.php" class="space-y-6">
        <input type="hidden" name="page" value="admin/reports">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label for="search" class="block text-sm font-medium text-gray-700 mb-2">Search</label>
            <input type="text" id="search" name="search" value="<?php echo htmlspecialchars($filters['search']); ?>"
              class="w-full px-4 py-3 border border-gray-300 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200"
              placeholder="Report ID, Title, or Location">
          </div>

          <div>
            <label for="status" class="block text-sm font-medium text-gray-700 mb-2">Status</label>
            <select id="status" name="status"
              class="w-full px-4 py-3 border border-gray-300 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
              <option value="">All Statuses</option>
              <option value="pending" <?php echo $filters['status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
              <option value="approved" <?php echo $filters['status'] === 'approved' ? 'selected' : ''; ?>>Approved</option>
              <option value="in_progress" <?php echo $filters['status'] === 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
              <option value="completed" <?php echo $filters['status'] === 'completed' ? 'selected' : ''; ?>>Completed</option>
              <option value="rejected" <?php echo $filters['status'] === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
            </select>
          </div>

          <div>
            <label for="division" class="block text-sm font-medium text-gray-700 mb-2">Division</label>
            <select id="division" name="division"
              class="w-full px-4 py-3 border border-gray-300 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
              <option value="">All Divisions</option>
              <?php foreach ($divisions as $div): ?>
                <option value="<?php echo htmlspecialchars($div['name']); ?>" <?php echo $filters['division'] === $div['name'] ? 'selected' : ''; ?>>
                  <?php echo htmlspecialchars($div['name']); ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div>
            <label for="priority" class="block text-sm font-medium text-gray-700 mb-2">Priority</label>
            <select id="priority" name="priority"
              class="w-full px-4 py-3 border border-gray-300 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
              <option value="">All Priorities</option>
              <option value="low" <?php echo $filters['priority'] === 'low' ? 'selected' : ''; ?>>Low</option>
              <option value="medium" <?php echo $filters['priority'] === 'medium' ? 'selected' : ''; ?>>Medium</option>
              <option value="high" <?php echo $filters['priority'] === 'high' ? 'selected' : ''; ?>>High</option>
              <option value="urgent" <?php echo $filters['priority'] === 'urgent' ? 'selected' : ''; ?>>Urgent</option>
            </select>
          </div>
        </div>

        <div class="flex flex-col sm:flex-row items-center justify-between space-y-4 sm:space-y-0">
          <div class="text-sm text-gray-600 bg-gray-50 px-4 py-2 rounded-xl">
            Showing <span class="font-medium text-gray-900"><?php echo count($reports); ?></span> of <span class="font-medium text-gray-900"><?php echo $pagination['total']; ?></span> reports
          </div>
          <div class="flex space-x-3">
            <a href="index.php?page=admin/reports" class="inline-flex items-center px-6 py-3 bg-red-600 hover:bg-red-700 text-white font-medium rounded-xl transition-all duration-200">
              Clear Filters
            </a>
            <button type="submit" class="inline-flex items-center px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300">
              Search Reports
            </button>
          </div>
        </div>
      </form>
    </div>
  </div>
</section>

<!-- Reports Table -->
<section class="pb-12 mt-8">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden">
      <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
          <thead class="bg-gray-50">
            <tr>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100" onclick="sortTable('report_id')">
                Report ID
                <svg class="w-4 h-4 inline ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                </svg>
              </th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100" onclick="sortTable('title')">
                Title
                <svg class="w-4 h-4 inline ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                </svg>
              </th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100" onclick="sortTable('division')">
                Location
                <svg class="w-4 h-4 inline ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                </svg>
              </th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100" onclick="sortTable('status')">
                Status
                <svg class="w-4 h-4 inline ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                </svg>
              </th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100 w-32" onclick="sortTable('priority')">
                Priority
                <svg class="w-4 h-4 inline ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                </svg>
              </th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100 w-32">
                Assigned Crew
                <svg class="w-4 h-4 inline ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                </svg>
              </th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100" onclick="sortTable('created_at')">
                Created
                <svg class="w-4 h-4 inline ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                </svg>
              </th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-20">Actions</th>
            </tr>
          </thead>
          <tbody class="bg-white divide-y divide-gray-200">
            <?php if (count($reports) > 0): ?>
              <?php
              $statusColors = [
                'pending' => 'bg-green-100 text-green-800',
                'approved' => 'bg-blue-100 text-blue-800',
                'in_progress' => 'bg-orange-100 text-orange-800',
                'completed' => 'bg-green-100 text-green-800',
                'rejected' => 'bg-red-100 text-red-800'
              ];
              $priorityColors = [
                'low' => 'bg-green-100 text-green-800',
                'medium' => 'bg-blue-100 text-blue-800',
                'high' => 'bg-orange-100 text-orange-800',
                'urgent' => 'bg-red-100 text-red-800'
              ];
              ?>
              <?php foreach ($reports as $report): ?>
                <tr class="hover:bg-gray-50">
                  <td class="px-6 py-4 whitespace-nowrap">
                    <div class="text-sm font-medium text-gray-900">#<?php echo htmlspecialchars($report['id']); ?></div>
                  </td>
                  <td class="px-6 py-4">
                    <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars(substr($report['title'], 0, 30)); ?></div>
                    <div class="text-sm text-gray-500"><?php echo htmlspecialchars(substr($report['description'], 0, 50)); ?></div>
                  </td>
                  <td class="px-6 py-4">
                    <div class="text-sm text-gray-900"><?php echo htmlspecialchars($report['division']); ?>, <?php echo htmlspecialchars($report['district'] ?? ''); ?></div>
                    <div class="text-sm text-gray-500"><?php echo htmlspecialchars(substr($report['location'], 0, 30)); ?></div>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $statusColors[$report['status']] ?? 'bg-gray-100 text-gray-800'; ?>">
                      <?php echo ucfirst(str_replace('_', ' ', $report['status'])); ?>
                    </span>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $priorityColors[$report['priority']] ?? 'bg-gray-100 text-gray-800'; ?>">
                      <?php echo ucfirst($report['priority']); ?>
                    </span>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <?php if ($report['crew_name']): ?>
                      <div class="text-sm text-gray-900"><?php echo htmlspecialchars($report['crew_name']); ?></div>
                      <div class="text-sm text-gray-500"><?php echo htmlspecialchars($report['crew_division']); ?></div>
                    <?php else: ?>
                      <span class="text-sm text-gray-500">Not assigned</span>
                    <?php endif; ?>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <?php echo date('M d, Y', strtotime($report['created_at'])); ?>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button onclick="viewReport(<?php echo $report['id']; ?>)" class="text-green-600 hover:text-green-900 font-medium">View</button>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr>
                <td colspan="8" class="px-6 py-12 text-center text-gray-500">
                  <div class="text-gray-500">
                    <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    <h3 class="mt-2 text-sm font-medium text-gray-900">No reports found</h3>
                    <p class="mt-1 text-sm text-gray-500">Try adjusting your search or filter criteria.</p>
                  </div>
                </td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <!-- Pagination - Always Show -->
      <div class="bg-white px-6 py-4 border-t border-gray-200">
        <div class="flex items-center justify-between">
          <div class="text-sm text-gray-700">
            Showing <?php echo $pagination['from']; ?> to <?php echo $pagination['to']; ?> of <?php echo $pagination['total']; ?> results
          </div>
          <div class="flex items-center space-x-2">
            <?php
            // Build pagination links
            $queryParams = $_GET;
            unset($queryParams['page']);
            $queryString = http_build_query($queryParams);
            $baseUrl = 'index.php?' . $queryString;
            if ($queryString) $baseUrl .= '&';
            ?>

            <?php if ($pagination['current_page'] > 1): ?>
              <a href="<?php echo $baseUrl; ?>page=<?php echo ($pagination['current_page'] - 1); ?>" class="px-3 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-md hover:bg-gray-50">Previous</a>
            <?php endif; ?>

            <?php for ($i = max(1, $pagination['current_page'] - 2); $i <= min($pagination['last_page'], $pagination['current_page'] + 2); $i++): ?>
              <?php if ($i == $pagination['current_page']): ?>
                <span class="px-3 py-2 text-sm font-medium text-white bg-green-600 border border-green-600 rounded-md"><?php echo $i; ?></span>
              <?php else: ?>
                <a href="<?php echo $baseUrl; ?>page=<?php echo $i; ?>" class="px-3 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-md hover:bg-gray-50"><?php echo $i; ?></a>
              <?php endif; ?>
            <?php endfor; ?>

            <?php if ($pagination['current_page'] < $pagination['last_page']): ?>
              <a href="<?php echo $baseUrl; ?>page=<?php echo ($pagination['current_page'] + 1); ?>" class="px-3 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-md hover:bg-gray-50">Next</a>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Report View Sidebar Backdrop -->
<div id="reportSidebarBackdrop" class="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm z-40 hidden"></div>

<!-- Report View Sidebar -->
<div id="reportSidebar" class="fixed inset-y-0 right-0 w-[600px] bg-gradient-to-b from-white to-gray-50 shadow-2xl transform translate-x-full transition-transform duration-300 ease-in-out z-50">
  <div class="h-full flex flex-col">
    <!-- Sidebar Header -->
    <div class="flex items-center justify-between p-8 border-b border-gray-200 bg-white">
      <div class="flex items-center space-x-3">
        <div class="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center">
          <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
        </div>
        <div>
          <h3 class="text-xl font-bold text-gray-900">Report Details</h3>
          <p class="text-sm text-gray-500">View and manage report information</p>
        </div>
      </div>
      <button onclick="closeReportSidebar()" class="w-10 h-10 bg-gray-100 hover:bg-gray-200 rounded-xl flex items-center justify-center transition-colors">
        <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
        </svg>
      </button>
    </div>

    <!-- Sidebar Content -->
    <div class="flex-1 overflow-y-auto p-8" id="reportSidebarContent">
      <?php if ($selectedReport): ?>
        <?php include 'admin/report-view.php'; ?>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Review Modal -->
<div id="reviewModal" class="fixed inset-0 bg-black bg-opacity-50 overflow-y-auto h-full w-full hidden z-50 backdrop-blur-sm">
  <div class="relative top-20 mx-auto p-0 border-0 w-full max-w-md shadow-2xl rounded-2xl bg-white overflow-hidden">
    <!-- Modal Header -->
    <div class="bg-gradient-to-r from-green-700 to-green-800 px-8 py-6">
      <div class="flex items-center justify-between">
        <div class="flex items-center space-x-3">
          <div class="w-12 h-12 bg-white bg-opacity-20 rounded-xl flex items-center justify-center">
            <svg class="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div>
            <h3 class="text-xl font-bold text-white">Review Report</h3>
            <p class="text-green-100 text-sm">Evaluate and approve/reject this report</p>
          </div>
        </div>
        <button onclick="closeReviewModal()" class="w-10 h-10 bg-white bg-opacity-20 hover:bg-opacity-30 rounded-xl flex items-center justify-center transition-all duration-200">
          <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>
    </div>

    <!-- Modal Content -->
    <div class="p-8">
      <form id="reviewForm" method="POST" class="space-y-6">
        <input type="hidden" name="action" value="review">
        <input type="hidden" name="report_id" id="reviewReportId">

        <!-- Decision Selection -->
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-3">Review Decision</label>
          <div class="grid grid-cols-2 gap-3">
            <label class="relative cursor-pointer">
              <input type="radio" name="status" value="approved" class="sr-only peer" checked>
              <div class="border-2 border-gray-200 rounded-xl p-4 text-center transition-all duration-200 peer-checked:border-green-500 peer-checked:bg-green-50 hover:border-green-300 hover:bg-green-50">
                <svg class="w-8 h-8 mx-auto mb-2 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <div class="font-semibold text-gray-900">Approve</div>
                <div class="text-sm text-gray-500">Accept this report</div>
              </div>
            </label>
            <label class="relative cursor-pointer">
              <input type="radio" name="status" value="rejected" class="sr-only peer">
              <div class="border-2 border-gray-200 rounded-xl p-4 text-center transition-all duration-200 peer-checked:border-red-500 peer-checked:bg-red-50 hover:border-red-300 hover:bg-red-50">
                <svg class="w-8 h-8 mx-auto mb-2 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <div class="font-semibold text-gray-900">Reject</div>
                <div class="text-sm text-gray-500">Decline this report</div>
              </div>
            </label>
          </div>
        </div>

        <!-- Estimated Cost -->
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-3">Estimated Cost</label>
          <div class="relative">
            <span class="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500 font-medium">৳</span>
            <input type="number" name="estimated_cost" min="0" step="0.01" class="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors" placeholder="0.00">
          </div>
        </div>

        <!-- Admin Notes -->
        <div>
          <label class="block text-sm font-semibold text-gray-700 mb-3">Review Notes</label>
          <textarea name="admin_notes" rows="4" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500 resize-none transition-colors" placeholder="Provide detailed feedback and reasoning for your decision..."></textarea>
        </div>

        <!-- Action Buttons -->
        <div class="flex space-x-4 pt-4">
          <button type="button" onclick="closeReviewModal()" class="flex-1 px-6 py-3 text-gray-700 border-2 border-gray-300 rounded-xl font-medium hover:bg-gray-50 transition-colors">
            Cancel
          </button>
          <button type="submit" class="flex-1 px-6 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-xl font-medium hover:from-green-600 hover:to-green-700 transition-all duration-200 transform hover:scale-105">
            Submit Review
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Assign Crew Modal -->
<div id="assignModal" class="fixed inset-0 bg-black bg-opacity-50 overflow-y-auto h-full w-full hidden z-50 backdrop-blur-sm">
  <div class="relative top-20 mx-auto p-0 border-0 w-full max-w-md shadow-2xl rounded-2xl bg-white overflow-hidden">
    <!-- Modal Header -->
    <div class="bg-gradient-to-r from-green-600 to-green-700 px-8 py-6">
      <div class="flex items-center justify-between">
        <div class="flex items-center space-x-3">
          <div class="w-12 h-12 bg-white bg-opacity-20 rounded-xl flex items-center justify-center">
            <svg class="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
          </div>
          <div>
            <h3 class="text-xl font-bold text-white">Assign Work Crew</h3>
            <p class="text-green-100 text-sm">Select a crew to handle this report</p>
          </div>
        </div>
        <button onclick="closeAssignModal()" class="w-10 h-10 bg-white bg-opacity-20 hover:bg-opacity-30 rounded-xl flex items-center justify-center transition-all duration-200">
          <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>
    </div>

    <!-- Modal Content -->
    <div class="p-8">
      <form id="assignForm" method="POST" class="space-y-6">
        <input type="hidden" name="action" value="assign">
        <input type="hidden" name="report_id" id="assignReportId">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Select Crew</label>
          <select name="assigned_crew_id" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200" required>
            <option value="">Select a work crew</option>
            <?php foreach ($crews as $crew): ?>
              <option value="<?php echo $crew['id']; ?>"><?php echo htmlspecialchars($crew['name']); ?> - <?php echo htmlspecialchars($crew['division']); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <!-- Action Buttons -->
        <div class="flex space-x-4 pt-4">
          <button type="button" onclick="closeAssignModal()" class="flex-1 px-6 py-3 text-gray-700 border-2 border-gray-300 rounded-xl font-medium hover:bg-gray-50 transition-colors">
            Cancel
          </button>
          <button type="submit" class="flex-1 px-6 py-3 bg-gradient-to-r from-green-600 to-green-700 text-white rounded-xl font-medium hover:from-green-700 hover:to-green-800 transition-all duration-200 transform hover:scale-105">
            Assign Crew
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Status Update Modal -->
<div id="statusModal" class="fixed inset-0 bg-black bg-opacity-50 overflow-y-auto h-full w-full hidden z-50 backdrop-blur-sm">
  <div class="relative top-20 mx-auto p-0 border-0 w-full max-w-md shadow-2xl rounded-2xl bg-white overflow-hidden">
    <!-- Modal Header -->
    <div class="bg-gradient-to-r from-green-700 to-green-800 px-8 py-6">
      <div class="flex items-center justify-between">
        <div class="flex items-center space-x-3">
          <div class="w-12 h-12 bg-white bg-opacity-20 rounded-xl flex items-center justify-center">
            <svg class="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
          </div>
          <div>
            <h3 class="text-xl font-bold text-white">Update Status</h3>
            <p class="text-green-100 text-sm">Update the current status of this report</p>
          </div>
        </div>
        <button onclick="closeStatusModal()" class="w-10 h-10 bg-white bg-opacity-20 hover:bg-opacity-30 rounded-xl flex items-center justify-center transition-all duration-200">
          <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>
    </div>

    <!-- Modal Content -->
    <div class="p-8">
      <form id="statusForm" method="POST" class="space-y-6">
        <input type="hidden" name="action" value="update_status">
        <input type="hidden" name="report_id" id="statusReportId">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">New Status</label>
          <select name="status" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200" required>
            <option value="">Select status</option>
            <option value="in_progress">In Progress</option>
            <option value="completed">Completed</option>
          </select>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Actual Cost (BDT)</label>
          <input type="number" name="actual_cost" step="0.01" min="0" placeholder="0.00" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
        </div>
        <!-- Action Buttons -->
        <div class="flex space-x-4 pt-4">
          <button type="button" onclick="closeStatusModal()" class="flex-1 px-6 py-3 text-gray-700 border-2 border-gray-300 rounded-xl font-medium hover:bg-gray-50 transition-colors">
            Cancel
          </button>
          <button type="submit" class="flex-1 px-6 py-3 bg-gradient-to-r from-green-700 to-green-800 text-white rounded-xl font-medium hover:from-green-800 hover:to-green-900 transition-all duration-200 transform hover:scale-105">
            Update Status
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
  function viewReport(reportId) {
    // Update URL
    const url = new URL(window.location);
    url.searchParams.set('report_id', reportId);
    window.history.pushState({}, '', url);

    // Load report content via AJAX
    fetch(`index.php?page=admin/reports&report_id=${reportId}&ajax=1`)
      .then(response => response.text())
      .then(html => {
        document.getElementById('reportSidebarContent').innerHTML = html;
        document.getElementById('reportSidebar').classList.remove('translate-x-full');
        document.getElementById('reportSidebarBackdrop').classList.remove('hidden');
      })
      .catch(error => {
        console.error('Error loading report:', error);
      });
  }

  function closeReportSidebar() {
    document.getElementById('reportSidebar').classList.add('translate-x-full');
    document.getElementById('reportSidebarBackdrop').classList.add('hidden');
    // Reset URL
    const url = new URL(window.location);
    url.searchParams.delete('report_id');
    window.history.pushState({}, '', url);
  }

  function openReviewModal(reportId) {
    document.getElementById('reviewReportId').value = reportId;
    document.getElementById('reviewModal').classList.remove('hidden');
  }

  function closeReviewModal() {
    document.getElementById('reviewModal').classList.add('hidden');
  }

  function openAssignModal(reportId) {
    document.getElementById('assignReportId').value = reportId;
    document.getElementById('assignModal').classList.remove('hidden');
  }

  function closeAssignModal() {
    document.getElementById('assignModal').classList.add('hidden');
  }

  function openStatusModal(reportId) {
    document.getElementById('statusReportId').value = reportId;
    document.getElementById('statusModal').classList.remove('hidden');
  }

  function closeStatusModal() {
    document.getElementById('statusModal').classList.add('hidden');
  }

  // Close modals when clicking outside
  window.onclick = function(event) {
    const modals = ['reviewModal', 'assignModal', 'statusModal'];
    modals.forEach(modalId => {
      const modal = document.getElementById(modalId);
      if (event.target === modal) {
        modal.classList.add('hidden');
      }
    });

    // Close sidebar when clicking on backdrop
    const backdrop = document.getElementById('reportSidebarBackdrop');
    if (event.target === backdrop) {
      closeReportSidebar();
    }
  }

  // Handle browser back button
  window.addEventListener('popstate', function() {
    const url = new URL(window.location);
    if (!url.searchParams.has('report_id')) {
      closeReportSidebar();
    }
  });

  // Sorting functionality
  function sortTable(column) {
    const urlParams = new URLSearchParams(window.location.search);
    const currentSortBy = urlParams.get('sort_by') || 'created_at';
    const currentSortOrder = urlParams.get('sort_order') || 'desc';

    let newSortOrder = 'asc';
    if (currentSortBy === column && currentSortOrder === 'asc') {
      newSortOrder = 'desc';
    }

    urlParams.set('sort_by', column);
    urlParams.set('sort_order', newSortOrder);

    window.location.href = `${window.location.pathname}?${urlParams.toString()}`;
  }

  // Auto-focus search input if search parameter exists and auto-open sidebar if report_id exists
  document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('search');
    const urlParams = new URLSearchParams(window.location.search);

    if (urlParams.get('search') && searchInput) {
      searchInput.focus();
      searchInput.select();
    }

    // Auto-open sidebar if report_id parameter exists
    if (urlParams.get('report_id')) {
      const reportId = urlParams.get('report_id');
      viewReport(reportId);
    }
  });
</script>

<?php
// Get the captured content
$content = ob_get_clean();

// Use centralized layout
require_once 'includes/layout.php';
renderPage('Admin - Reports Management', $content);
?>