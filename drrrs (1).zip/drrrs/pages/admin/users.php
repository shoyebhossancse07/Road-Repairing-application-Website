<?php

/**
 * Admin Users Management Page
 * Displays and manages all system users
 */

require_once 'includes/auth.php';
require_once 'includes/models/User.php';
require_once 'includes/models/Division.php';

// Check if user is admin
if (!isAdmin()) {
  header('Location: index.php?page=dashboard&error=access_denied');
  exit;
}

// Initialize models
$user = new User();
$division = new Division();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';

  if ($action === 'create') {
    // Validate password confirmation
    if ($_POST['password'] !== $_POST['password_confirmation']) {
      $errorMessage = 'Passwords do not match.';
    } else {
      $data = [
        'name' => $_POST['name'] ?? '',
        'email' => $_POST['email'] ?? '',
        'password' => password_hash($_POST['password'], PASSWORD_DEFAULT),
        'role' => $_POST['role'] ?? 'citizen',
        'phone' => $_POST['phone'] ?? null,
        'division' => $_POST['division'] ?? null,
        'district' => $_POST['district'] ?? null
      ];

      if ($user->createWithDetails($data)) {
        $successMessage = 'User created successfully!';
      } else {
        $errorMessage = 'Failed to create user.';
      }
    }
  } elseif ($action === 'update') {
    $userId = $_POST['user_id'] ?? '';
    $data = [
      'name' => $_POST['name'] ?? '',
      'email' => $_POST['email'] ?? '',
      'role' => $_POST['role'] ?? 'citizen',
      'phone' => $_POST['phone'] ?? null,
      'division' => $_POST['division'] ?? null,
      'district' => $_POST['district'] ?? null
    ];

    // Handle password update if provided
    if (!empty($_POST['password'])) {
      if ($_POST['password'] !== $_POST['password_confirmation']) {
        $errorMessage = 'Passwords do not match.';
      } else {
        $data['password'] = password_hash($_POST['password'], PASSWORD_DEFAULT);
      }
    }

    if (!isset($errorMessage) && $user->updateWithDetails($userId, $data)) {
      $successMessage = 'User updated successfully!';
    } elseif (!isset($errorMessage)) {
      $errorMessage = 'Failed to update user.';
    }
  } elseif ($action === 'delete') {
    $userId = $_POST['user_id'] ?? '';

    // Prevent deleting own account
    if ($userId == getCurrentUserId()) {
      $errorMessage = 'You cannot delete your own account.';
    } else {
      if ($user->delete($userId)) {
        $successMessage = 'User deleted successfully!';
      } else {
        $errorMessage = 'Failed to delete user.';
      }
    }
  }
}

// Handle AJAX request for user view
if (isset($_GET['ajax']) && $_GET['ajax'] == '1' && isset($_GET['user_id'])) {
  $selectedUser = $user->getById($_GET['user_id']);
  if ($selectedUser) {
    // Include the user-view.php and output only its content
    include 'pages/admin/user-view.php';
  } else {
    echo '<div class="p-8 text-center"><p class="text-red-600">User not found.</p></div>';
  }
  exit; // Stop execution for AJAX requests
}

// Handle AJAX request for user edit data
if (isset($_GET['edit']) && $_GET['edit'] == '1' && isset($_GET['user_id'])) {
  $selectedUser = $user->getById($_GET['user_id']);
  if ($selectedUser) {
    // Remove password from response
    unset($selectedUser['password']);
    header('Content-Type: application/json');
    echo json_encode($selectedUser);
  } else {
    http_response_code(404);
    echo json_encode(['error' => 'User not found']);
  }
  exit;
}

// Get sorting parameters
$sortBy = $_GET['sort_by'] ?? 'name';
$sortOrder = $_GET['sort_order'] ?? 'asc';
$page = max(1, intval($_GET['page'] ?? 1));

// Get users with pagination
$usersData = $user->getAdminUsers($sortBy, $sortOrder, $page, 10);
$users = $usersData['data'];
$pagination = $usersData;

// Get divisions for form
$divisions = $division->getAll();

// Check if a specific user should be shown in sidebar
$selectedUser = null;
if (isset($_GET['user_id']) && $_GET['user_id']) {
  $selectedUser = $user->getById($_GET['user_id']);
}

// Success/error messages
$successMessage = $successMessage ?? ($_GET['success'] ?? '');
$errorMessage = $errorMessage ?? ($_GET['error'] ?? '');

// Start output buffering to capture content
ob_start();
?>

<!-- Hero Section -->
<section class="pt-32 pb-8">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="text-center mb-8">
      <h1 class="text-4xl lg:text-5xl font-bold text-gray-900 mb-6 leading-tight">
        Users
        <span class="text-green-600">Management</span>
      </h1>
      <p class="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
        Manage system users including citizens and administrators. Create new accounts and manage permissions.
      </p>
    </div>
  </div>
</section>

<!-- Add New User Section -->
<section class="pb-8">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="bg-white rounded-2xl shadow-lg border border-gray-200 p-6">
      <h3 class="text-lg font-semibold text-gray-900 mb-4">Add New User</h3>
      <form method="POST" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <input type="hidden" name="action" value="create">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
          <input type="text" name="name" required class="w-full px-4 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500" placeholder="Full Name">
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Email</label>
          <input type="email" name="email" required class="w-full px-4 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500" placeholder="email@example.com">
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Password</label>
          <input type="password" name="password" required class="w-full px-4 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500" placeholder="Password">
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Confirm Password</label>
          <input type="password" name="password_confirmation" required class="w-full px-4 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500" placeholder="Confirm Password">
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Role</label>
          <select name="role" required class="w-full px-4 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500">
            <option value="">Select Role</option>
            <option value="citizen">Citizen</option>
            <option value="admin">Administrator</option>
          </select>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Phone</label>
          <input type="text" name="phone" class="w-full px-4 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500" placeholder="+880 1XXX XXX XXX">
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Division</label>
          <select name="division" class="w-full px-4 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500">
            <option value="">Select Division</option>
            <?php foreach ($divisions as $div): ?>
              <option value="<?php echo htmlspecialchars($div['name']); ?>"><?php echo htmlspecialchars($div['name']); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">District</label>
          <input type="text" name="district" class="w-full px-4 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500" placeholder="District">
        </div>
        <div class="flex items-end">
          <button type="submit" class="w-full bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-xl font-medium transition-colors">
            Add User
          </button>
        </div>
      </form>
    </div>
  </div>
</section>

<!-- Users List -->
<section class="pb-12">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden">
      <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
          <thead class="bg-gray-50">
            <tr>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100" onclick="sortTable('name')">
                <div class="flex items-center space-x-1">
                  <span>Name</span>
                  <?php if ($sortBy == 'name'): ?>
                    <?php if ($sortOrder == 'asc'): ?>
                      <svg class="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7" />
                      </svg>
                    <?php else: ?>
                      <svg class="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                      </svg>
                    <?php endif; ?>
                  <?php else: ?>
                    <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                    </svg>
                  <?php endif; ?>
                </div>
              </th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100" onclick="sortTable('email')">
                <div class="flex items-center space-x-1">
                  <span>Email</span>
                  <?php if ($sortBy == 'email'): ?>
                    <?php if ($sortOrder == 'asc'): ?>
                      <svg class="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7" />
                      </svg>
                    <?php else: ?>
                      <svg class="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                      </svg>
                    <?php endif; ?>
                  <?php else: ?>
                    <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                    </svg>
                  <?php endif; ?>
                </div>
              </th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100" onclick="sortTable('role')">
                <div class="flex items-center space-x-1">
                  <span>Role</span>
                  <?php if ($sortBy == 'role'): ?>
                    <?php if ($sortOrder == 'asc'): ?>
                      <svg class="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7" />
                      </svg>
                    <?php else: ?>
                      <svg class="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                      </svg>
                    <?php endif; ?>
                  <?php else: ?>
                    <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                    </svg>
                  <?php endif; ?>
                </div>
              </th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100" onclick="sortTable('division')">
                <div class="flex items-center space-x-1">
                  <span>Location</span>
                  <?php if ($sortBy == 'division'): ?>
                    <?php if ($sortOrder == 'asc'): ?>
                      <svg class="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7" />
                      </svg>
                    <?php else: ?>
                      <svg class="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                      </svg>
                    <?php endif; ?>
                  <?php else: ?>
                    <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                    </svg>
                  <?php endif; ?>
                </div>
              </th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100" onclick="sortTable('phone')">
                <div class="flex items-center space-x-1">
                  <span>Phone</span>
                  <?php if ($sortBy == 'phone'): ?>
                    <?php if ($sortOrder == 'asc'): ?>
                      <svg class="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7" />
                      </svg>
                    <?php else: ?>
                      <svg class="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                      </svg>
                    <?php endif; ?>
                  <?php else: ?>
                    <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                    </svg>
                  <?php endif; ?>
                </div>
              </th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100" onclick="sortTable('created_at')">
                <div class="flex items-center space-x-1">
                  <span>Joined</span>
                  <?php if ($sortBy == 'created_at'): ?>
                    <?php if ($sortOrder == 'asc'): ?>
                      <svg class="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7" />
                      </svg>
                    <?php else: ?>
                      <svg class="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                      </svg>
                    <?php endif; ?>
                  <?php else: ?>
                    <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                    </svg>
                  <?php endif; ?>
                </div>
              </th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody class="bg-white divide-y divide-gray-200">
            <?php if (count($users) > 0): ?>
              <?php foreach ($users as $userData): ?>
                <tr class="hover:bg-gray-50">
                  <td class="px-6 py-4 whitespace-nowrap">
                    <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($userData['name']); ?></div>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($userData['email']); ?></td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <?php if ($userData['role'] === 'admin'): ?>
                      <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800 border border-green-200">
                        Administrator
                      </span>
                    <?php else: ?>
                      <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800 border border-gray-200">
                        Citizen
                      </span>
                    <?php endif; ?>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    <?php if ($userData['division'] && $userData['district']): ?>
                      <?php echo htmlspecialchars($userData['division']); ?>, <?php echo htmlspecialchars($userData['district']); ?>
                    <?php elseif ($userData['division']): ?>
                      <?php echo htmlspecialchars($userData['division']); ?>
                    <?php else: ?>
                      <span class="text-gray-500">Not specified</span>
                    <?php endif; ?>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    <?php echo $userData['phone'] ? htmlspecialchars($userData['phone']) : 'Not provided'; ?>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <?php echo date('M d, Y', strtotime($userData['created_at'])); ?>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button onclick="viewUser(<?php echo $userData['id']; ?>)" class="text-green-600 hover:text-green-900 font-medium">View</button>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr>
                <td colspan="7" class="px-6 py-12 text-center text-gray-500">
                  <div class="text-lg font-medium">No users found</div>
                  <div class="text-sm">Create your first user above</div>
                </td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <!-- Pagination -->
      <div class="bg-white px-6 py-4 border-t border-gray-200">
        <div class="flex items-center justify-between">
          <div class="text-sm text-gray-700">
            Showing <?php echo $pagination['from']; ?> to <?php echo $pagination['to']; ?> of <?php echo $pagination['total']; ?> results
          </div>
          <div class="flex items-center space-x-2">
            <?php
            // Build pagination links
            $queryParams = $_GET;
            unset($queryParams['page']);
            $queryString = http_build_query($queryParams);
            $baseUrl = 'index.php?' . $queryString;
            if ($queryString) $baseUrl .= '&';
            ?>

            <?php if ($pagination['current_page'] > 1): ?>
              <a href="<?php echo $baseUrl; ?>page=<?php echo ($pagination['current_page'] - 1); ?>" class="px-3 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-md hover:bg-gray-50">Previous</a>
            <?php endif; ?>

            <?php for ($i = max(1, $pagination['current_page'] - 2); $i <= min($pagination['last_page'], $pagination['current_page'] + 2); $i++): ?>
              <?php if ($i == $pagination['current_page']): ?>
                <span class="px-3 py-2 text-sm font-medium text-white bg-green-600 border border-green-600 rounded-md"><?php echo $i; ?></span>
              <?php else: ?>
                <a href="<?php echo $baseUrl; ?>page=<?php echo $i; ?>" class="px-3 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-md hover:bg-gray-50"><?php echo $i; ?></a>
              <?php endif; ?>
            <?php endfor; ?>

            <?php if ($pagination['current_page'] < $pagination['last_page']): ?>
              <a href="<?php echo $baseUrl; ?>page=<?php echo ($pagination['current_page'] + 1); ?>" class="px-3 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-md hover:bg-gray-50">Next</a>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- User View Sidebar Backdrop -->
<div id="userSidebarBackdrop" class="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm z-40 hidden"></div>

<!-- User View Sidebar -->
<div id="userSidebar" class="fixed inset-y-0 right-0 w-[600px] bg-gradient-to-b from-white to-gray-50 shadow-2xl transform translate-x-full transition-transform duration-300 ease-in-out z-50">
  <div class="h-full flex flex-col">
    <!-- Sidebar Header -->
    <div class="flex items-center justify-between p-8 border-b border-gray-200 bg-white">
      <div class="flex items-center space-x-3">
        <div class="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center">
          <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
          </svg>
        </div>
        <div>
          <h3 class="text-xl font-bold text-gray-900">User Details</h3>
          <p class="text-sm text-gray-500">View and manage user information</p>
        </div>
      </div>
      <button onclick="closeUserSidebar()" class="w-10 h-10 bg-gray-100 hover:bg-gray-200 rounded-xl flex items-center justify-center transition-colors">
        <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
        </svg>
      </button>
    </div>

    <!-- Sidebar Content -->
    <div class="flex-1 overflow-y-auto p-8" id="userSidebarContent">
      <?php if ($selectedUser): ?>
        <?php include 'admin/user-view.php'; ?>
      <?php endif; ?>
      <!-- Content will be loaded here -->
    </div>
  </div>
</div>

<!-- Edit User Modal -->
<div id="editModal" class="fixed inset-0 bg-black bg-opacity-50 overflow-y-auto h-full w-full hidden z-50 backdrop-blur-sm">
  <div class="relative top-20 mx-auto p-0 border-0 w-full max-w-md shadow-2xl rounded-2xl bg-white overflow-hidden">
    <!-- Modal Header -->
    <div class="bg-gradient-to-r from-green-600 to-green-700 px-8 py-6">
      <div class="flex items-center justify-between">
        <div class="flex items-center space-x-3">
          <div class="w-12 h-12 bg-white bg-opacity-20 rounded-xl flex items-center justify-center">
            <svg class="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
            </svg>
          </div>
          <div>
            <h3 class="text-xl font-bold text-white">Edit User</h3>
            <p class="text-green-100 text-sm">Update user information</p>
          </div>
        </div>
        <button onclick="closeEditModal()" class="w-10 h-10 bg-white bg-opacity-20 hover:bg-opacity-30 rounded-xl flex items-center justify-center transition-all duration-200">
          <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>
    </div>

    <!-- Modal Content -->
    <div class="p-8">
      <form id="editForm" method="POST" class="space-y-6">
        <input type="hidden" name="action" value="update">
        <input type="hidden" name="user_id" id="edit_user_id">

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
            <input type="text" name="name" id="edit_name" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Email</label>
            <input type="email" name="email" id="edit_email" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Role</label>
            <select name="role" id="edit_role" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
              <option value="citizen">Citizen</option>
              <option value="admin">Administrator</option>
            </select>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Phone</label>
            <input type="text" name="phone" id="edit_phone" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Division</label>
            <select name="division" id="edit_division" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
              <option value="">Select Division</option>
              <?php foreach ($divisions as $div): ?>
                <option value="<?php echo htmlspecialchars($div['name']); ?>"><?php echo htmlspecialchars($div['name']); ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">District</label>
            <input type="text" name="district" id="edit_district" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
          </div>
        </div>

        <div class="space-y-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">New Password (leave blank to keep current)</label>
            <input type="password" name="password" id="edit_password" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Confirm New Password</label>
            <input type="password" name="password_confirmation" id="edit_password_confirmation" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
          </div>
        </div>

        <!-- Action Buttons -->
        <div class="flex space-x-4 pt-4">
          <button type="button" onclick="closeEditModal()" class="flex-1 px-6 py-3 text-gray-700 border-2 border-gray-300 rounded-xl font-medium hover:bg-gray-50 transition-colors">
            Cancel
          </button>
          <button type="submit" class="flex-1 px-6 py-3 bg-gradient-to-r from-green-600 to-green-700 text-white rounded-xl font-medium hover:from-green-700 hover:to-green-800 transition-all duration-200 transform hover:scale-105">
            Update User
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
  function viewUser(userId) {
    // Update URL
    const url = new URL(window.location);
    url.searchParams.set('user_id', userId);
    window.history.pushState({}, '', url);

    // Load user content via AJAX
    fetch(`index.php?page=admin/users&user_id=${userId}&ajax=1`)
      .then(response => response.text())
      .then(html => {
        document.getElementById('userSidebarContent').innerHTML = html;
        document.getElementById('userSidebar').classList.remove('translate-x-full');
        document.getElementById('userSidebarBackdrop').classList.remove('hidden');
      })
      .catch(error => {
        console.error('Error loading user:', error);
      });
  }

  function closeUserSidebar() {
    document.getElementById('userSidebar').classList.add('translate-x-full');
    document.getElementById('userSidebarBackdrop').classList.add('hidden');
    // Reset URL
    const url = new URL(window.location);
    url.searchParams.delete('user_id');
    window.history.pushState({}, '', url);
  }

  function openEditUserModal(userId) {
    // Fetch user data and populate form
    fetch(`index.php?page=admin/users&user_id=${userId}&edit=1`)
      .then(response => response.json())
      .then(data => {
        document.getElementById('edit_user_id').value = data.id;
        document.getElementById('edit_name').value = data.name;
        document.getElementById('edit_email').value = data.email;
        document.getElementById('edit_role').value = data.role;
        document.getElementById('edit_phone').value = data.phone || '';
        document.getElementById('edit_division').value = data.division || '';
        document.getElementById('edit_district').value = data.district || '';

        document.getElementById('editModal').classList.remove('hidden');
      })
      .catch(error => {
        console.error('Error fetching user data:', error);
        alert('Error loading user data. Please try again.');
      });
  }

  function closeEditModal() {
    document.getElementById('editModal').classList.add('hidden');
  }

  function showDeleteUserConfirmation(userId) {
    console.log('Showing delete confirmation for user:', userId);
    const deleteConfirmation = document.getElementById('deleteUserConfirmation');
    if (deleteConfirmation) {
      deleteConfirmation.classList.remove('hidden');
    }
  }

  function hideDeleteUserConfirmation() {
    console.log('Hiding delete confirmation');
    const deleteConfirmation = document.getElementById('deleteUserConfirmation');
    if (deleteConfirmation) {
      deleteConfirmation.classList.add('hidden');
    }
  }

  function confirmDeleteUser(userId) {
    console.log('Confirming delete for user:', userId);
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = window.location.href;

    const actionField = document.createElement('input');
    actionField.type = 'hidden';
    actionField.name = 'action';
    actionField.value = 'delete';

    const userIdField = document.createElement('input');
    userIdField.type = 'hidden';
    userIdField.name = 'user_id';
    userIdField.value = userId;

    form.appendChild(actionField);
    form.appendChild(userIdField);
    document.body.appendChild(form);
    form.submit();
  }

  // Close modals when clicking outside
  window.onclick = function(event) {
    const editModal = document.getElementById('editModal');
    const userSidebarBackdrop = document.getElementById('userSidebarBackdrop');

    if (event.target === editModal) {
      closeEditModal();
    }

    if (event.target === userSidebarBackdrop) {
      closeUserSidebar();
    }
  }

  // Handle browser back button
  window.addEventListener('popstate', function() {
    const url = new URL(window.location);
    if (!url.searchParams.has('user_id')) {
      closeUserSidebar();
    }
  });

  function sortTable(column) {
    const urlParams = new URLSearchParams(window.location.search);
    const currentSortBy = urlParams.get('sort_by') || 'name';
    const currentSortOrder = urlParams.get('sort_order') || 'asc';

    let newSortOrder = 'asc';
    if (currentSortBy === column && currentSortOrder === 'asc') {
      newSortOrder = 'desc';
    }

    urlParams.set('sort_by', column);
    urlParams.set('sort_order', newSortOrder);

    window.location.href = `${window.location.pathname}?${urlParams.toString()}`;
  }

  // Auto-open sidebar if user_id parameter exists
  document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const userId = urlParams.get('user_id');

    if (userId) {
      viewUser(userId);
    }
  });
</script>

<?php
// Get the captured content
$content = ob_get_clean();

// Use centralized layout
require_once 'includes/layout.php';
renderPage('Admin - Users Management', $content);
?>