<?php
// This file should be included within the sidebar context where $selectedCrew is available
// If accessed directly (not via AJAX), redirect back
if (!isset($selectedCrew) || !$selectedCrew) {
  // Only redirect if not an AJAX request
  if (!isset($_GET['ajax'])) {
    header('Location: index.php?page=admin/crews');
    exit;
  } else {
    echo '<div class="p-8 text-center"><p class="text-red-600">Crew not found.</p></div>';
    return;
  }
}

$crew = $selectedCrew;
$statusColors = [
  'active' => 'bg-green-100 text-green-800 border-green-200',
  'inactive' => 'bg-gray-100 text-gray-800 border-gray-200',
  'maintenance' => 'bg-yellow-100 text-yellow-800 border-yellow-200'
];

// Get assigned reports for this crew
$assignedReports = $workCrew->getAssignedReports($crew['id']);
?>

<!-- Crew Details -->
<div class="space-y-8 text-base">
  <!-- Crew Header -->
  <div class="bg-gradient-to-r from-gray-50 to-white rounded-2xl p-6 border border-gray-100">
    <div class="flex items-start justify-between mb-4">
      <div class="flex-1">
        <h2 class="text-2xl font-bold text-gray-900 mb-2"><?php echo htmlspecialchars($crew['name']); ?></h2>
        <p class="text-gray-600 text-sm">Crew ID: #<?php echo htmlspecialchars($crew['id']); ?></p>
      </div>
      <div class="flex items-center space-x-3">
        <span class="px-4 py-2 text-sm font-semibold rounded-full border <?php echo $statusColors[$crew['status']] ?? 'bg-gray-100 text-gray-800 border-gray-200'; ?>">
          <?php echo ucfirst($crew['status']); ?>
        </span>
      </div>
    </div>

    <?php if ($crew['status'] === 'maintenance'): ?>
      <div class="bg-gradient-to-r from-yellow-50 to-yellow-100 border border-yellow-200 rounded-xl p-4">
        <div class="flex items-center">
          <div class="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center mr-3">
            <svg class="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
            </svg>
          </div>
          <div>
            <span class="text-yellow-800 font-bold text-lg">UNDER MAINTENANCE</span>
            <p class="text-yellow-700 text-sm">This crew is currently unavailable for assignments</p>
          </div>
        </div>
      </div>
    <?php endif; ?>
  </div>

  <!-- Crew Information -->
  <div>
    <h3 class="text-lg font-semibold text-gray-900 mb-3">Crew Information</h3>
    <div class="space-y-3">
      <div>
        <span class="text-sm font-medium text-gray-600">Specialization:</span>
        <p class="text-gray-900 mt-1"><?php echo htmlspecialchars($crew['specialization']); ?></p>
      </div>
      <div>
        <span class="text-sm font-medium text-gray-600">Division:</span>
        <p class="text-gray-900"><?php echo htmlspecialchars($crew['division']); ?></p>
      </div>
      <div>
        <span class="text-sm font-medium text-gray-600">Team Size:</span>
        <p class="text-gray-900"><?php echo htmlspecialchars($crew['team_size']); ?> members</p>
      </div>
      <?php if ($crew['description']): ?>
        <div>
          <span class="text-sm font-medium text-gray-600">Description:</span>
          <p class="text-gray-900 mt-1"><?php echo nl2br(htmlspecialchars($crew['description'])); ?></p>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Supervisor Information -->
  <div>
    <h3 class="text-lg font-semibold text-gray-900 mb-3">Supervisor Information</h3>
    <div class="bg-green-50 border border-green-200 rounded-lg p-4">
      <div class="space-y-2">
        <div>
          <span class="text-sm font-medium text-gray-600">Name:</span>
          <p class="text-gray-900 font-medium"><?php echo htmlspecialchars($crew['supervisor_name']); ?></p>
        </div>
        <div>
          <span class="text-sm font-medium text-gray-600">Phone:</span>
          <p class="text-gray-900"><?php echo htmlspecialchars($crew['supervisor_phone']); ?></p>
        </div>
      </div>
    </div>
  </div>

  <!-- Assigned Reports -->
  <div>
    <h3 class="text-lg font-semibold text-gray-900 mb-3">Assigned Reports</h3>

    <?php if (count($assignedReports) > 0): ?>
      <div class="space-y-3">
        <?php
        $reportStatusColors = [
          'pending' => 'bg-green-100 text-green-800 border-green-200',
          'approved' => 'bg-green-200 text-green-800 border-green-300',
          'in_progress' => 'bg-orange-100 text-orange-800 border-orange-200',
          'completed' => 'bg-green-100 text-green-800 border-green-200',
          'rejected' => 'bg-red-100 text-red-800 border-red-200'
        ];
        ?>
        <?php foreach ($assignedReports as $report): ?>
          <div class="bg-gray-50 border border-gray-200 rounded-lg p-4">
            <div class="flex items-start justify-between">
              <div class="flex-1">
                <h4 class="font-medium text-gray-900"><?php echo htmlspecialchars($report['title']); ?></h4>
                <p class="text-sm text-gray-600">Report ID: #<?php echo htmlspecialchars($report['id']); ?></p>
                <p class="text-sm text-gray-600"><?php echo htmlspecialchars($report['division']); ?>, <?php echo htmlspecialchars($report['district'] ?? ''); ?></p>
              </div>
              <div class="ml-4">
                <span class="px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full border <?php echo $reportStatusColors[$report['status']] ?? 'bg-gray-100 text-gray-800 border-gray-200'; ?>">
                  <?php echo ucfirst(str_replace('_', ' ', $report['status'])); ?>
                </span>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="bg-gray-50 border border-gray-200 rounded-lg p-6 text-center">
        <svg class="w-12 h-12 text-gray-400 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
        <p class="text-gray-500 font-medium">No reports assigned</p>
        <p class="text-sm text-gray-400">This crew hasn't been assigned to any reports yet</p>
      </div>
    <?php endif; ?>
  </div>

  <!-- Timeline -->
  <div>
    <h3 class="text-lg font-semibold text-gray-900 mb-3">Crew Timeline</h3>
    <div class="space-y-3">
      <div class="flex items-center">
        <div class="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
        <div>
          <p class="text-sm font-medium text-gray-900">Crew Created</p>
          <p class="text-xs text-gray-600"><?php echo date('M d, Y g:i A', strtotime($crew['created_at'])); ?></p>
        </div>
      </div>

      <?php if ($crew['updated_at'] && $crew['updated_at'] != $crew['created_at']): ?>
        <div class="flex items-center">
          <div class="w-3 h-3 bg-blue-500 rounded-full mr-3"></div>
          <div>
            <p class="text-sm font-medium text-gray-900">Crew Updated</p>
            <p class="text-xs text-gray-600"><?php echo date('M d, Y g:i A', strtotime($crew['updated_at'])); ?></p>
          </div>
        </div>
      <?php endif; ?>

      <?php if (count($assignedReports) > 0): ?>
        <div class="flex items-center">
          <div class="w-3 h-3 bg-purple-500 rounded-full mr-3"></div>
          <div>
            <p class="text-sm font-medium text-gray-900">First Assignment</p>
            <p class="text-xs text-gray-600"><?php echo date('M d, Y g:i A', strtotime($assignedReports[0]['created_at'])); ?></p>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Sticky Action Buttons -->
  <div class="sticky bottom-0 bg-white border-t border-gray-200 pt-4 pb-2 -mx-6 px-6 space-y-3">
    <div class="flex items-center justify-between mb-3">
      <h4 class="text-sm font-semibold text-gray-700">Quick Actions</h4>
      <div class="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
    </div>

    <!-- Edit Crew Button -->
    <div class="relative group">
      <button
        onclick="openEditCrewModal(<?php echo $crew['id']; ?>)"
        class="w-full px-4 py-3 rounded-xl font-medium transition-all duration-200 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white shadow-lg hover:shadow-xl transform hover:-translate-y-0.5">
        <div class="flex items-center justify-center space-x-2">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
          </svg>
          <span>Edit Crew</span>
        </div>
      </button>
    </div>

    <!-- Delete Crew Button -->
    <div class="relative group">
      <button
        onclick="showDeleteConfirmation(<?php echo $crew['id']; ?>)"
        class="w-full px-4 py-3 rounded-xl font-medium transition-all duration-200 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white shadow-lg hover:shadow-xl transform hover:-translate-y-0.5">
        <div class="flex items-center justify-center space-x-2">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
          </svg>
          <span>Delete Crew</span>
        </div>
      </button>
    </div>

    <!-- Delete Confirmation Section (Hidden by default) -->
    <div id="deleteConfirmation" class="hidden">
      <div class="bg-red-50 border border-red-200 rounded-xl p-4">
        <div class="flex items-center space-x-3 mb-3">
          <div class="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
            <svg class="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
            </svg>
          </div>
          <h4 class="text-sm font-semibold text-red-800">Confirm Deletion</h4>
        </div>
        <p class="text-sm text-red-700 mb-4">Are you sure you want to delete <strong><?php echo htmlspecialchars($crew['name']); ?></strong>? This action cannot be undone.</p>
        <div class="flex space-x-3">
          <button
            onclick="hideDeleteConfirmation()"
            class="flex-1 px-4 py-2 text-sm text-gray-700 border border-gray-300 rounded-lg font-medium hover:bg-gray-50 transition-colors">
            Cancel
          </button>
          <button
            onclick="confirmDeleteCrew(<?php echo $crew['id']; ?>)"
            class="flex-1 px-4 py-2 text-sm bg-gradient-to-r from-red-500 to-red-600 text-white rounded-lg font-medium hover:from-red-600 hover:to-red-700 transition-all duration-200">
            Delete Crew
          </button>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  // Delete confirmation functions are now defined in the main crews page
  // They will be called from the sidebar buttons
</script>