<?php

/**
 * Admin Work Crews Management Page
 * Displays and manages all work crews
 */

require_once 'includes/auth.php';
require_once 'includes/models/WorkCrew.php';
require_once 'includes/models/Division.php';

// Check if user is admin
if (!isAdmin()) {
  header('Location: index.php?page=dashboard&error=access_denied');
  exit;
}

// Initialize models
$workCrew = new WorkCrew();
$division = new Division();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';

  if ($action === 'create') {
    $data = [
      'name' => $_POST['name'] ?? '',
      'specialization' => $_POST['specialization'] ?? '',
      'division' => $_POST['division'] ?? '',
      'description' => $_POST['description'] ?? '',
      'team_size' => $_POST['team_size'] ?? 5,
      'supervisor_name' => $_POST['supervisor_name'] ?? '',
      'supervisor_phone' => $_POST['supervisor_phone'] ?? '',
      'status' => $_POST['status'] ?? 'active'
    ];

    if ($workCrew->create($data)) {
      $successMessage = 'Work crew created successfully!';
    } else {
      $errorMessage = 'Failed to create work crew.';
    }
  } elseif ($action === 'update') {
    $crewId = $_POST['crew_id'] ?? '';
    $data = [
      'name' => $_POST['name'] ?? '',
      'specialization' => $_POST['specialization'] ?? '',
      'division' => $_POST['division'] ?? '',
      'description' => $_POST['description'] ?? '',
      'team_size' => $_POST['team_size'] ?? 5,
      'supervisor_name' => $_POST['supervisor_name'] ?? '',
      'supervisor_phone' => $_POST['supervisor_phone'] ?? '',
      'status' => $_POST['status'] ?? 'active'
    ];

    if ($workCrew->update($crewId, $data)) {
      $successMessage = 'Work crew updated successfully!';
    } else {
      $errorMessage = 'Failed to update work crew.';
    }
  } elseif ($action === 'delete') {
    $crewId = $_POST['crew_id'] ?? '';

    if ($workCrew->delete($crewId)) {
      $successMessage = 'Work crew deleted successfully!';
    } else {
      $errorMessage = 'Failed to delete work crew.';
    }
  }
}

// Handle AJAX request for crew view
if (isset($_GET['ajax']) && $_GET['ajax'] == '1' && isset($_GET['crew_id'])) {
  $selectedCrew = $workCrew->getById($_GET['crew_id']);
  if ($selectedCrew) {
    // Include the crew-view.php and output only its content
    include 'pages/admin/crew-view.php';
  } else {
    echo '<div class="p-8 text-center"><p class="text-red-600">Crew not found.</p></div>';
  }
  exit; // Stop execution for AJAX requests
}

// Handle AJAX request for crew edit data
if (isset($_GET['edit']) && $_GET['edit'] == '1' && isset($_GET['crew_id'])) {
  $selectedCrew = $workCrew->getById($_GET['crew_id']);
  if ($selectedCrew) {
    header('Content-Type: application/json');
    echo json_encode($selectedCrew);
  } else {
    http_response_code(404);
    echo json_encode(['error' => 'Crew not found']);
  }
  exit;
}

// Get sorting parameters
$sortBy = $_GET['sort_by'] ?? 'name';
$sortOrder = $_GET['sort_order'] ?? 'asc';
$page = max(1, intval($_GET['page'] ?? 1));

// Get crews with pagination
$crewsData = $workCrew->getAdminCrews($sortBy, $sortOrder, $page, 10);
$crews = $crewsData['data'];
$pagination = $crewsData;

// Get divisions for form
$divisions = $division->getAll();

// Check if a specific crew should be shown in sidebar
$selectedCrew = null;
if (isset($_GET['crew_id']) && $_GET['crew_id']) {
  $selectedCrew = $workCrew->getById($_GET['crew_id']);
}

// Success/error messages
$successMessage = $successMessage ?? ($_GET['success'] ?? '');
$errorMessage = $errorMessage ?? ($_GET['error'] ?? '');

// Start output buffering to capture content
ob_start();
?>

<!-- Hero Section -->
<section class="pt-32 pb-8">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="text-center mb-8">
      <h1 class="text-4xl lg:text-5xl font-bold text-gray-900 mb-6 leading-tight">
        Work Crews
        <span class="text-green-600">Management</span>
      </h1>
      <p class="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
        Manage and track all work crews across Bangladesh. Create, assign, and monitor crew performance.
      </p>
    </div>
  </div>
</section>

<!-- Messages -->
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
  <?php if ($successMessage): ?>
    <div class="mb-8">
      <div class="bg-green-50 border border-green-200 rounded-xl p-6 shadow-sm">
        <div class="flex items-start">
          <div class="flex-shrink-0">
            <div class="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
              <svg class="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
              </svg>
            </div>
          </div>
          <div class="ml-4">
            <h3 class="text-lg font-semibold text-green-800">Success!</h3>
            <p class="text-green-700 mt-1"><?php echo htmlspecialchars($successMessage); ?></p>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <?php if ($errorMessage): ?>
    <div class="mb-8">
      <div class="bg-red-50 border border-red-200 rounded-xl p-6 shadow-sm">
        <div class="flex items-start">
          <div class="flex-shrink-0">
            <div class="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center">
              <svg class="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
              </svg>
            </div>
          </div>
          <div class="ml-4">
            <h3 class="text-lg font-semibold text-red-800">Error!</h3>
            <p class="text-red-700 mt-1"><?php echo htmlspecialchars($errorMessage); ?></p>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>
</div>

<!-- Add New Crew Section -->
<section class="pb-8 mt-8">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
      <h2 class="text-2xl font-bold text-gray-900 mb-6">Add New Work Crew</h2>

      <form method="POST" class="space-y-6">
        <input type="hidden" name="action" value="create">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Crew Name</label>
            <input type="text" name="name" required class="w-full px-4 py-3 border border-gray-300 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200" placeholder="e.g., Crew Alpha">
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Specialization</label>
            <input type="text" name="specialization" required class="w-full px-4 py-3 border border-gray-300 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200" placeholder="e.g., Road Repair">
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Division</label>
            <select name="division" required class="w-full px-4 py-3 border border-gray-300 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
              <option value="">Select Division</option>
              <?php foreach ($divisions as $div): ?>
                <option value="<?php echo htmlspecialchars($div['name']); ?>"><?php echo htmlspecialchars($div['name']); ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Team Size</label>
            <input type="number" name="team_size" min="1" max="50" required class="w-full px-4 py-3 border border-gray-300 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200" placeholder="5">
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Supervisor Name</label>
            <input type="text" name="supervisor_name" required class="w-full px-4 py-3 border border-gray-300 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200" placeholder="Supervisor Name">
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Supervisor Phone</label>
            <input type="text" name="supervisor_phone" required class="w-full px-4 py-3 border border-gray-300 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200" placeholder="+880 1XXX XXX XXX">
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
            <select name="status" required class="w-full px-4 py-3 border border-gray-300 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
              <option value="maintenance">Maintenance</option>
            </select>
          </div>
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Description (Optional)</label>
          <textarea name="description" rows="3" class="w-full px-4 py-3 border border-gray-300 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 resize-none transition-all duration-200" placeholder="Additional details about the crew..."></textarea>
        </div>

        <div class="flex justify-end">
          <button type="submit" class="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white px-8 py-3 rounded-xl font-medium shadow-lg hover:shadow-xl transition-all duration-200 transform hover:-translate-y-0.5">
            Add Work Crew
          </button>
        </div>
      </form>
    </div>
  </div>
</section>

<!-- Crews List -->
<section class="pb-12 mt-8">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden">
      <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
          <thead class="bg-gray-50">
            <tr>
              <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100" onclick="sortTable('name')">
                <div class="flex items-center space-x-1">
                  <span>Crew Name</span>
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                  </svg>
                </div>
              </th>
              <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100" onclick="sortTable('specialization')">
                <div class="flex items-center space-x-1">
                  <span>Specialization</span>
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                  </svg>
                </div>
              </th>
              <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100" onclick="sortTable('division')">
                <div class="flex items-center space-x-1">
                  <span>Division</span>
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                  </svg>
                </div>
              </th>
              <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100" onclick="sortTable('team_size')">
                <div class="flex items-center space-x-1">
                  <span>Team Size</span>
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                  </svg>
                </div>
              </th>
              <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100" onclick="sortTable('supervisor_name')">
                <div class="flex items-center space-x-1">
                  <span>Supervisor</span>
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                  </svg>
                </div>
              </th>
              <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100" onclick="sortTable('status')">
                <div class="flex items-center space-x-1">
                  <span>Status</span>
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                  </svg>
                </div>
              </th>
              <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-20">Actions</th>
            </tr>
          </thead>
          <tbody class="bg-white divide-y divide-gray-200">
            <?php if (count($crews) > 0): ?>
              <?php
              $statusColors = [
                'active' => 'bg-green-100 text-green-800 border-green-200',
                'inactive' => 'bg-gray-100 text-gray-800 border-gray-200',
                'maintenance' => 'bg-yellow-100 text-yellow-800 border-yellow-200'
              ];
              ?>
              <?php foreach ($crews as $crew): ?>
                <tr class="hover:bg-gray-50">
                  <td class="px-6 py-4 whitespace-nowrap">
                    <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($crew['name']); ?></div>
                    <?php if ($crew['description']): ?>
                      <div class="text-xs text-gray-500"><?php echo htmlspecialchars(substr($crew['description'], 0, 30)); ?></div>
                    <?php endif; ?>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($crew['specialization']); ?></td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($crew['division']); ?></td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($crew['team_size']); ?> members</td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <div class="text-sm text-gray-900"><?php echo htmlspecialchars($crew['supervisor_name']); ?></div>
                    <div class="text-xs text-gray-500"><?php echo htmlspecialchars($crew['supervisor_phone']); ?></div>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <span class="px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full border <?php echo $statusColors[$crew['status']] ?? 'bg-gray-100 text-gray-800 border-gray-200'; ?>">
                      <?php echo ucfirst($crew['status']); ?>
                    </span>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button onclick="viewCrew(<?php echo $crew['id']; ?>)" class="text-green-600 hover:text-green-900 font-medium">View</button>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr>
                <td colspan="7" class="px-6 py-12 text-center text-gray-500">
                  <div class="text-lg font-medium">No work crews found</div>
                  <div class="text-sm">Create your first work crew above</div>
                </td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <!-- Pagination -->
      <div class="bg-white px-6 py-4 border-t border-gray-200">
        <div class="flex items-center justify-between">
          <div class="text-sm text-gray-700">
            Showing <?php echo $pagination['from']; ?> to <?php echo $pagination['to']; ?> of <?php echo $pagination['total']; ?> results
          </div>
          <div class="flex items-center space-x-2">
            <?php
            // Build pagination links
            $queryParams = $_GET;
            unset($queryParams['page']);
            $queryString = http_build_query($queryParams);
            $baseUrl = 'index.php?' . $queryString;
            if ($queryString) $baseUrl .= '&';
            ?>

            <?php if ($pagination['current_page'] > 1): ?>
              <a href="<?php echo $baseUrl; ?>page=<?php echo ($pagination['current_page'] - 1); ?>" class="px-3 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-md hover:bg-gray-50">Previous</a>
            <?php endif; ?>

            <?php for ($i = max(1, $pagination['current_page'] - 2); $i <= min($pagination['last_page'], $pagination['current_page'] + 2); $i++): ?>
              <?php if ($i == $pagination['current_page']): ?>
                <span class="px-3 py-2 text-sm font-medium text-white bg-green-600 border border-green-600 rounded-md"><?php echo $i; ?></span>
              <?php else: ?>
                <a href="<?php echo $baseUrl; ?>page=<?php echo $i; ?>" class="px-3 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-md hover:bg-gray-50"><?php echo $i; ?></a>
              <?php endif; ?>
            <?php endfor; ?>

            <?php if ($pagination['current_page'] < $pagination['last_page']): ?>
              <a href="<?php echo $baseUrl; ?>page=<?php echo ($pagination['current_page'] + 1); ?>" class="px-3 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-md hover:bg-gray-50">Next</a>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Crew View Sidebar Backdrop -->
<div id="crewSidebarBackdrop" class="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm z-40 hidden"></div>

<!-- Crew View Sidebar -->
<div id="crewSidebar" class="fixed inset-y-0 right-0 w-[600px] bg-gradient-to-b from-white to-gray-50 shadow-2xl transform translate-x-full transition-transform duration-300 ease-in-out z-50">
  <div class="h-full flex flex-col">
    <!-- Sidebar Header -->
    <div class="flex items-center justify-between p-8 border-b border-gray-200 bg-white">
      <div class="flex items-center space-x-3">
        <div class="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center">
          <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
          </svg>
        </div>
        <div>
          <h3 class="text-xl font-bold text-gray-900">Crew Details</h3>
          <p class="text-sm text-gray-500">View and manage crew information</p>
        </div>
      </div>
      <button onclick="closeCrewSidebar()" class="w-10 h-10 bg-gray-100 hover:bg-gray-200 rounded-xl flex items-center justify-center transition-colors">
        <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
        </svg>
      </button>
    </div>

    <!-- Sidebar Content -->
    <div class="flex-1 overflow-y-auto p-8" id="crewSidebarContent">
      <?php if ($selectedCrew): ?>
        <?php include 'admin/crew-view.php'; ?>
      <?php endif; ?>
      <!-- Content will be loaded here -->
    </div>
  </div>
</div>

<!-- Edit Crew Modal -->
<div id="editModal" class="fixed inset-0 bg-black bg-opacity-50 overflow-y-auto h-full w-full hidden z-50 backdrop-blur-sm">
  <div class="relative top-20 mx-auto p-0 border-0 w-full max-w-md shadow-2xl rounded-2xl bg-white overflow-hidden">
    <!-- Modal Header -->
    <div class="bg-gradient-to-r from-green-600 to-green-700 px-8 py-6">
      <div class="flex items-center justify-between">
        <div class="flex items-center space-x-3">
          <div class="w-12 h-12 bg-white bg-opacity-20 rounded-xl flex items-center justify-center">
            <svg class="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
            </svg>
          </div>
          <div>
            <h3 class="text-xl font-bold text-white">Edit Work Crew</h3>
            <p class="text-green-100 text-sm">Update crew information</p>
          </div>
        </div>
        <button onclick="closeEditModal()" class="w-10 h-10 bg-white bg-opacity-20 hover:bg-opacity-30 rounded-xl flex items-center justify-center transition-all duration-200">
          <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>
    </div>

    <!-- Modal Content -->
    <div class="p-8">
      <form id="editForm" method="POST" class="space-y-6">
        <input type="hidden" name="action" value="update">
        <input type="hidden" name="crew_id" id="edit_crew_id">

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Crew Name</label>
            <input type="text" name="name" id="edit_name" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Specialization</label>
            <input type="text" name="specialization" id="edit_specialization" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Division</label>
            <select name="division" id="edit_division" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
              <?php foreach ($divisions as $div): ?>
                <option value="<?php echo htmlspecialchars($div['name']); ?>"><?php echo htmlspecialchars($div['name']); ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Team Size</label>
            <input type="number" name="team_size" id="edit_team_size" min="1" max="50" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Supervisor Name</label>
            <input type="text" name="supervisor_name" id="edit_supervisor_name" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Supervisor Phone</label>
            <input type="text" name="supervisor_phone" id="edit_supervisor_phone" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
            <select name="status" id="edit_status" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200">
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
              <option value="maintenance">Maintenance</option>
            </select>
          </div>
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Description</label>
          <textarea name="description" id="edit_description" rows="3" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500 resize-none transition-all duration-200"></textarea>
        </div>

        <!-- Action Buttons -->
        <div class="flex space-x-4 pt-4">
          <button type="button" onclick="closeEditModal()" class="flex-1 px-6 py-3 text-gray-700 border-2 border-gray-300 rounded-xl font-medium hover:bg-gray-50 transition-colors">
            Cancel
          </button>
          <button type="submit" class="flex-1 px-6 py-3 bg-gradient-to-r from-green-600 to-green-700 text-white rounded-xl font-medium hover:from-green-700 hover:to-green-800 transition-all duration-200 transform hover:scale-105">
            Update Crew
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
  function viewCrew(crewId) {
    // Update URL
    const url = new URL(window.location);
    url.searchParams.set('crew_id', crewId);
    window.history.pushState({}, '', url);

    // Load crew content via AJAX
    fetch(`index.php?page=admin/crews&crew_id=${crewId}&ajax=1`)
      .then(response => response.text())
      .then(html => {
        document.getElementById('crewSidebarContent').innerHTML = html;
        document.getElementById('crewSidebar').classList.remove('translate-x-full');
        document.getElementById('crewSidebarBackdrop').classList.remove('hidden');
      })
      .catch(error => {
        console.error('Error loading crew:', error);
      });
  }

  function closeCrewSidebar() {
    document.getElementById('crewSidebar').classList.add('translate-x-full');
    document.getElementById('crewSidebarBackdrop').classList.add('hidden');
    // Reset URL
    const url = new URL(window.location);
    url.searchParams.delete('crew_id');
    window.history.pushState({}, '', url);
  }

  // Sorting functionality
  function sortTable(column) {
    const urlParams = new URLSearchParams(window.location.search);
    const currentSortBy = urlParams.get('sort_by') || 'name';
    const currentSortOrder = urlParams.get('sort_order') || 'asc';

    let newSortOrder = 'asc';
    if (currentSortBy === column && currentSortOrder === 'asc') {
      newSortOrder = 'desc';
    }

    urlParams.set('sort_by', column);
    urlParams.set('sort_order', newSortOrder);

    window.location.href = `${window.location.pathname}?${urlParams.toString()}`;
  }

  // Close sidebar when clicking on backdrop
  window.onclick = function(event) {
    const backdrop = document.getElementById('crewSidebarBackdrop');
    if (event.target === backdrop) {
      closeCrewSidebar();
    }

    const editModal = document.getElementById('editModal');
    if (event.target === editModal) {
      closeEditModal();
    }
  }

  // Handle browser back button
  window.addEventListener('popstate', function() {
    const url = new URL(window.location);
    if (!url.searchParams.has('crew_id')) {
      closeCrewSidebar();
    }
  });

  function closeEditModal() {
    document.getElementById('editModal').classList.add('hidden');
  }

  function openEditCrewModal(crewId) {
    console.log('Opening edit modal for crew:', crewId);
    // Fetch crew data and populate form
    fetch(`index.php?page=admin/crews&crew_id=${crewId}&edit=1`)
      .then(response => {
        console.log('Response status:', response.status);
        return response.json();
      })
      .then(data => {
        console.log('Crew data received:', data);
        // Populate the edit form
        document.getElementById('edit_crew_id').value = data.id;
        document.getElementById('edit_name').value = data.name;
        document.getElementById('edit_specialization').value = data.specialization;
        document.getElementById('edit_division').value = data.division;
        document.getElementById('edit_team_size').value = data.team_size;
        document.getElementById('edit_supervisor_name').value = data.supervisor_name;
        document.getElementById('edit_supervisor_phone').value = data.supervisor_phone;
        document.getElementById('edit_status').value = data.status;
        document.getElementById('edit_description').value = data.description || '';

        document.getElementById('editModal').classList.remove('hidden');
      })
      .catch(error => {
        console.error('Error fetching crew data:', error);
        alert('Error loading crew data. Please try again.');
      });
  }

  function showDeleteConfirmation(crewId) {
    console.log('Showing delete confirmation for crew:', crewId);
    const deleteConfirmation = document.getElementById('deleteConfirmation');
    if (deleteConfirmation) {
      deleteConfirmation.classList.remove('hidden');
    }
  }

  function hideDeleteConfirmation() {
    console.log('Hiding delete confirmation');
    const deleteConfirmation = document.getElementById('deleteConfirmation');
    if (deleteConfirmation) {
      deleteConfirmation.classList.add('hidden');
    }
  }

  function confirmDeleteCrew(crewId) {
    console.log('Confirming delete for crew:', crewId);
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = window.location.href;

    const actionField = document.createElement('input');
    actionField.type = 'hidden';
    actionField.name = 'action';
    actionField.value = 'delete';

    const crewIdField = document.createElement('input');
    crewIdField.type = 'hidden';
    crewIdField.name = 'crew_id';
    crewIdField.value = crewId;

    form.appendChild(actionField);
    form.appendChild(crewIdField);
    document.body.appendChild(form);
    form.submit();
  }

  // Auto-open sidebar if crew_id parameter exists
  document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const crewId = urlParams.get('crew_id');

    if (crewId) {
      const crewId = urlParams.get('crew_id');
      viewCrew(crewId);
    }
  });
</script>

<?php
// Get the captured content
$content = ob_get_clean();

// Use centralized layout
require_once 'includes/layout.php';
renderPage('Admin - Work Crews Management', $content);
?>