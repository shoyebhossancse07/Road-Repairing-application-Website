<?php
// This file should be included within the sidebar context where $selectedReport is available
// If accessed directly (not via AJAX), redirect back
if (!isset($selectedReport) || !$selectedReport) {
  // Only redirect if not an AJAX request
  if (!isset($_GET['ajax'])) {
    header('Location: index.php?page=admin/reports');
    exit;
  } else {
    echo '<div class="p-8 text-center"><p class="text-red-600">Report not found.</p></div>';
    return;
  }
}

$report = $selectedReport;
$statusColors = [
  'pending' => 'bg-green-100 text-green-800 border-green-200',
  'approved' => 'bg-green-200 text-green-800 border-green-300',
  'in_progress' => 'bg-orange-100 text-orange-800 border-orange-200',
  'completed' => 'bg-green-100 text-green-800 border-green-200',
  'rejected' => 'bg-red-100 text-red-800 border-red-200'
];
?>

<!-- Report Details -->
<div class="space-y-8">
  <!-- Report Header -->
  <div class="bg-gradient-to-r from-gray-50 to-white rounded-2xl p-6 border border-gray-100">
    <div class="flex items-start justify-between mb-4">
      <div class="flex-1">
        <h2 class="text-2xl font-bold text-gray-900 mb-2"><?php echo htmlspecialchars($report['title']); ?></h2>
        <p class="text-gray-600 text-sm">Report ID: #<?php echo htmlspecialchars($report['id']); ?></p>
      </div>
      <div class="flex items-center space-x-3">
        <span class="px-4 py-2 text-sm font-semibold rounded-full border <?php echo $statusColors[$report['status']] ?? 'bg-gray-100 text-gray-800 border-gray-200'; ?>">
          <?php echo ucfirst(str_replace('_', ' ', $report['status'])); ?>
        </span>
      </div>
    </div>

    <?php if ($report['priority'] === 'urgent'): ?>
      <div class="bg-gradient-to-r from-red-50 to-red-100 border border-red-200 rounded-xl p-4">
        <div class="flex items-center">
          <div class="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center mr-3">
            <svg class="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
            </svg>
          </div>
          <div>
            <span class="text-red-800 font-bold text-lg">URGENT PRIORITY</span>
            <p class="text-red-700 text-sm">This report requires immediate attention</p>
          </div>
        </div>
      </div>
    <?php endif; ?>
  </div>

  <!-- Issue Details -->
  <div>
    <h3 class="text-lg font-semibold text-gray-900 mb-3">Issue Details</h3>
    <div class="space-y-3">
      <div>
        <span class="text-sm font-medium text-gray-600">Description:</span>
        <p class="text-gray-900 mt-1"><?php echo nl2br(htmlspecialchars($report['description'])); ?></p>
      </div>
      <div>
        <span class="text-sm font-medium text-gray-600">Issue Type:</span>
        <p class="text-gray-900"><?php echo ucfirst($report['issue_type'] ?? 'N/A'); ?></p>
      </div>
      <div>
        <span class="text-sm font-medium text-gray-600">Location:</span>
        <p class="text-gray-900"><?php echo htmlspecialchars($report['division']); ?>, <?php echo htmlspecialchars($report['district'] ?? ''); ?></p>
        <p class="text-gray-600 text-sm"><?php echo htmlspecialchars($report['location']); ?></p>
      </div>
    </div>
  </div>

  <!-- Reporter Information -->
  <div>
    <h3 class="text-lg font-semibold text-gray-900 mb-3">Reporter Information</h3>
    <div class="space-y-2">
      <div>
        <span class="text-sm font-medium text-gray-600">Name:</span>
        <p class="text-gray-900"><?php echo htmlspecialchars($report['reporter_name'] ?? 'N/A'); ?></p>
      </div>
      <div>
        <span class="text-sm font-medium text-gray-600">Email:</span>
        <p class="text-gray-900"><?php echo htmlspecialchars($report['reporter_email']); ?></p>
      </div>
      <div>
        <span class="text-sm font-medium text-gray-600">Phone:</span>
        <p class="text-gray-900"><?php echo htmlspecialchars($report['reporter_phone'] ?? 'N/A'); ?></p>
      </div>
      <div>
        <span class="text-sm font-medium text-gray-600">Reported:</span>
        <p class="text-gray-900"><?php echo date('M d, Y \a\t g:i A', strtotime($report['created_at'])); ?></p>
      </div>
    </div>
  </div>

  <!-- Assigned Crew -->
  <?php if ($report['crew_name']): ?>
    <div>
      <h3 class="text-lg font-semibold text-gray-900 mb-3">Assigned Work Crew</h3>
      <div class="bg-green-50 border border-green-200 rounded-lg p-4">
        <div class="space-y-2">
          <div>
            <span class="text-sm font-medium text-gray-600">Crew Name:</span>
            <p class="text-gray-900 font-medium"><?php echo htmlspecialchars($report['crew_name']); ?></p>
          </div>
          <div>
            <span class="text-sm font-medium text-gray-600">Division:</span>
            <p class="text-gray-900"><?php echo htmlspecialchars($report['crew_division'] ?? 'N/A'); ?></p>
          </div>
          <?php
          // Get crew details if needed
          $crewDetails = null;
          if ($report['assigned_crew_id']) {
            $workCrew = new WorkCrew();
            $crewDetails = $workCrew->getById($report['assigned_crew_id']);
          }
          ?>
          <?php if ($crewDetails): ?>
            <div>
              <span class="text-sm font-medium text-gray-600">Supervisor:</span>
              <p class="text-gray-900"><?php echo htmlspecialchars($crewDetails['supervisor_name']); ?></p>
            </div>
            <div>
              <span class="text-sm font-medium text-gray-600">Phone:</span>
              <p class="text-gray-900"><?php echo htmlspecialchars($crewDetails['supervisor_phone']); ?></p>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <!-- Cost Information -->
  <?php if ($report['estimated_cost'] || $report['actual_cost']): ?>
    <div>
      <h3 class="text-lg font-semibold text-gray-900 mb-3">Cost Information</h3>
      <div class="grid grid-cols-2 gap-4">
        <?php if ($report['estimated_cost']): ?>
          <div class="bg-green-50 border border-green-200 rounded-lg p-4">
            <span class="text-sm font-medium text-gray-600">Estimated Cost</span>
            <p class="text-2xl font-bold text-green-700">৳<?php echo number_format($report['estimated_cost']); ?></p>
          </div>
        <?php endif; ?>
        <?php if ($report['actual_cost']): ?>
          <div class="bg-green-50 border border-green-200 rounded-lg p-4">
            <span class="text-sm font-medium text-gray-600">Actual Cost</span>
            <p class="text-2xl font-bold text-green-700">৳<?php echo number_format($report['actual_cost']); ?></p>
          </div>
        <?php endif; ?>
      </div>
    </div>
  <?php endif; ?>

  <!-- Admin Notes -->
  <?php if ($report['admin_notes']): ?>
    <div>
      <h3 class="text-lg font-semibold text-gray-900 mb-3">Admin Notes</h3>
      <div class="bg-gray-50 border border-gray-200 rounded-lg p-4">
        <p class="text-gray-900"><?php echo nl2br(htmlspecialchars($report['admin_notes'])); ?></p>
        <?php if ($report['reviewer_name']): ?>
          <p class="text-sm text-gray-600 mt-2">Reviewed by <?php echo htmlspecialchars($report['reviewer_name']); ?> on <?php echo $report['approved_at'] ? date('M d, Y', strtotime($report['approved_at'])) : 'N/A'; ?></p>
        <?php endif; ?>
      </div>
    </div>
  <?php endif; ?>

  <!-- Timeline -->
  <div>
    <h3 class="text-lg font-semibold text-gray-900 mb-3">Timeline</h3>
    <div class="space-y-3">
      <div class="flex items-center">
        <div class="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
        <div>
          <p class="text-sm font-medium text-gray-900">Report Submitted</p>
          <p class="text-xs text-gray-600"><?php echo date('M d, Y g:i A', strtotime($report['created_at'])); ?></p>
        </div>
      </div>

      <?php if ($report['approved_at']): ?>
        <div class="flex items-center">
          <div class="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
          <div>
            <p class="text-sm font-medium text-gray-900">Report Approved</p>
            <p class="text-xs text-gray-600"><?php echo date('M d, Y g:i A', strtotime($report['approved_at'])); ?></p>
          </div>
        </div>
      <?php endif; ?>

      <?php if ($report['started_at']): ?>
        <div class="flex items-center">
          <div class="w-3 h-3 bg-orange-500 rounded-full mr-3"></div>
          <div>
            <p class="text-sm font-medium text-gray-900">Work Started</p>
            <p class="text-xs text-gray-600"><?php echo date('M d, Y g:i A', strtotime($report['started_at'])); ?></p>
          </div>
        </div>
      <?php endif; ?>

      <?php if ($report['completed_at']): ?>
        <div class="flex items-center">
          <div class="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
          <div>
            <p class="text-sm font-medium text-gray-900">Work Completed</p>
            <p class="text-xs text-gray-600"><?php echo date('M d, Y g:i A', strtotime($report['completed_at'])); ?></p>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Sticky Action Buttons -->
  <div class="sticky bottom-0 bg-white border-t border-gray-200 pt-4 pb-2 -mx-6 px-6 space-y-3">
    <div class="flex items-center justify-between mb-3">
      <h4 class="text-sm font-semibold text-gray-700">Quick Actions</h4>
      <div class="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
    </div>

    <!-- Review Report Button -->
    <div class="relative group">
      <button
        onclick="<?php echo $report['status'] === 'pending' ? 'openReviewModal(' . $report['id'] . ')' : ''; ?>"
        class="w-full px-4 py-3 rounded-xl font-medium transition-all duration-200 <?php echo $report['status'] === 'pending' ? 'bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white shadow-lg hover:shadow-xl transform hover:-translate-y-0.5' : 'bg-gray-100 text-gray-400 cursor-not-allowed'; ?>"
        <?php echo $report['status'] !== 'pending' ? 'disabled' : ''; ?>>
        <div class="flex items-center justify-center space-x-2">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <span>Review Report</span>
        </div>
      </button>
      <?php if ($report['status'] !== 'pending'): ?>
        <div class="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 bg-gray-900 text-white text-sm rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-10">
          Report must be in 'pending' status to review
          <div class="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-900"></div>
        </div>
      <?php endif; ?>
    </div>

    <!-- Assign Work Crew Button -->
    <div class="relative group">
      <button
        onclick="<?php echo ($report['status'] === 'approved' && !$report['crew_name']) ? 'openAssignModal(' . $report['id'] . ')' : ''; ?>"
        class="w-full px-4 py-3 rounded-xl font-medium transition-all duration-200 <?php echo ($report['status'] === 'approved' && !$report['crew_name']) ? 'bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white shadow-lg hover:shadow-xl transform hover:-translate-y-0.5' : 'bg-gray-100 text-gray-400 cursor-not-allowed'; ?>"
        <?php echo !($report['status'] === 'approved' && !$report['crew_name']) ? 'disabled' : ''; ?>>
        <div class="flex items-center justify-center space-x-2">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
          </svg>
          <span>Assign Work Crew</span>
        </div>
      </button>
      <?php if (!($report['status'] === 'approved' && !$report['crew_name'])): ?>
        <div class="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 bg-gray-900 text-white text-sm rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-10">
          <?php if ($report['status'] !== 'approved'): ?>
            Report must be 'approved' to assign crew
          <?php elseif ($report['crew_name']): ?>
            Crew already assigned: <?php echo htmlspecialchars($report['crew_name']); ?>
          <?php endif; ?>
          <div class="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-900"></div>
        </div>
      <?php endif; ?>
    </div>

    <!-- Update Status Button -->
    <div class="relative group">
      <button
        onclick="<?php echo ($report['status'] === 'approved' || $report['status'] === 'in_progress') ? 'openStatusModal(' . $report['id'] . ')' : ''; ?>"
        class="w-full px-4 py-3 rounded-xl font-medium transition-all duration-200 <?php echo ($report['status'] === 'approved' || $report['status'] === 'in_progress') ? 'bg-gradient-to-r from-green-700 to-green-800 hover:from-green-800 hover:to-green-900 text-white shadow-lg hover:shadow-xl transform hover:-translate-y-0.5' : 'bg-gray-100 text-gray-400 cursor-not-allowed'; ?>"
        <?php echo !($report['status'] === 'approved' || $report['status'] === 'in_progress') ? 'disabled' : ''; ?>>
        <div class="flex items-center justify-center space-x-2">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
          <span>Update Status</span>
        </div>
      </button>
      <?php if (!($report['status'] === 'approved' || $report['status'] === 'in_progress')): ?>
        <div class="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 bg-gray-900 text-white text-sm rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-10">
          Report must be 'approved' or 'in progress' to update status
          <div class="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-900"></div>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>