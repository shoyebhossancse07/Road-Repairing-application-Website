<?php

/**
 * Login Page
 * Handles user authentication
 */

require_once 'includes/auth.php';

$error = '';
$message = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $csrf_token = $_POST['csrf_token'] ?? '';

    // Verify CSRF token
    if (!verifyCSRFToken($csrf_token)) {
        $error = 'Invalid request. Please try again.';
    } else {
        // Validate input
        $errors = validateLoginData($email, $password);

        if (empty($errors)) {
            // Attempt authentication
            $user = authenticateUser($email, $password);

            if ($user) {
                // Redirect based on role
                if ($user['role'] === 'admin') {
                    header('Location: index.php?page=admin/dashboard');
                } else {
                    header('Location: index.php?page=dashboard');
                }
                exit;
            } else {
                $error = 'Invalid email or password.';
            }
        } else {
            $error = implode('<br>', $errors);
        }
    }
}

// Check for messages from other pages
if (isset($_GET['message'])) {
    switch ($_GET['message']) {
        case 'logged_out':
            $message = 'You have been successfully logged out.';
            break;
        case 'session_expired':
            $message = 'Your session has expired. Please log in again.';
            break;
        case 'registration_success':
            $message = 'Registration successful! Please log in with your credentials.';
            break;
    }
}

// Generate CSRF token
$csrf_token = generateCSRFToken();

// Start output buffering to capture content
ob_start();
?>

<div class="flex items-center justify-center min-h-screen p-4">
    <div class="w-full max-w-4xl bg-white rounded-2xl shadow-2xl overflow-hidden grid lg:grid-cols-2 animate-fade-in-up">
        <!-- Left Side - Branding -->
        <div class="bg-gradient-to-br from-emerald-600 to-green-800 p-8 lg:p-12 flex flex-col justify-center items-center text-center text-white relative overflow-hidden">
            <!-- Background Pattern -->
            <div class="absolute inset-0 opacity-10">
                <div class="absolute top-0 -left-4 w-72 h-72 bg-white rounded-full mix-blend-overlay filter blur-xl animate-pulse"></div>
                <div class="absolute bottom-0 -right-4 w-72 h-72 bg-white rounded-full mix-blend-overlay filter blur-xl animate-pulse delay-300"></div>
            </div>

            <div class="relative z-10">
                <div class="mb-8">
                    <div class="relative mb-6">
                        <div class="absolute inset-0 bg-white rounded-2xl opacity-20 blur-sm"></div>
                        <div class="relative bg-white bg-opacity-20 backdrop-blur-sm p-4 rounded-2xl border border-white border-opacity-30">
                            <svg class="h-12 w-12 mx-auto text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                            </svg>
                        </div>
                    </div>
                    <h2 class="text-3xl lg:text-4xl font-bold mb-3 text-white">Welcome Back</h2>
                    <p class="text-xl text-green-100 font-medium">Digital Road Repair Request System</p>
                </div>

                <div class="space-y-6 text-center">
                    <div class="bg-white bg-opacity-10 backdrop-blur-sm rounded-2xl p-6 border border-white border-opacity-20">
                        <div class="flex items-center justify-center mb-4">
                            <div class="text-4xl">🇧🇩</div>
                        </div>
                        <p class="text-lg font-semibold text-white mb-2">Serving Bangladesh</p>
                        <p class="text-green-100 text-sm leading-relaxed">Continue making roads better, one report at a time across all 8 divisions</p>
                    </div>

                    <div class="grid grid-cols-2 gap-4 text-sm">
                        <div class="bg-white bg-opacity-10 backdrop-blur-sm rounded-xl p-3 border border-white border-opacity-20">
                            <div class="text-2xl font-bold text-white">Secure</div>
                            <div class="text-green-100 text-xs">Login</div>
                        </div>
                        <div class="bg-white bg-opacity-10 backdrop-blur-sm rounded-xl p-3 border border-white border-opacity-20">
                            <div class="text-2xl font-bold text-white">24/7</div>
                            <div class="text-green-100 text-xs">Access</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Side - Login Form -->
        <div class="p-8 lg:p-12 flex flex-col justify-center bg-white">
            <div class="mb-8">
                <div class="flex items-center space-x-3 mb-4">
                    <div class="w-12 h-12 bg-gradient-to-br from-emerald-500 to-green-600 rounded-xl flex items-center justify-center">
                        <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                        </svg>
                    </div>
                    <div>
                        <h3 class="text-2xl lg:text-3xl font-bold text-gray-900">Welcome Back</h3>
                        <p class="text-emerald-600 font-medium">Continue your journey</p>
                    </div>
                </div>
                <p class="text-gray-600 leading-relaxed">Sign in to your account to access the dashboard and manage road reports</p>
            </div>

            <?php if ($error): ?>
                <div class="bg-red-50 border border-red-200 rounded-md p-4 mb-6">
                    <div class="flex">
                        <svg class="w-5 h-5 text-red-400" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
                        </svg>
                        <div class="ml-3">
                            <h3 class="text-sm font-medium text-red-800">Login Failed</h3>
                            <p class="text-sm text-red-700 mt-1"><?php echo htmlspecialchars($error); ?></p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ($message): ?>
                <div class="bg-green-50 border border-green-200 rounded-md p-4 mb-6">
                    <div class="flex">
                        <svg class="w-5 h-5 text-green-400" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                        </svg>
                        <div class="ml-3">
                            <h3 class="text-sm font-medium text-green-800">Success</h3>
                            <p class="text-sm text-green-700 mt-1"><?php echo htmlspecialchars($message); ?></p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Demo Credentials -->
            <div class="bg-green-50 border-l-4 border-green-400 p-4 mb-6 rounded-r-md">
                <div class="flex">
                    <svg class="w-5 h-5 text-green-400" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd" />
                    </svg>
                    <div class="ml-3">
                        <h3 class="text-sm font-medium text-green-800">Demo Credentials</h3>
                        <div class="text-sm text-green-700 mt-1">
                            <p><strong>Admin:</strong> admin@dhaka.gov.bd / admin123</p>
                            <p><strong>Citizen:</strong> sumaiya.arthy@gmail.com / citizen123</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Login Form -->
            <form method="POST" class="space-y-6">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">

                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required
                        class="w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200"
                        placeholder="Enter your email">
                </div>

                <div>
                    <label for="password" class="block text-sm font-medium text-gray-700 mb-1">Password</label>
                    <input type="password" id="password" name="password" required
                        class="w-full px-4 py-3 border border-gray-200 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200"
                        placeholder="Enter your password">
                </div>

                <div class="flex items-center justify-between">
                    <label class="flex items-center">
                        <input type="checkbox" name="remember" class="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded">
                        <span class="ml-2 text-sm text-gray-600">Remember me</span>
                    </label>
                </div>

                <button type="submit" class="w-full bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700 text-white font-semibold py-3 px-4 rounded-xl shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-300">
                    <span class="flex items-center justify-center">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                        </svg>
                        Sign In
                    </span>
                </button>
            </form>

            <div class="mt-8 text-center">
                <div class="relative">
                    <div class="absolute inset-0 flex items-center">
                        <div class="w-full border-t border-gray-300"></div>
                    </div>
                    <div class="relative flex justify-center text-sm">
                        <span class="px-2 bg-white text-gray-500">Need an account?</span>
                    </div>
                </div>

                <div class="mt-6">
                    <a href="index.php?page=register" class="inline-flex items-center justify-center w-full px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-medium rounded-xl shadow-sm hover:shadow-md transition-all duration-200">
                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
                        </svg>
                        Create New Account
                    </a>
                </div>

                <div class="mt-6 text-center">
                    <p class="text-sm text-gray-600">
                        Citizens can also report issues without registration
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Get the captured content
$content = ob_get_clean();

// Use centralized layout
require_once 'includes/layout.php';
renderPage('Login - DRRRS', $content);
?>