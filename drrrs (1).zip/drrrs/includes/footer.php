<?php
/**
 * Footer Component
 * Contains the footer content and closing body/html tags
 */

function renderFooter($additionalJS = [])
{
?>
    </main>

    <!-- Footer -->
    <footer class="bg-gray-900 text-white">
      <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          <!-- Brand Section -->
          <div class="lg:col-span-2">
            <div class="flex items-center space-x-3 mb-6">
              <div class="relative">
                <div class="absolute inset-0 bg-green-700 rounded-xl opacity-20 blur-sm"></div>
                <div class="relative bg-green-700 p-2 rounded-xl">
                  <svg class="h-8 w-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                  </svg>
                </div>
              </div>
              <span class="text-2xl font-bold text-green-700">DRRRS</span>
            </div>
            <p class="text-gray-300 text-lg leading-relaxed mb-6 max-w-md">
              Digital Road Repair Request System for Bangladesh. Building better infrastructure through citizen engagement and transparent governance.
            </p>
            <div class="flex space-x-4">
              <div class="text-center">
                <div class="text-2xl font-bold text-white">8</div>
                <div class="text-xs text-white">Divisions</div>
              </div>
              <div class="text-center">
                <div class="text-2xl font-bold text-white">24/7</div>
                <div class="text-xs text-white">Monitoring</div>
              </div>
              <div class="text-center">
                <div class="text-2xl font-bold text-white">999</div>
                <div class="text-xs text-white">Emergency</div>
              </div>
            </div>
          </div>

          <!-- Quick Links -->
          <div>
            <h6 class="text-lg font-semibold mb-6 text-gray-100">Quick Access</h6>
            <ul class="space-y-3">
              <li>
                <a href="index.php" class="group flex items-center text-gray-300 hover:text-green-400 transition-colors duration-200">
                  <svg class="w-4 h-4 mr-2 group-hover:scale-110 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                  </svg>
                  Home
                </a>
              </li>
              <li>
                <a href="index.php?page=report/create" class="group flex items-center text-gray-300 hover:text-green-400 transition-colors duration-200">
                  <svg class="w-4 h-4 mr-2 group-hover:scale-110 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Report Issue
                </a>
              </li>
              <li>
                <a href="index.php?page=report/track" class="group flex items-center text-gray-300 hover:text-green-400 transition-colors duration-200">
                  <svg class="w-4 h-4 mr-2 group-hover:scale-110 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                  Track Progress
                </a>
              </li>
              <?php if (isLoggedIn()): ?>
                <li>
                  <a href="index.php?page=dashboard" class="group flex items-center text-gray-300 hover:text-green-400 transition-colors duration-200">
                    <svg class="w-4 h-4 mr-2 group-hover:scale-110 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z" />
                    </svg>
                    Dashboard
                  </a>
                </li>
              <?php endif; ?>
            </ul>
          </div>

          <!-- Coverage Areas -->
          <div>
            <h6 class="text-lg font-semibold mb-6 text-gray-100">Coverage Areas</h6>
            <div class="grid grid-cols-2 gap-2 text-sm">
              <div class="flex items-center space-x-2">
                <div class="w-2 h-2 bg-green-400 rounded-full"></div>
                <span class="text-gray-300">Dhaka</span>
              </div>
              <div class="flex items-center space-x-2">
                <div class="w-2 h-2 bg-green-500 rounded-full"></div>
                <span class="text-gray-300">Chittagong</span>
              </div>
              <div class="flex items-center space-x-2">
                <div class="w-2 h-2 bg-green-600 rounded-full"></div>
                <span class="text-gray-300">Rajshahi</span>
              </div>
              <div class="flex items-center space-x-2">
                <div class="w-2 h-2 bg-green-700 rounded-full"></div>
                <span class="text-gray-300">Khulna</span>
              </div>
              <div class="flex items-center space-x-2">
                <div class="w-2 h-2 bg-green-800 rounded-full"></div>
                <span class="text-gray-300">Sylhet</span>
              </div>
              <div class="flex items-center space-x-2">
                <div class="w-2 h-2 bg-green-900 rounded-full"></div>
                <span class="text-gray-300">Barisal</span>
              </div>
              <div class="flex items-center space-x-2">
                <div class="w-2 h-2 bg-emerald-400 rounded-full"></div>
                <span class="text-gray-300">Rangpur</span>
              </div>
              <div class="flex items-center space-x-2">
                <div class="w-2 h-2 bg-emerald-500 rounded-full"></div>
                <span class="text-gray-300">Mymensingh</span>
              </div>
            </div>

            <div class="mt-6 p-4 bg-gray-800/50 rounded-xl border border-gray-700">
              <h6 class="text-sm font-medium text-gray-200 mb-2">Need Help?</h6>
              <p class="text-xs text-gray-400 mb-2">Contact support</p>
              <a href="mailto:info@drrrs.gov.bd" class="text-green-400 hover:text-green-300 text-xs font-medium transition-colors">
                info@drrrs.gov.bd
              </a>
            </div>
          </div>
        </div>

        <!-- Bottom Bar -->
        <div class="border-t border-gray-700/50 pt-8 mt-12">
          <div class="flex justify-start">
            <p class="text-gray-400 text-sm">
              &copy; <?= date('Y') ?> Digital Road Repair Request System.
            </p>
          </div>
        </div>
      </div>
    </footer>

    <!-- JavaScript -->
    <script>
      document.addEventListener("DOMContentLoaded", function() {
        // Mobile menu toggle
        const mobileMenuButton = document.querySelector(".mobile-menu-button");
        const mobileMenu = document.querySelector(".mobile-menu");

        if (mobileMenuButton && mobileMenu) {
          mobileMenuButton.addEventListener("click", function() {
            const isExpanded = mobileMenuButton.getAttribute("aria-expanded") === "true";
            mobileMenuButton.setAttribute("aria-expanded", !isExpanded);
            mobileMenu.classList.toggle("hidden");
          });
        }
      });
    </script>

    <!-- Additional JavaScript -->
    <?php foreach ($additionalJS as $js): ?>
      <script src="<?= htmlspecialchars($js) ?>"></script>
    <?php endforeach; ?>
  </body>

  </html>
<?php
}
?>
