<?php

/**
 * Division Model
 * Handles division data operations
 */

require_once __DIR__ . '/../database.php';

class Division
{
    private $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    /**
     * Get all divisions
     */
    public function getAll()
    {
        $sql = "SELECT * FROM divisions ORDER BY name";
        return $this->db->fetchAll($sql);
    }

    /**
     * Get division by ID
     */
    public function getById($id)
    {
        $sql = "SELECT * FROM divisions WHERE id = ?";
        return $this->db->fetch($sql, [$id]);
    }

    /**
     * Get division by name
     */
    public function getByName($name)
    {
        $sql = "SELECT * FROM divisions WHERE name = ?";
        return $this->db->fetch($sql, [$name]);
    }

    /**
     * Create new division
     */
    public function create($data)
    {
        $sql = "INSERT INTO divisions (
            name, name_bn, description, total_districts, created_at, updated_at
        ) VALUES (?, ?, ?, ?, NOW(), NOW())";

        $params = [
            $data['name'],
            $data['name_bn'],
            $data['description'] ?? null,
            $data['total_districts']
        ];

        if ($this->db->execute($sql, $params)) {
            return $this->db->lastInsertId();
        }
        return false;
    }

    /**
     * Update division
     */
    public function update($id, $data)
    {
        $setParts = [];
        $params = [];

        foreach ($data as $key => $value) {
            $setParts[] = "$key = ?";
            $params[] = $value;
        }

        $setParts[] = "updated_at = NOW()";
        $params[] = $id;

        $sql = "UPDATE divisions SET " . implode(", ", $setParts) . " WHERE id = ?";
        return $this->db->execute($sql, $params);
    }

    /**
     * Delete division
     */
    public function delete($id)
    {
        $sql = "DELETE FROM divisions WHERE id = ?";
        return $this->db->execute($sql, [$id]);
    }

    /**
     * Get division statistics
     */
    public function getStatistics($divisionName)
    {
        $sql = "SELECT 
                COUNT(*) as total_reports,
                COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_reports,
                COUNT(CASE WHEN status = 'approved' THEN 1 END) as approved_reports,
                COUNT(CASE WHEN status = 'in_progress' THEN 1 END) as in_progress_reports,
                COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_reports,
                COUNT(CASE WHEN priority = 'urgent' THEN 1 END) as urgent_reports,
                AVG(CASE WHEN status = 'completed' AND actual_cost IS NOT NULL THEN actual_cost END) as avg_cost
                FROM road_reports 
                WHERE division = ?";

        return $this->db->fetch($sql, [$divisionName]);
    }

    /**
     * Get work crews count by division
     */
    public function getWorkCrewsCount($divisionName)
    {
        $sql = "SELECT COUNT(*) as count FROM work_crews WHERE division = ? AND status = 'active'";
        $result = $this->db->fetch($sql, [$divisionName]);
        return $result ? $result['count'] : 0;
    }

    /**
     * Get divisions with report counts
     */
    public function getWithReportCounts()
    {
        $sql = "SELECT d.*, 
                COUNT(rr.id) as total_reports,
                COUNT(CASE WHEN rr.status = 'pending' THEN 1 END) as pending_reports,
                COUNT(CASE WHEN rr.status = 'urgent' THEN 1 END) as urgent_reports
                FROM divisions d
                LEFT JOIN road_reports rr ON d.name = rr.division
                GROUP BY d.id
                ORDER BY d.name";

        return $this->db->fetchAll($sql);
    }

    /**
     * Get division names for dropdown
     */
    public function getNamesForDropdown()
    {
        $divisions = $this->getAll();
        $options = [];

        foreach ($divisions as $division) {
            $options[$division['name']] = $division['name'];
        }

        return $options;
    }
}
