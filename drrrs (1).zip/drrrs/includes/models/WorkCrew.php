<?php

/**
 * WorkCrew Model
 * Handles work crew data operations
 */

require_once __DIR__ . '/../database.php';

class WorkCrew
{
    private $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    /**
     * Get all work crews
     */
    public function getAll($filters = [])
    {
        $sql = "SELECT * FROM work_crews";
        $conditions = [];
        $params = [];

        // Apply filters
        if (!empty($filters['status'])) {
            $conditions[] = "status = ?";
            $params[] = $filters['status'];
        }

        if (!empty($filters['division'])) {
            $conditions[] = "division = ?";
            $params[] = $filters['division'];
        }

        if (!empty($filters['specialization'])) {
            $conditions[] = "specialization LIKE ?";
            $params[] = '%' . $filters['specialization'] . '%';
        }

        if (!empty($conditions)) {
            $sql .= " WHERE " . implode(" AND ", $conditions);
        }

        $sql .= " ORDER BY name";

        return $this->db->fetchAll($sql, $params);
    }

    /**
     * Get active crews
     */
    public function getActive()
    {
        $sql = "SELECT * FROM work_crews WHERE status = 'active' ORDER BY name";
        return $this->db->fetchAll($sql);
    }

    /**
     * Get crew by ID
     */
    public function getById($id)
    {
        $sql = "SELECT * FROM work_crews WHERE id = ?";
        return $this->db->fetch($sql, [$id]);
    }

    /**
     * Get crews by division
     */
    public function getByDivision($division)
    {
        $sql = "SELECT * FROM work_crews WHERE division = ? AND status = 'active' ORDER BY name";
        return $this->db->fetchAll($sql, [$division]);
    }

    /**
     * Create new crew
     */
    public function create($data)
    {
        $sql = "INSERT INTO work_crews (
            name, specialization, division, description, team_size,
            supervisor_name, supervisor_phone, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";

        $params = [
            $data['name'],
            $data['specialization'],
            $data['division'],
            $data['description'] ?? null,
            $data['team_size'] ?? 5,
            $data['supervisor_name'],
            $data['supervisor_phone'],
            $data['status'] ?? 'active'
        ];

        if ($this->db->execute($sql, $params)) {
            return $this->db->lastInsertId();
        }
        return false;
    }

    /**
     * Update crew
     */
    public function update($id, $data)
    {
        $setParts = [];
        $params = [];

        foreach ($data as $key => $value) {
            $setParts[] = "$key = ?";
            $params[] = $value;
        }

        $setParts[] = "updated_at = NOW()";
        $params[] = $id;

        $sql = "UPDATE work_crews SET " . implode(", ", $setParts) . " WHERE id = ?";
        return $this->db->execute($sql, $params);
    }

    /**
     * Delete crew
     */
    public function delete($id)
    {
        $sql = "DELETE FROM work_crews WHERE id = ?";
        return $this->db->execute($sql, [$id]);
    }

    /**
     * Get crew workload (number of assigned reports)
     */
    public function getWorkload($crewId)
    {
        $sql = "SELECT COUNT(*) as count FROM road_reports 
                WHERE assigned_crew_id = ? AND status IN ('approved', 'in_progress')";
        $result = $this->db->fetch($sql, [$crewId]);
        return $result ? $result['count'] : 0;
    }

    /**
     * Get crews with their current workload
     */
    public function getWithWorkload()
    {
        $sql = "SELECT wc.*, 
                COUNT(rr.id) as current_workload
                FROM work_crews wc
                LEFT JOIN road_reports rr ON wc.id = rr.assigned_crew_id 
                    AND rr.status IN ('approved', 'in_progress')
                WHERE wc.status = 'active'
                GROUP BY wc.id
                ORDER BY wc.name";

        return $this->db->fetchAll($sql);
    }

    /**
     * Get crew statistics
     */
    public function getStatistics($crewId)
    {
        $sql = "SELECT 
                COUNT(*) as total_reports,
                COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_reports,
                COUNT(CASE WHEN status = 'in_progress' THEN 1 END) as in_progress_reports,
                AVG(CASE WHEN status = 'completed' AND actual_cost IS NOT NULL THEN actual_cost END) as avg_cost
                FROM road_reports 
                WHERE assigned_crew_id = ?";

        return $this->db->fetch($sql, [$crewId]);
    }

    /**
     * Get available crews for assignment (least busy crews first)
     */
    public function getAvailableForAssignment($division = null)
    {
        $sql = "SELECT wc.*, 
                COUNT(rr.id) as current_workload
                FROM work_crews wc
                LEFT JOIN road_reports rr ON wc.id = rr.assigned_crew_id 
                    AND rr.status IN ('approved', 'in_progress')
                WHERE wc.status = 'active'";

        $params = [];
        if ($division) {
            $sql .= " AND wc.division = ?";
            $params[] = $division;
        }

        $sql .= " GROUP BY wc.id ORDER BY current_workload ASC, wc.name";

        return $this->db->fetchAll($sql, $params);
    }

    /**
     * Get crews with pagination and sorting for admin page
     */
    public function getAdminCrews($sortBy = 'name', $sortOrder = 'asc', $page = 1, $perPage = 10)
    {
        $offset = ($page - 1) * $perPage;

        $sql = "SELECT * FROM work_crews";

        // Add sorting
        $allowedSortFields = ['name', 'specialization', 'division', 'team_size', 'supervisor_name', 'status'];
        if (in_array($sortBy, $allowedSortFields)) {
            $sql .= " ORDER BY {$sortBy} {$sortOrder}";
        } else {
            $sql .= " ORDER BY name ASC";
        }

        // Get total count for pagination
        $countSql = "SELECT COUNT(*) FROM work_crews";
        $totalCount = $this->db->fetch($countSql)['COUNT(*)'];

        // Add pagination
        $sql .= " LIMIT ? OFFSET ?";
        $params = [$perPage, $offset];

        $crews = $this->db->fetchAll($sql, $params);

        return [
            'data' => $crews,
            'total' => $totalCount,
            'per_page' => $perPage,
            'current_page' => $page,
            'last_page' => ceil($totalCount / $perPage),
            'from' => $totalCount > 0 ? $offset + 1 : 0,
            'to' => min($offset + $perPage, $totalCount)
        ];
    }

    /**
     * Get assigned reports for a crew
     */
    public function getAssignedReports($crewId)
    {
        $sql = "SELECT * FROM road_reports WHERE assigned_crew_id = ? ORDER BY created_at DESC";
        return $this->db->fetchAll($sql, [$crewId]);
    }
}
