<?php

/**
 * User Model
 * Handles user data operations
 */

require_once __DIR__ . '/../database.php';

class User
{
    private $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    /**
     * Get all users
     */
    public function getAll($limit = 10, $offset = 0, $filters = [])
    {
        $sql = "SELECT * FROM users";
        $conditions = [];
        $params = [];

        // Apply filters
        if (!empty($filters['role'])) {
            $conditions[] = "role = ?";
            $params[] = $filters['role'];
        }

        if (!empty($filters['email'])) {
            $conditions[] = "email LIKE ?";
            $params[] = '%' . $filters['email'] . '%';
        }

        if (!empty($conditions)) {
            $sql .= " WHERE " . implode(" AND ", $conditions);
        }

        $sql .= " ORDER BY created_at DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;

        return $this->db->fetchAll($sql, $params);
    }

    /**
     * Get user by ID
     */
    public function getById($id)
    {
        $sql = "SELECT * FROM users WHERE id = ?";
        return $this->db->fetch($sql, [$id]);
    }

    /**
     * Get user by email
     */
    public function getByEmail($email)
    {
        $sql = "SELECT * FROM users WHERE email = ?";
        return $this->db->fetch($sql, [$email]);
    }

    /**
     * Create new user
     */
    public function create($data)
    {
        $sql = "INSERT INTO users (
            name, email, password, role, created_at, updated_at
        ) VALUES (?, ?, ?, ?, NOW(), NOW())";

        $params = [
            $data['name'],
            $data['email'],
            $data['password'],
            $data['role'] ?? 'citizen'
        ];

        if ($this->db->execute($sql, $params)) {
            return $this->db->lastInsertId();
        }
        return false;
    }

    /**
     * Update user
     */
    public function update($id, $data)
    {
        $setParts = [];
        $params = [];

        foreach ($data as $key => $value) {
            $setParts[] = "$key = ?";
            $params[] = $value;
        }

        $setParts[] = "updated_at = NOW()";
        $params[] = $id;

        $sql = "UPDATE users SET " . implode(", ", $setParts) . " WHERE id = ?";
        return $this->db->execute($sql, $params);
    }

    /**
     * Delete user
     */
    public function delete($id)
    {
        $sql = "DELETE FROM users WHERE id = ?";
        return $this->db->execute($sql, [$id]);
    }

    /**
     * Authenticate user
     */
    public function authenticate($email, $password)
    {
        $user = $this->getByEmail($email);

        if ($user && password_verify($password, $user['password'])) {
            return $user;
        }

        return false;
    }

    /**
     * Get users count by role
     */
    public function getCountByRole()
    {
        $sql = "SELECT role, COUNT(*) as count FROM users GROUP BY role";
        $results = $this->db->fetchAll($sql);

        $counts = [
            'admin' => 0,
            'citizen' => 0
        ];

        foreach ($results as $result) {
            $counts[$result['role']] = $result['count'];
        }

        return $counts;
    }

    /**
     * Get recent users
     */
    public function getRecent($limit = 5)
    {
        $sql = "SELECT * FROM users ORDER BY created_at DESC LIMIT ?";
        return $this->db->fetchAll($sql, [$limit]);
    }

    /**
     * Get users with their report counts
     */
    public function getWithReportCounts()
    {
        $sql = "SELECT u.*, 
                COUNT(rr.id) as total_reports,
                COUNT(CASE WHEN rr.status = 'pending' THEN 1 END) as pending_reports
                FROM users u
                LEFT JOIN road_reports rr ON u.email = rr.reporter_email
                WHERE u.role = 'citizen'
                GROUP BY u.id
                ORDER BY u.created_at DESC";

        return $this->db->fetchAll($sql);
    }

    /**
     * Change password
     */
    public function changePassword($userId, $newPassword)
    {
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        return $this->update($userId, ['password' => $hashedPassword]);
    }

    /**
     * Check if email exists
     */
    public function emailExists($email, $excludeId = null)
    {
        $sql = "SELECT COUNT(*) as count FROM users WHERE email = ?";
        $params = [$email];

        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }

        $result = $this->db->fetch($sql, $params);
        return $result && $result['count'] > 0;
    }

    /**
     * Get users with pagination and sorting for admin page
     */
    public function getAdminUsers($sortBy = 'name', $sortOrder = 'asc', $page = 1, $perPage = 10)
    {
        $offset = ($page - 1) * $perPage;

        $sql = "SELECT * FROM users";

        // Add sorting
        $allowedSortFields = ['name', 'email', 'role', 'division', 'phone', 'created_at'];
        if (in_array($sortBy, $allowedSortFields)) {
            $sql .= " ORDER BY {$sortBy} {$sortOrder}";
        } else {
            $sql .= " ORDER BY name ASC";
        }

        // Get total count for pagination
        $countSql = "SELECT COUNT(*) FROM users";
        $totalCount = $this->db->fetch($countSql)['COUNT(*)'];

        // Add pagination
        $sql .= " LIMIT ? OFFSET ?";
        $params = [$perPage, $offset];

        $users = $this->db->fetchAll($sql, $params);

        return [
            'data' => $users,
            'total' => $totalCount,
            'per_page' => $perPage,
            'current_page' => $page,
            'last_page' => ceil($totalCount / $perPage),
            'from' => $totalCount > 0 ? $offset + 1 : 0,
            'to' => min($offset + $perPage, $totalCount)
        ];
    }

    /**
     * Create user with additional fields
     */
    public function createWithDetails($data)
    {
        $sql = "INSERT INTO users (
            name, email, password, role, phone, division, district, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";

        $params = [
            $data['name'],
            $data['email'],
            $data['password'],
            $data['role'] ?? 'citizen',
            $data['phone'] ?? null,
            $data['division'] ?? null,
            $data['district'] ?? null
        ];

        if ($this->db->execute($sql, $params)) {
            return $this->db->lastInsertId();
        }
        return false;
    }

    /**
     * Update user with additional fields
     */
    public function updateWithDetails($id, $data)
    {
        $setParts = [];
        $params = [];

        foreach ($data as $key => $value) {
            if ($key !== 'password' || !empty($value)) {
                $setParts[] = "$key = ?";
                $params[] = $value;
            }
        }

        $setParts[] = "updated_at = NOW()";
        $params[] = $id;

        $sql = "UPDATE users SET " . implode(", ", $setParts) . " WHERE id = ?";
        return $this->db->execute($sql, $params);
    }
}
