<?php

/**
 * RoadReport Model
 * Handles road report data operations
 */

require_once __DIR__ . '/../database.php';

class RoadReport
{
    private $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    /**
     * Get all road reports with pagination
     */
    public function getAll($limit = 10, $offset = 0, $filters = [])
    {
        $sql = "SELECT rr.*, wc.name as crew_name, u.name as reviewer_name 
                FROM road_reports rr 
                LEFT JOIN work_crews wc ON rr.assigned_crew_id = wc.id 
                LEFT JOIN users u ON rr.reviewed_by = u.id";

        $conditions = [];
        $params = [];

        // Apply filters
        if (!empty($filters['status'])) {
            $conditions[] = "rr.status = ?";
            $params[] = $filters['status'];
        }

        if (!empty($filters['priority'])) {
            $conditions[] = "rr.priority = ?";
            $params[] = $filters['priority'];
        }

        if (!empty($filters['division'])) {
            $conditions[] = "rr.division = ?";
            $params[] = $filters['division'];
        }

        if (!empty($filters['issue_type'])) {
            $conditions[] = "rr.issue_type = ?";
            $params[] = $filters['issue_type'];
        }

        if (!empty($conditions)) {
            $sql .= " WHERE " . implode(" AND ", $conditions);
        }

        $sql .= " ORDER BY rr.created_at DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;

        return $this->db->fetchAll($sql, $params);
    }

    /**
     * Get recent reports (for dashboard)
     */
    public function getRecent($limit = 5)
    {
        $sql = "SELECT * FROM road_reports ORDER BY created_at DESC LIMIT ?";
        return $this->db->fetchAll($sql, [$limit]);
    }

    /**
     * Get report by ID
     */
    public function getById($id)
    {
        $sql = "SELECT rr.*, wc.name as crew_name, u.name as reviewer_name 
                FROM road_reports rr 
                LEFT JOIN work_crews wc ON rr.assigned_crew_id = wc.id 
                LEFT JOIN users u ON rr.reviewed_by = u.id 
                WHERE rr.id = ?";
        return $this->db->fetch($sql, [$id]);
    }

    /**
     * Get report by report_id
     */
    public function getByReportId($reportId)
    {
        $sql = "SELECT rr.*, wc.name as crew_name, u.name as reviewer_name 
                FROM road_reports rr 
                LEFT JOIN work_crews wc ON rr.assigned_crew_id = wc.id 
                LEFT JOIN users u ON rr.reviewed_by = u.id 
                WHERE rr.report_id = ?";
        return $this->db->fetch($sql, [$reportId]);
    }

    /**
     * Create new report
     */
    public function create($data)
    {
        $sql = "INSERT INTO road_reports (
            report_id, title, description, issue_type, priority, status,
            division, district, upazila, location, detailed_location,
            latitude, longitude, reporter_name, reporter_email, reporter_phone,
            created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";

        $params = [
            $data['report_id'],
            $data['title'],
            $data['description'],
            $data['issue_type'],
            $data['priority'],
            $data['status'] ?? 'pending',
            $data['division'],
            $data['district'],
            $data['upazila'] ?? null,
            $data['location'],
            $data['detailed_location'] ?? null,
            $data['latitude'] ?? null,
            $data['longitude'] ?? null,
            $data['reporter_name'],
            $data['reporter_email'],
            $data['reporter_phone']
        ];

        if ($this->db->execute($sql, $params)) {
            return $this->db->lastInsertId();
        }
        return false;
    }

    /**
     * Update report
     */
    public function update($id, $data)
    {
        $setParts = [];
        $params = [];

        foreach ($data as $key => $value) {
            $setParts[] = "$key = ?";
            $params[] = $value;
        }

        $setParts[] = "updated_at = NOW()";
        $params[] = $id;

        $sql = "UPDATE road_reports SET " . implode(", ", $setParts) . " WHERE id = ?";
        return $this->db->execute($sql, $params);
    }

    /**
     * Delete report
     */
    public function delete($id)
    {
        $sql = "DELETE FROM road_reports WHERE id = ?";
        return $this->db->execute($sql, [$id]);
    }

    /**
     * Get reports count by status
     */
    public function getCountByStatus()
    {
        $sql = "SELECT status, COUNT(*) as count FROM road_reports GROUP BY status";
        $results = $this->db->fetchAll($sql);

        $counts = [
            'pending' => 0,
            'approved' => 0,
            'in_progress' => 0,
            'completed' => 0,
            'rejected' => 0
        ];

        foreach ($results as $result) {
            $counts[$result['status']] = $result['count'];
        }

        return $counts;
    }

    /**
     * Get reports count by priority
     */
    public function getCountByPriority()
    {
        $sql = "SELECT priority, COUNT(*) as count FROM road_reports GROUP BY priority";
        $results = $this->db->fetchAll($sql);

        $counts = [
            'low' => 0,
            'medium' => 0,
            'high' => 0,
            'urgent' => 0
        ];

        foreach ($results as $result) {
            $counts[$result['priority']] = $result['count'];
        }

        return $counts;
    }

    /**
     * Get statistics for dashboard
     */
    public function getStats()
    {
        $sql = "SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                    SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
                    SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress,
                    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                    SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected
                FROM road_reports";

        $result = $this->db->fetch($sql);

        return [
            'total' => $result['total'] ?? 0,
            'pending' => $result['pending'] ?? 0,
            'approved' => $result['approved'] ?? 0,
            'in_progress' => $result['in_progress'] ?? 0,
            'completed' => $result['completed'] ?? 0,
            'rejected' => $result['rejected'] ?? 0
        ];
    }

    /**
     * Count reports with filters
     */
    public function count($filters = [])
    {
        $sql = "SELECT COUNT(*) as count FROM road_reports";
        $conditions = [];
        $params = [];

        if (!empty($filters)) {
            foreach ($filters as $key => $value) {
                $conditions[] = "$key = ?";
                $params[] = $value;
            }

            if (!empty($conditions)) {
                $sql .= " WHERE " . implode(" AND ", $conditions);
            }
        }

        $result = $this->db->fetch($sql, $params);
        return $result ? $result['count'] : 0;
    }

    /**
     * Get total count of reports
     */
    public function getTotalCount()
    {
        $sql = "SELECT COUNT(*) as count FROM road_reports";
        $result = $this->db->fetch($sql);
        return $result ? $result['count'] : 0;
    }

    /**
     * Get count by specific status
     */
    public function getCountByStatusSingle($status)
    {
        $sql = "SELECT COUNT(*) as count FROM road_reports WHERE status = ?";
        $result = $this->db->fetch($sql, [$status]);
        return $result ? $result['count'] : 0;
    }

    /**
     * Get count by division
     */
    public function getCountByDivision()
    {
        $sql = "SELECT division, COUNT(*) as count FROM road_reports GROUP BY division";
        $results = $this->db->fetchAll($sql);

        $divisionStats = [];
        foreach ($results as $result) {
            $divisionStats[$result['division']] = $result['count'];
        }

        return $divisionStats;
    }

    /**
     * Get recent reports for dashboard
     */
    public function getRecentReports($limit = 5)
    {
        $sql = "SELECT * FROM road_reports ORDER BY created_at DESC LIMIT ?";
        return $this->db->fetchAll($sql, [$limit]);
    }

    /**
     * Get monthly report trends for charts
     */
    public function getMonthlyTrends($year = null)
    {
        if ($year === null) {
            $year = date('Y');
        }

        $sql = "SELECT 
                    MONTH(created_at) as month,
                    COUNT(*) as count
                FROM road_reports 
                WHERE YEAR(created_at) = ?
                GROUP BY MONTH(created_at)
                ORDER BY month";

        $results = $this->db->fetchAll($sql, [$year]);

        // Initialize all months with 0
        $monthlyData = array_fill(1, 12, 0);

        // Fill in actual data
        foreach ($results as $result) {
            $monthlyData[$result['month']] = $result['count'];
        }

        return array_values($monthlyData); // Return indexed array
    }

    /**
     * Get comprehensive status counts including all possible statuses
     */
    public function getAllStatusCounts()
    {
        $sql = "SELECT status, COUNT(*) as count FROM road_reports GROUP BY status";
        $results = $this->db->fetchAll($sql);

        $statusCounts = [
            'pending' => 0,
            'approved' => 0,
            'in_progress' => 0,
            'completed' => 0,
            'rejected' => 0
        ];

        foreach ($results as $result) {
            $statusCounts[$result['status']] = $result['count'];
        }

        return $statusCounts;
    }

    /**
     * Get priority distribution
     */
    public function getPriorityDistribution()
    {
        $sql = "SELECT priority, COUNT(*) as count FROM road_reports GROUP BY priority";
        $results = $this->db->fetchAll($sql);

        $priorityData = [];
        foreach ($results as $result) {
            $priorityData[$result['priority']] = $result['count'];
        }

        return $priorityData;
    }

    /**
     * Get reports with advanced filtering, sorting, and pagination for admin
     */
    public function getAdminReports($filters = [], $sortBy = 'created_at', $sortOrder = 'desc', $page = 1, $perPage = 15)
    {
        $offset = ($page - 1) * $perPage;

        $sql = "SELECT rr.*, wc.name as crew_name, wc.division as crew_division, u.name as reviewer_name 
                FROM road_reports rr 
                LEFT JOIN work_crews wc ON rr.assigned_crew_id = wc.id 
                LEFT JOIN users u ON rr.reviewed_by = u.id";

        $conditions = [];
        $params = [];

        // Apply filters
        if (!empty($filters['status'])) {
            $conditions[] = "rr.status = ?";
            $params[] = $filters['status'];
        }

        if (!empty($filters['division'])) {
            $conditions[] = "rr.division = ?";
            $params[] = $filters['division'];
        }

        if (!empty($filters['priority'])) {
            $conditions[] = "rr.priority = ?";
            $params[] = $filters['priority'];
        }

        if (!empty($filters['search'])) {
            $conditions[] = "(rr.report_id LIKE ? OR rr.title LIKE ? OR rr.location LIKE ? OR rr.reporter_name LIKE ?)";
            $searchTerm = '%' . $filters['search'] . '%';
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }

        if (!empty($conditions)) {
            $sql .= " WHERE " . implode(" AND ", $conditions);
        }

        // Add sorting
        $allowedSortFields = ['created_at', 'title', 'status', 'priority', 'division', 'estimated_cost', 'report_id'];
        if (in_array($sortBy, $allowedSortFields)) {
            $sql .= " ORDER BY rr.{$sortBy} {$sortOrder}";
        } else {
            $sql .= " ORDER BY rr.created_at DESC";
        }

        // Get total count for pagination
        $countSql = str_replace("SELECT rr.*, wc.name as crew_name, wc.division as crew_division, u.name as reviewer_name", "SELECT COUNT(*)", $sql);
        $countSql = preg_replace('/ORDER BY.*/', '', $countSql);
        $totalCount = $this->db->fetch($countSql, $params)['COUNT(*)'];

        // Add pagination
        $sql .= " LIMIT ? OFFSET ?";
        $params[] = $perPage;
        $params[] = $offset;

        $reports = $this->db->fetchAll($sql, $params);

        return [
            'data' => $reports,
            'total' => $totalCount,
            'per_page' => $perPage,
            'current_page' => $page,
            'last_page' => ceil($totalCount / $perPage),
            'from' => $totalCount > 0 ? $offset + 1 : 0,
            'to' => min($offset + $perPage, $totalCount)
        ];
    }

    /**
     * Update report review status
     */
    public function updateReview($id, $status, $adminNotes, $estimatedCost = null, $reviewedBy = null)
    {
        $sql = "UPDATE road_reports SET 
                status = ?, 
                admin_notes = ?, 
                estimated_cost = ?, 
                reviewed_by = ?,
                approved_at = ?,
                updated_at = NOW()
                WHERE id = ?";

        $approvedAt = ($status === 'approved') ? date('Y-m-d H:i:s') : null;

        return $this->db->execute($sql, [
            $status,
            $adminNotes,
            $estimatedCost,
            $reviewedBy,
            $approvedAt,
            $id
        ]);
    }

    /**
     * Assign crew to report
     */
    public function assignCrew($id, $crewId)
    {
        $sql = "UPDATE road_reports SET assigned_crew_id = ?, updated_at = NOW() WHERE id = ?";
        return $this->db->execute($sql, [$crewId, $id]);
    }

    /**
     * Update report status with optional actual cost
     */
    public function updateReportStatus($id, $status, $actualCost = null)
    {
        $updates = ['status = ?', 'updated_at = NOW()'];
        $params = [$status];

        if ($actualCost !== null) {
            $updates[] = 'actual_cost = ?';
            $params[] = $actualCost;
        }

        if ($status === 'in_progress') {
            $updates[] = 'started_at = NOW()';
        } elseif ($status === 'completed') {
            $updates[] = 'completed_at = NOW()';
        }

        $params[] = $id;

        $sql = "UPDATE road_reports SET " . implode(", ", $updates) . " WHERE id = ?";
        return $this->db->execute($sql, $params);
    }

    /**
     * Get reports by reporter email
     */
    public function getByEmail($email)
    {
        $sql = "SELECT rr.*, wc.name as crew_name 
                FROM road_reports rr 
                LEFT JOIN work_crews wc ON rr.assigned_crew_id = wc.id 
                WHERE rr.reporter_email = ? 
                ORDER BY rr.created_at DESC";

        return $this->db->fetchAll($sql, [$email]);
    }



    /**
     * Start work on report
     */
    public function startWork($reportId)
    {
        $sql = "UPDATE road_reports SET 
                status = 'in_progress', 
                started_at = NOW(),
                updated_at = NOW()
                WHERE id = ?";
        return $this->db->execute($sql, [$reportId]);
    }

    /**
     * Complete report
     */
    public function complete($reportId, $actualCost = null)
    {
        $sql = "UPDATE road_reports SET 
                status = 'completed', 
                completed_at = NOW(),
                updated_at = NOW()";

        $params = [$reportId];

        if ($actualCost !== null) {
            $sql .= ", actual_cost = ?";
            $params = [$actualCost, $reportId];
        }

        $sql .= " WHERE id = ?";
        return $this->db->execute($sql, $params);
    }

    /**
     * Get public reports for tracking (accessible without login)
     */
    public function getPublicReports($search = '', $status = '', $division = '', $priority = '')
    {
        $sql = "SELECT rr.*, wc.name as crew_name 
                FROM road_reports rr 
                LEFT JOIN work_crews wc ON rr.assigned_crew_id = wc.id";

        $conditions = [];
        $params = [];

        // Apply search filter
        if (!empty($search)) {
            $conditions[] = "(rr.report_id LIKE ? OR rr.title LIKE ? OR rr.location LIKE ? OR rr.district LIKE ?)";
            $searchTerm = "%$search%";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }

        // Apply status filter
        if (!empty($status)) {
            $conditions[] = "rr.status = ?";
            $params[] = $status;
        }

        // Apply division filter
        if (!empty($division)) {
            $conditions[] = "rr.division = ?";
            $params[] = $division;
        }

        // Apply priority filter
        if (!empty($priority)) {
            $conditions[] = "rr.priority = ?";
            $params[] = $priority;
        }

        // Add WHERE clause if conditions exist
        if (!empty($conditions)) {
            $sql .= " WHERE " . implode(" AND ", $conditions);
        }

        $sql .= " ORDER BY rr.created_at DESC";

        return $this->db->fetchAll($sql, $params);
    }

    /**
     * Generate unique report ID
     */
    public function generateReportId()
    {
        $prefix = 'RPT-' . date('Y') . '-';

        // Get the latest report ID for this year
        $sql = "SELECT report_id FROM road_reports 
                WHERE report_id LIKE ? 
                ORDER BY report_id DESC LIMIT 1";

        $latestReport = $this->db->fetch($sql, [$prefix . '%']);

        if ($latestReport) {
            // Extract number and increment
            $number = (int)substr($latestReport['report_id'], strlen($prefix));
            $number++;
        } else {
            $number = 1;
        }

        return $prefix . str_pad($number, 3, '0', STR_PAD_LEFT);
    }
}
