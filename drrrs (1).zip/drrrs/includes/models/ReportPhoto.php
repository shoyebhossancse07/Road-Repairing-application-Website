<?php

/**
 * ReportPhoto Model
 * Handles report photo data operations
 */

require_once __DIR__ . '/../database.php';

class ReportPhoto
{
    private $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    /**
     * Create new photo record
     */
    public function create($data)
    {
        $sql = "INSERT INTO report_photos (
            road_report_id, file_name, file_path, file_size, mime_type, description, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, NOW())";

        $params = [
            $data['report_id'],
            $data['file_name'] ?? basename($data['file_path']),
            $data['file_path'],
            $data['file_size'] ?? filesize($data['file_path']),
            $data['mime_type'] ?? mime_content_type($data['file_path']),
            $data['description'] ?? 'Report photo'
        ];

        if ($this->db->execute($sql, $params)) {
            return $this->db->lastInsertId();
        }
        return false;
    }

    /**
     * Get photos by report ID
     */
    public function getByReportId($reportId)
    {
        $sql = "SELECT * FROM report_photos WHERE road_report_id = ? ORDER BY created_at ASC";
        return $this->db->fetchAll($sql, [$reportId]);
    }

    /**
     * Get photo by ID
     */
    public function getById($id)
    {
        $sql = "SELECT * FROM report_photos WHERE id = ?";
        return $this->db->fetch($sql, [$id]);
    }

    /**
     * Delete photo
     */
    public function delete($id)
    {
        $photo = $this->getById($id);
        if ($photo && file_exists($photo['file_path'])) {
            unlink($photo['file_path']);
        }
        
        $sql = "DELETE FROM report_photos WHERE id = ?";
        return $this->db->execute($sql, [$id]);
    }

    /**
     * Delete all photos for a report
     */
    public function deleteByReportId($reportId)
    {
        $photos = $this->getByReportId($reportId);
        foreach ($photos as $photo) {
            if (file_exists($photo['file_path'])) {
                unlink($photo['file_path']);
            }
        }
        
        $sql = "DELETE FROM report_photos WHERE road_report_id = ?";
        return $this->db->execute($sql, [$reportId]);
    }
}
