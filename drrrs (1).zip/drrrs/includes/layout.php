<?php

/**
 * Centralized Layout System
 * Handles common HTML structure, headers, navigation, and footers
 */

// Include header and footer components
require_once __DIR__ . '/header.php';
require_once __DIR__ . '/footer.php';

function renderPage($title, $content, $additionalCSS = [], $additionalJS = [])
{
  renderHeader($title, $additionalCSS);
  echo $content;
  renderFooter($additionalJS);
}

function renderAdminHeader($title = 'DRRRS Admin', $additionalCSS = [])
{
  renderHeader($title, $additionalCSS);
}

function renderAdminPage($title, $content, $additionalCSS = [], $additionalJS = [])
{
  renderPage($title, $content, $additionalCSS, $additionalJS);
}
