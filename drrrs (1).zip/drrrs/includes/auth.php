<?php
/**
 * Authentication Functions
 * Handles user authentication and authorization
 */

require_once 'database.php';

/**
 * Authenticate user login
 */
function authenticateUser($email, $password) {
    global $db;
    
    $sql = "SELECT id, name, email, password, role FROM users WHERE email = ? LIMIT 1";
    $user = $db->fetch($sql, [$email]);
    
    if ($user && password_verify($password, $user['password'])) {
        // Set user session
        setUserSession($user);
        return $user;
    }
    
    return false;
}

/**
 * Register new user
 */
function registerUser($name, $email, $password, $role = 'citizen') {
    global $db;
    
    // Check if email already exists
    $existingUser = $db->fetch("SELECT id FROM users WHERE email = ?", [$email]);
    if ($existingUser) {
        return ['success' => false, 'message' => 'Email already exists'];
    }
    
    // Hash password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    // Insert user
    $sql = "INSERT INTO users (name, email, password, role, created_at, updated_at) VALUES (?, ?, ?, ?, NOW(), NOW())";
    $result = $db->execute($sql, [$name, $email, $hashedPassword, $role]);
    
    if ($result) {
        $userId = $db->lastInsertId();
        $user = [
            'id' => $userId,
            'name' => $name,
            'email' => $email,
            'role' => $role
        ];
        
        // Set user session
        setUserSession($user);
        
        return ['success' => true, 'user' => $user];
    }
    
    return ['success' => false, 'message' => 'Registration failed'];
}

/**
 * Get user by ID
 */
function getUserById($id) {
    global $db;
    
    $sql = "SELECT id, name, email, role, created_at, updated_at FROM users WHERE id = ?";
    return $db->fetch($sql, [$id]);
}

/**
 * Get user by email
 */
function getUserByEmail($email) {
    global $db;
    
    $sql = "SELECT id, name, email, role, created_at, updated_at FROM users WHERE email = ?";
    return $db->fetch($sql, [$email]);
}

/**
 * Update user
 */
function updateUser($id, $data) {
    global $db;
    
    $fields = [];
    $values = [];
    
    foreach ($data as $key => $value) {
        if (in_array($key, ['name', 'email', 'role'])) {
            $fields[] = "$key = ?";
            $values[] = $value;
        }
    }
    
    if (empty($fields)) {
        return false;
    }
    
    $values[] = $id;
    $sql = "UPDATE users SET " . implode(', ', $fields) . ", updated_at = NOW() WHERE id = ?";
    
    return $db->execute($sql, $values);
}

/**
 * Delete user
 */
function deleteUser($id) {
    global $db;
    
    $sql = "DELETE FROM users WHERE id = ?";
    return $db->execute($sql, [$id]);
}

/**
 * Change user password
 */
function changePassword($userId, $currentPassword, $newPassword) {
    global $db;
    
    // Get current user
    $user = $db->fetch("SELECT password FROM users WHERE id = ?", [$userId]);
    if (!$user) {
        return ['success' => false, 'message' => 'User not found'];
    }
    
    // Verify current password
    if (!password_verify($currentPassword, $user['password'])) {
        return ['success' => false, 'message' => 'Current password is incorrect'];
    }
    
    // Hash new password
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
    
    // Update password
    $sql = "UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?";
    $result = $db->execute($sql, [$hashedPassword, $userId]);
    
    if ($result) {
        return ['success' => true, 'message' => 'Password updated successfully'];
    }
    
    return ['success' => false, 'message' => 'Failed to update password'];
}

/**
 * Get all users (for admin)
 */
function getAllUsers($limit = null, $offset = 0) {
    global $db;
    
    $sql = "SELECT id, name, email, role, created_at, updated_at FROM users ORDER BY created_at DESC";
    
    if ($limit) {
        $sql .= " LIMIT ? OFFSET ?";
        return $db->fetchAll($sql, [$limit, $offset]);
    }
    
    return $db->fetchAll($sql);
}

/**
 * Count total users
 */
function countUsers() {
    global $db;
    
    $result = $db->fetch("SELECT COUNT(*) as count FROM users");
    return $result ? $result['count'] : 0;
}

/**
 * Validate email format
 */
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Validate password strength
 */
function validatePassword($password) {
    // At least 8 characters, 1 uppercase, 1 lowercase, 1 number
    return strlen($password) >= 8 && 
           preg_match('/[A-Z]/', $password) && 
           preg_match('/[a-z]/', $password) && 
           preg_match('/[0-9]/', $password);
}

/**
 * Sanitize user input
 */
function sanitizeInput($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * Validate registration data
 */
function validateRegistrationData($name, $email, $password, $confirmPassword) {
    $errors = [];
    
    if (empty($name) || strlen($name) < 2) {
        $errors[] = 'Name must be at least 2 characters long';
    }
    
    if (!validateEmail($email)) {
        $errors[] = 'Please enter a valid email address';
    }
    
    if (!validatePassword($password)) {
        $errors[] = 'Password must be at least 8 characters with uppercase, lowercase, and number';
    }
    
    if ($password !== $confirmPassword) {
        $errors[] = 'Passwords do not match';
    }
    
    return $errors;
}

/**
 * Validate login data
 */
function validateLoginData($email, $password) {
    $errors = [];
    
    if (empty($email)) {
        $errors[] = 'Email is required';
    }
    
    if (empty($password)) {
        $errors[] = 'Password is required';
    }
    
    return $errors;
}

/**
 * Get current user's name
 */
function getCurrentUserName() {
    if (isset($_SESSION['user_id'])) {
        $user = getUserById($_SESSION['user_id']);
        return $user ? $user['name'] : '';
    }
    return '';
}
