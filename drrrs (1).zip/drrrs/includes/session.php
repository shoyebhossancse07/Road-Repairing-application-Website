<?php

/**
 * Session Management Functions
 * Handles sessions, CSRF tokens, and security
 */

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Generate CSRF token
 */
function generateCSRFToken()
{
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF token
 */
function verifyCSRFToken($token)
{
    if (!isset($_SESSION['csrf_token'])) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Regenerate CSRF token
 */
function regenerateCSRFToken()
{
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf_token'];
}

/**
 * Set session data
 */
function setSession($key, $value)
{
    $_SESSION[$key] = $value;
}

/**
 * Get session data
 */
function getSession($key, $default = null)
{
    return $_SESSION[$key] ?? $default;
}

/**
 * Remove session data
 */
function removeSession($key)
{
    unset($_SESSION[$key]);
}

/**
 * Check if user is logged in
 */
function isLoggedIn()
{
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Get current user ID
 */
function getCurrentUserId()
{
    return $_SESSION['user_id'] ?? null;
}

/**
 * Get current user role
 */
function getCurrentUserRole()
{
    return $_SESSION['user_role'] ?? null;
}

/**
 * Check if user is admin
 */
function isAdmin()
{
    return getCurrentUserRole() === 'admin';
}

/**
 * Set user session
 */
function setUserSession($user)
{
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_role'] = $user['role'];
    $_SESSION['logged_in_at'] = time();
}

/**
 * Clear user session
 */
function clearUserSession()
{
    unset($_SESSION['user_id']);
    unset($_SESSION['user_name']);
    unset($_SESSION['user_email']);
    unset($_SESSION['user_role']);
    unset($_SESSION['logged_in_at']);
}

/**
 * Destroy session completely
 */
function destroySession()
{
    session_destroy();
    session_start();
}

/**
 * Check session timeout
 */
function checkSessionTimeout($timeout = 7200)
{ // 2 hours default
    if (isset($_SESSION['logged_in_at'])) {
        if (time() - $_SESSION['logged_in_at'] > $timeout) {
            clearUserSession();
            return false;
        }
        // Refresh session time
        $_SESSION['logged_in_at'] = time();
    }
    return true;
}

/**
 * Require authentication
 */
function requireAuth()
{
    if (!isLoggedIn()) {
        header('Location: index.php?page=login');
        exit;
    }

    if (!checkSessionTimeout()) {
        header('Location: index.php?page=login&message=session_expired');
        exit;
    }
}

/**
 * Require admin role
 */
function requireAdmin()
{
    requireAuth();

    if (!isAdmin()) {
        header('Location: index.php?page=dashboard&error=access_denied');
        exit;
    }
}

/**
 * Flash message functions
 */
function setFlashMessage($type, $message)
{
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message
    ];
}

function getFlashMessage()
{
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * Display flash message
 */
function displayFlashMessage()
{
    $flash = getFlashMessage();
    if ($flash) {
        $type = $flash['type'];
        $message = htmlspecialchars($flash['message']);

        $bgClass = 'bg-blue-100 border-blue-400 text-blue-700';
        if ($type === 'error') {
            $bgClass = 'bg-red-100 border-red-400 text-red-700';
        } elseif ($type === 'success') {
            $bgClass = 'bg-green-100 border-green-400 text-green-700';
        } elseif ($type === 'warning') {
            $bgClass = 'bg-yellow-100 border-yellow-400 text-yellow-700';
        }

        echo "<div class='$bgClass border px-4 py-3 rounded mb-4'>$message</div>";
    }
}

/**
 * Secure session configuration
 */
function secureSession()
{
    // Only set session parameters if session hasn't started yet
    if (session_status() === PHP_SESSION_NONE) {
        // Set secure session parameters
        ini_set('session.cookie_httponly', 1);
        ini_set('session.use_only_cookies', 1);
        ini_set('session.cookie_secure', isset($_SERVER['HTTPS']));
        ini_set('session.cookie_samesite', 'Strict');
    }

    // Regenerate session ID periodically
    if (!isset($_SESSION['last_regeneration'])) {
        $_SESSION['last_regeneration'] = time();
    } elseif (time() - $_SESSION['last_regeneration'] > 300) { // 5 minutes
        session_regenerate_id(true);
        $_SESSION['last_regeneration'] = time();
    }
}

// Initialize secure session
secureSession();
