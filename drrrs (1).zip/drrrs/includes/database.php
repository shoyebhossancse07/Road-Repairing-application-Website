<?php

/**
 * Database Connection Class
 * Handles database connections and basic operations
 */

class Database
{
    private $pdo;
    public $host;
    public $port;
    public $database;
    public $username;
    public $password;
    private $charset;
    private $lastError;

    public function __construct()
    {
        $this->host = config('database.host', 'localhost');
        $this->port = config('database.port', '3306');
        $this->database = config('database.database', 'drrs_db');
        $this->username = config('database.username', 'root');
        $this->password = config('database.password', '');
        $this->charset = config('database.charset', 'utf8mb4');
    }

    /**
     * Connect to database
     */
    public function connect()
    {
        try {
            $dsn = "mysql:host={$this->host};port={$this->port};charset={$this->charset}";
            $this->pdo = new PDO($dsn, $this->username, $this->password, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
            return true;
        } catch (PDOException $e) {
            $this->lastError = $e->getMessage();
            error_log("Database connection failed: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Connect to specific database
     */
    public function connectToDatabase($database = null)
    {
        try {
            $db = $database ?: $this->database;
            $dsn = "mysql:host={$this->host};port={$this->port};dbname={$db};charset={$this->charset}";
            $this->pdo = new PDO($dsn, $this->username, $this->password, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
            return true;
        } catch (PDOException $e) {
            $this->lastError = $e->getMessage();
            error_log("Database connection failed: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Test database connection
     */
    public function testConnection()
    {
        return $this->connect();
    }

    /**
     * Check if database exists
     */
    public function databaseExists($database = null)
    {
        $db = $database ?: $this->database;

        if (!$this->connect()) {
            return false;
        }

        try {
            $stmt = $this->pdo->prepare("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = ?");
            $stmt->execute([$db]);
            return $stmt->fetch() !== false;
        } catch (PDOException $e) {
            error_log("Database check failed: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Create database
     */
    public function createDatabase($database = null)
    {
        $db = $database ?: $this->database;

        if (!$this->connect()) {
            return false;
        }

        try {
            $this->pdo->exec("CREATE DATABASE IF NOT EXISTS `$db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            return true;
        } catch (PDOException $e) {
            error_log("Database creation failed: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get PDO instance
     */
    public function getPdo()
    {
        if (!$this->pdo) {
            $this->connectToDatabase();
        }
        return $this->pdo;
    }

    /**
     * Get last error message
     */
    public function getLastError()
    {
        return $this->lastError;
    }

    /**
     * Execute a query
     */
    public function query($sql, $params = [])
    {
        try {
            $pdo = $this->getPdo();
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            $this->lastError = $e->getMessage();
            error_log("Query failed: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Fetch all rows
     */
    public function fetchAll($sql, $params = [])
    {
        $stmt = $this->query($sql, $params);
        return $stmt ? $stmt->fetchAll() : [];
    }

    /**
     * Fetch single row
     */
    public function fetch($sql, $params = [])
    {
        $stmt = $this->query($sql, $params);
        return $stmt ? $stmt->fetch() : false;
    }

    /**
     * Execute insert/update/delete
     */
    public function execute($sql, $params = [])
    {
        $stmt = $this->query($sql, $params);
        if (!$stmt) {
            return false;
        }
        return $stmt->rowCount() > 0 || $stmt->rowCount() === 0; // Return true for successful execution even if no rows affected
    }

    /**
     * Get last insert ID
     */
    public function lastInsertId()
    {
        return $this->pdo ? $this->pdo->lastInsertId() : null;
    }

    /**
     * Check if table exists
     */
    public function tableExists($table)
    {
        try {
            $pdo = $this->getPdo();
            // Use direct query instead of prepared statement for SHOW TABLES
            $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
            $result = $stmt->fetch() !== false;
            error_log("Table $table exists: " . ($result ? 'true' : 'false'));
            return $result;
        } catch (PDOException $e) {
            error_log("Table check failed for $table: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get table structure
     */
    public function getTableStructure($table)
    {
        try {
            $pdo = $this->getPdo();
            $stmt = $pdo->prepare("DESCRIBE `$table`");
            $stmt->execute();
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("Table structure check failed: " . $e->getMessage());
            return [];
        }
    }
}

// Global database instance
$db = new Database();
