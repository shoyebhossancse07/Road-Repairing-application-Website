<?php
/**
 * Header Component
 * Contains the HTML head, navigation, and opening body tags
 */

function renderHeader($title = 'DRRRS - Digital Road Repair Request System', $additionalCSS = [])
{
?>
  <!DOCTYPE html>
  <html lang="en">

  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title) ?></title>

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Inter Font -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Custom Tailwind Configuration -->
    <script>
      tailwind.config = {
        theme: {
          extend: {
            fontFamily: {
              sans: ["Inter", "sans-serif"],
            },
            colors: {
              primary: {
                50: "#eff6ff",
                500: "#3b82f6",
                600: "#2563eb",
                700: "#1d4ed8",
                900: "#1e3a8a",
              },
            },
          },
        },
      };
    </script>

    <!-- Additional CSS -->
    <?php foreach ($additionalCSS as $css): ?>
      <link rel="stylesheet" href="<?= htmlspecialchars($css) ?>">
    <?php endforeach; ?>

    <style>
      .glass-nav {
        backdrop-filter: blur(10px);
        background: rgba(255, 255, 255, 0.95);
      }

      .gradient-bg {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      }

      @keyframes fadeInUp {
        from {
          opacity: 0;
          transform: translateY(20px);
        }

        to {
          opacity: 1;
          transform: translateY(0);
        }
      }

      .animate-fade-in-up {
        animation: fadeInUp 0.6s ease-out;
      }

      .animate-delay-100 {
        animation-delay: 0.1s;
      }

      .animate-delay-200 {
        animation-delay: 0.2s;
      }

      .animate-delay-300 {
        animation-delay: 0.3s;
      }
    </style>
  </head>

  <body class="font-sans bg-gray-50">
    <!-- Navigation -->
    <nav class="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-xl border-b border-gray-200/50 shadow-sm">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-20">
          <!-- Logo -->
          <div class="flex items-center space-x-3">
            <div class="relative">
              <div class="absolute inset-0 bg-green-700 rounded-xl opacity-20 blur-sm"></div>
              <div class="relative bg-green-700 p-2 rounded-xl">
                <svg class="h-8 w-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                </svg>
              </div>
            </div>
            <a href="<?= isLoggedIn() ? 'index.php?page=dashboard' : 'index.php' ?>" class="text-2xl font-bold text-green-700 hover:text-green-800 transition-all duration-200">
              DRRRS
            </a>
          </div>

          <!-- Desktop Navigation -->
          <div class="hidden md:block">
            <div class="flex items-center space-x-1">
              <?php if (isLoggedIn()): ?>
                <?php if (isAdmin()): ?>
                  <!-- Admin Navigation Links -->
                  <div class="flex items-center space-x-1 mr-6">
                    <a href="index.php?page=admin/dashboard" class="<?= ($_GET['page'] ?? '') === 'admin/dashboard' ? 'bg-green-50 text-green-700 border-green-200' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50' ?> px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 border">
                      Dashboard
                    </a>
                    <a href="index.php?page=admin/reports" class="<?= ($_GET['page'] ?? '') === 'admin/reports' ? 'bg-green-50 text-green-700 border-green-200' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50' ?> px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 border">
                      Reports
                    </a>
                    <a href="index.php?page=admin/crews" class="<?= ($_GET['page'] ?? '') === 'admin/crews' ? 'bg-green-50 text-green-700 border-green-200' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50' ?> px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 border">
                      Work Crews
                    </a>
                    <a href="index.php?page=admin/users" class="<?= ($_GET['page'] ?? '') === 'admin/users' ? 'bg-green-50 text-green-700 border-green-200' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50' ?> px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 border">
                      Users
                    </a>
                  </div>
                <?php else: ?>
                  <!-- Citizen Navigation Links -->
                  <div class="flex items-center space-x-1 mr-6">
                    <a href="index.php?page=dashboard" class="<?= ($_GET['page'] ?? '') === 'dashboard' ? 'bg-green-50 text-green-700 border-green-200' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50' ?> px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 border">
                      Dashboard
                    </a>
                    <a href="index.php?page=report/create" class="<?= ($_GET['page'] ?? '') === 'report/create' ? 'bg-green-50 text-green-700 border-green-200' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50' ?> px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 border">
                      Report Issue
                    </a>
                    <a href="index.php?page=report/track" class="<?= ($_GET['page'] ?? '') === 'report/track' ? 'bg-green-50 text-green-700 border-green-200' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50' ?> px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 border">
                      Track Progress
                    </a>
                  </div>
                <?php endif; ?>

                <!-- User Info & Logout -->
                <div class="flex items-center space-x-3">
                  <?php if (isAdmin()): ?>
                    <div class="flex items-center space-x-2 bg-green-50 border border-green-200 px-3 py-2 rounded-xl">
                      <div class="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span class="text-green-700 text-sm font-medium">Admin</span>
                    </div>
                  <?php else: ?>
                    <div class="flex items-center space-x-2 bg-green-50 border border-green-200 px-3 py-2 rounded-xl">
                      <div class="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span class="text-green-700 text-sm font-medium"><?= htmlspecialchars(substr(getCurrentUserName(), 0, 12)) ?></span>
                    </div>
                  <?php endif; ?>

                  <a href="index.php?page=logout" class="group flex items-center space-x-2 text-gray-600 hover:text-red-600 px-3 py-2 rounded-xl border border-gray-200 hover:border-red-200 hover:bg-red-50 transition-all duration-200">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                    </svg>
                    <span class="text-sm font-medium">Logout</span>
                  </a>
                </div>
              <?php else: ?>
                <!-- Guest Navigation -->
                <div class="flex items-center space-x-1">
                  <a href="index.php" class="<?= ($_GET['page'] ?? 'home') === 'home' ? 'bg-green-50 text-green-700 border-green-200' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50' ?> px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 border">
                    Home
                  </a>
                  <a href="index.php?page=report/create" class="<?= ($_GET['page'] ?? '') === 'report/create' ? 'bg-green-50 text-green-700 border-green-200' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50' ?> px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 border">
                    Report Issue
                  </a>
                  <a href="index.php?page=report/track" class="<?= ($_GET['page'] ?? '') === 'report/track' ? 'bg-green-50 text-green-700 border-green-200' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50' ?> px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 border">
                    Track Progress
                  </a>
                </div>

                <div class="flex items-center space-x-2 ml-6">
                  <a href="index.php?page=login" class="bg-green-600 hover:bg-green-700 text-white px-6 py-2.5 rounded-xl text-sm font-medium shadow-sm hover:shadow-md transition-all duration-200">
                    Get Started
                  </a>
                </div>
              <?php endif; ?>
            </div>
          </div>

          <!-- Mobile menu button -->
          <div class="md:hidden">
            <button type="button" class="mobile-menu-button p-2 rounded-xl text-gray-600 hover:text-gray-900 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-200" aria-expanded="false">
              <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      <!-- Mobile Navigation Menu -->
      <div class="mobile-menu hidden md:hidden bg-white/95 backdrop-blur-xl border-t border-gray-200/50 shadow-lg">
        <div class="px-4 py-4 space-y-3">
          <?php if (isLoggedIn()): ?>
            <!-- User Info -->
            <?php if (isAdmin()): ?>
              <div class="flex items-center space-x-2 bg-green-50 border border-green-200 px-3 py-2 rounded-xl mb-4">
                <div class="w-2 h-2 bg-green-500 rounded-full"></div>
                <span class="text-green-700 text-sm font-medium">Admin</span>
              </div>
            <?php else: ?>
              <div class="flex items-center space-x-2 bg-green-50 border border-green-200 px-3 py-2 rounded-xl mb-4">
                <div class="w-2 h-2 bg-green-500 rounded-full"></div>
                <span class="text-green-700 text-sm font-medium"><?= htmlspecialchars(getCurrentUserName()) ?></span>
              </div>
            <?php endif; ?>

            <?php if (isAdmin()): ?>
              <!-- Admin Navigation Links -->
              <a href="index.php?page=admin/dashboard" class="<?= ($_GET['page'] ?? '') === 'admin/dashboard' ? 'bg-green-50 text-green-700 border-green-200' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50' ?> px-4 py-3 rounded-xl text-base font-medium transition-all duration-200 border">
                Dashboard
              </a>
              <a href="index.php?page=admin/reports" class="<?= ($_GET['page'] ?? '') === 'admin/reports' ? 'bg-green-50 text-green-700 border-green-200' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50' ?> px-4 py-3 rounded-xl text-base font-medium transition-all duration-200 border">
                Reports
              </a>
              <a href="index.php?page=admin/crews" class="<?= ($_GET['page'] ?? '') === 'admin/crews' ? 'bg-green-50 text-green-700 border-green-200' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50' ?> px-4 py-3 rounded-xl text-base font-medium transition-all duration-200 border">
                Work Crews
              </a>
              <a href="index.php?page=admin/users" class="<?= ($_GET['page'] ?? '') === 'admin/users' ? 'bg-green-50 text-green-700 border-green-200' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50' ?> px-4 py-3 rounded-xl text-base font-medium transition-all duration-200 border">
                Users
              </a>
            <?php else: ?>
              <!-- Citizen Navigation Links -->
              <a href="index.php?page=dashboard" class="<?= ($_GET['page'] ?? '') === 'dashboard' ? 'bg-green-50 text-green-700 border-green-200' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50' ?> px-4 py-3 rounded-xl text-base font-medium transition-all duration-200 border">
                Dashboard
              </a>
              <a href="index.php?page=report/create" class="<?= ($_GET['page'] ?? '') === 'report/create' ? 'bg-green-50 text-green-700 border-green-200' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50' ?> px-4 py-3 rounded-xl text-base font-medium transition-all duration-200 border">
                Report Issue
              </a>
              <a href="index.php?page=report/track" class="<?= ($_GET['page'] ?? '') === 'report/track' ? 'bg-green-50 text-green-700 border-green-200' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50' ?> px-4 py-3 rounded-xl text-base font-medium transition-all duration-200 border">
                Track Progress
              </a>
            <?php endif; ?>

            <a href="index.php?page=logout" class="w-full flex items-center space-x-3 text-gray-600 hover:text-red-600 px-4 py-3 rounded-xl border border-gray-200 hover:border-red-200 hover:bg-red-50 transition-all duration-200">
              <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
              </svg>
              <span class="text-base font-medium">Logout</span>
            </a>
          <?php else: ?>
            <!-- Guest Navigation -->
            <a href="index.php" class="<?= ($_GET['page'] ?? 'home') === 'home' ? 'bg-green-50 text-green-700 border-green-200' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50' ?> flex items-center space-x-3 px-4 py-3 rounded-xl text-base font-medium transition-all duration-200 border">
              <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
              </svg>
              <span>Home</span>
            </a>
            <a href="index.php?page=report/create" class="<?= ($_GET['page'] ?? '') === 'report/create' ? 'bg-green-50 text-green-700 border-green-200' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50' ?> flex items-center space-x-3 px-4 py-3 rounded-xl text-base font-medium transition-all duration-200 border">
              <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span>Report Issue</span>
            </a>
            <a href="index.php?page=report/track" class="<?= ($_GET['page'] ?? '') === 'report/track' ? 'bg-green-50 text-green-700 border-green-200' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50' ?> flex items-center space-x-3 px-4 py-3 rounded-xl text-base font-medium transition-all duration-200 border">
              <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
              </svg>
              <span>Track Progress</span>
            </a>

            <div class="mt-4 pt-4 border-t border-gray-200">
              <a href="index.php?page=login" class="block text-center bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-xl text-base font-medium shadow-sm hover:shadow-md transition-all duration-200">
                Get Started
              </a>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </nav>

    <!-- Main Content -->
    <main>
      <?php
      // Display flash messages
      displayFlashMessage();
      ?>
    <?php
  }
?>
