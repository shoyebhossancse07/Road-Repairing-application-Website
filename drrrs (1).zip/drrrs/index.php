<?php

/**
 * DRRRS Main Entry Point
 * Handles routing and application initialization
 */

// Load configuration
require_once 'config.php';
require_once 'includes/database.php';
require_once 'includes/session.php';

// Set security headers
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');

// Check if database is configured and accessible
$db = new Database();
$databaseExists = $db->databaseExists();
// We don't require database_config.php anymore since config.php has defaults
$databaseConfigExists = true; // Always true since we use defaults from config.php

// Check if all required tables exist
$requiredTables = ['users', 'divisions', 'work_crews', 'road_reports', 'report_photos'];
$allTablesExist = true;

if ($databaseExists) {
    // Connect to the database to check tables
    if ($db->connectToDatabase()) {
        foreach ($requiredTables as $table) {
            if (!$db->tableExists($table)) {
                $allTablesExist = false;
                error_log("Table missing: $table");
                break;
            }
        }
    } else {
        $allTablesExist = false;
        error_log("Failed to connect to database for table check");
    }
} else {
    $allTablesExist = false;
    error_log("Database does not exist");
}

// Debug logging
error_log("Database exists: " . ($databaseExists ? 'true' : 'false'));
error_log("All tables exist: " . ($allTablesExist ? 'true' : 'false'));
error_log("Database config exists: " . ($databaseConfigExists ? 'true' : 'false'));

// If database is not configured or tables don't exist, redirect to installation
if (!$databaseConfigExists || !$databaseExists || !$allTablesExist) {
    // Only redirect if we're not already on install page
    if (!isset($_GET['page']) || $_GET['page'] !== 'install') {
        header('Location: install.php');
        exit;
    }
}

// If database exists with all tables and we're trying to access install page, redirect to home
if ($databaseExists && $allTablesExist && isset($_GET['page']) && $_GET['page'] === 'install') {
    header('Location: index.php');
    exit;
}

// Get the requested page
$page = $_GET['page'] ?? 'home';

// Define allowed pages
$publicPages = ['home', 'login', 'register', 'install', 'report/create', 'report/show', 'report/track'];
$authPages = ['dashboard', 'logout'];
$adminPages = ['admin/dashboard', 'admin/reports', 'admin/crews', 'admin/users'];

// Check if page requires authentication
if (!in_array($page, $publicPages) && !isLoggedIn()) {
    header('Location: index.php?page=login');
    exit;
}

// Check if page requires admin role
if (in_array($page, $adminPages) && !isAdmin()) {
    header('Location: index.php?page=dashboard&error=access_denied');
    exit;
}

// Handle logout
if ($page === 'logout') {
    clearUserSession();
    header('Location: index.php?page=login&message=logged_out');
    exit;
}

// Map page to file
$pageMap = [
    'home' => 'pages/home.php',
    'login' => 'pages/login.php',
    'register' => 'pages/register.php',
    'dashboard' => 'pages/dashboard.php',
    'report/create' => 'pages/report/create.php',
    'report/show' => 'pages/report/show.php',
    'report/track' => 'pages/report/track.php',
    'admin/dashboard' => 'pages/admin/dashboard.php',
    'admin/reports' => 'pages/admin/reports.php',
    'admin/crews' => 'pages/admin/crews.php',
    'admin/users' => 'pages/admin/users.php'
];

// Get the file to include
$fileToInclude = $pageMap[$page] ?? 'pages/home.php';

// Check if file exists
if (!file_exists($fileToInclude)) {
    http_response_code(404);
    $fileToInclude = 'pages/404.php';
}

// Include the page
include $fileToInclude;
