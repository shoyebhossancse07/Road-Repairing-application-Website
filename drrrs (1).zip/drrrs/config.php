<?php

/**
 * DRRRS Configuration File
 * Database and application settings
 */

// Error reporting for development
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Application settings
define('APP_NAME', 'DRRRS - Digital Road Repair Request System');
define('APP_URL', 'http://localhost/drrs');
define('APP_VERSION', '1.0.0');

// Database configuration
$config = [
    'database' => [
        'host' => 'localhost',
        'port' => '3306',
        'database' => 'drrs_db',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'driver' => 'mysql'
    ],
    'upload' => [
        'max_size' => 5242880, // 5MB
        'allowed_types' => ['jpg', 'jpeg', 'png', 'gif'],
        'upload_path' => 'uploads/'
    ],
    'session' => [
        'lifetime' => 7200, // 2 hours
        'path' => '/',
        'domain' => '',
        'secure' => false,
        'httponly' => true
    ]
];

// Load database config from file if exists (optional)
$config_file = __DIR__ . '/database_config.php';
if (file_exists($config_file)) {
    $db_config = include $config_file;
    $config['database'] = array_merge($config['database'], $db_config);
}

// Helper function to get config values
function config($key, $default = null)
{
    global $config;
    $keys = explode('.', $key);
    $value = $config;

    foreach ($keys as $k) {
        if (isset($value[$k])) {
            $value = $value[$k];
        } else {
            return $default;
        }
    }

    return $value;
}

// Helper function to save database config (optional - only if we can write to the directory)
function saveDatabaseConfig($host, $port, $username, $password, $database)
{
    $config_file = __DIR__ . '/database_config.php';

    // Only try to save if the directory is writable
    if (is_writable(__DIR__)) {
        $config_content = "<?php\nreturn [\n";
        $config_content .= "    'host' => '$host',\n";
        $config_content .= "    'port' => '$port',\n";
        $config_content .= "    'username' => '$username',\n";
        $config_content .= "    'password' => '$password',\n";
        $config_content .= "    'database' => '$database',\n";
        $config_content .= "];\n";

        $result = file_put_contents($config_file, $config_content);
        return $result !== false;
    }

    // If we can't write, just return true - the app will use the default config
    return true;
}
