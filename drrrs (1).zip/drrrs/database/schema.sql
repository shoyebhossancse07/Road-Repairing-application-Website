-- DRRRS Database Schema
-- Digital Road Repair Request System

-- Create users table
CREATE TABLE `users` (
    `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` varchar(255) NOT NULL,
    `email` varchar(255) NOT NULL UNIQUE,
    `email_verified_at` timestamp NULL DEFAULT NULL,
    `password` varchar(255) NOT NULL,
    `role` enum('admin','citizen') NOT NULL DEFAULT 'citizen',
    `phone` varchar(255) DEFAULT NULL,
    `division` varchar(255) DEFAULT NULL,
    `district` varchar(255) DEFAULT NULL,
    `remember_token` varchar(100) DEFAULT NULL,
    `created_at` timestamp NULL DEFAULT NULL,
    `updated_at` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create divisions table
CREATE TABLE `divisions` (
    `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` varchar(255) NOT NULL,
    `name_bn` varchar(255) NOT NULL,
    `description` text DEFAULT NULL,
    `total_districts` int(11) NOT NULL,
    `created_at` timestamp NULL DEFAULT NULL,
    `updated_at` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create work_crews table
CREATE TABLE `work_crews` (
    `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` varchar(255) NOT NULL,
    `specialization` varchar(255) NOT NULL,
    `division` varchar(255) NOT NULL,
    `description` text DEFAULT NULL,
    `team_size` int(11) NOT NULL DEFAULT 5,
    `supervisor_name` varchar(255) NOT NULL,
    `supervisor_phone` varchar(255) NOT NULL,
    `status` enum('active','inactive','maintenance') NOT NULL DEFAULT 'active',
    `created_at` timestamp NULL DEFAULT NULL,
    `updated_at` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create road_reports table
CREATE TABLE `road_reports` (
    `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    `report_id` varchar(255) NOT NULL UNIQUE,
    `title` varchar(255) NOT NULL,
    `description` text NOT NULL,
    `issue_type` enum('pothole','crack','debris','lighting','signage','other') NOT NULL,
    `priority` enum('low','medium','high','urgent') NOT NULL,
    `status` enum('pending','approved','in_progress','completed','rejected') NOT NULL DEFAULT 'pending',
    `division` varchar(255) NOT NULL,
    `district` varchar(255) NOT NULL,
    `upazila` varchar(255) DEFAULT NULL,
    `location` varchar(255) NOT NULL,
    `detailed_location` text DEFAULT NULL,
    `latitude` decimal(10,8) DEFAULT NULL,
    `longitude` decimal(11,8) DEFAULT NULL,
    `reporter_name` varchar(255) NOT NULL,
    `reporter_email` varchar(255) NOT NULL,
    `reporter_phone` varchar(255) NOT NULL,
    `estimated_cost` decimal(12,2) DEFAULT NULL,
    `actual_cost` decimal(12,2) DEFAULT NULL,
    `assigned_crew_id` bigint(20) UNSIGNED DEFAULT NULL,
    `reviewed_by` bigint(20) UNSIGNED DEFAULT NULL,
    `approved_at` timestamp NULL DEFAULT NULL,
    `started_at` timestamp NULL DEFAULT NULL,
    `completed_at` timestamp NULL DEFAULT NULL,
    `admin_notes` text DEFAULT NULL,
    `created_at` timestamp NULL DEFAULT NULL,
    `updated_at` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `road_reports_assigned_crew_id_foreign` (`assigned_crew_id`),
    KEY `road_reports_reviewed_by_foreign` (`reviewed_by`),
    KEY `road_reports_status_priority_index` (`status`, `priority`),
    KEY `road_reports_division_district_index` (`division`, `district`),
    KEY `road_reports_created_at_index` (`created_at`),
    CONSTRAINT `road_reports_assigned_crew_id_foreign` FOREIGN KEY (`assigned_crew_id`) REFERENCES `work_crews` (`id`) ON DELETE SET NULL,
    CONSTRAINT `road_reports_reviewed_by_foreign` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create report_photos table
CREATE TABLE `report_photos` (
    `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    `report_id` bigint(20) UNSIGNED NOT NULL,
    `filename` varchar(255) NOT NULL,
    `original_name` varchar(255) NOT NULL,
    `file_path` varchar(255) NOT NULL,
    `file_size` int(11) NOT NULL,
    `mime_type` varchar(100) NOT NULL,
    `created_at` timestamp NULL DEFAULT NULL,
    `updated_at` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `report_photos_report_id_foreign` (`report_id`),
    CONSTRAINT `report_photos_report_id_foreign` FOREIGN KEY (`report_id`) REFERENCES `road_reports` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create cache table (for Laravel compatibility)
CREATE TABLE `cache` (
    `key` varchar(255) NOT NULL,
    `value` longtext NOT NULL,
    `expiration` int(11) NOT NULL,
    PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create jobs table (for Laravel compatibility)
CREATE TABLE `jobs` (
    `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    `queue` varchar(255) NOT NULL,
    `payload` longtext NOT NULL,
    `attempts` tinyint(3) UNSIGNED NOT NULL,
    `reserved_at` int(10) UNSIGNED DEFAULT NULL,
    `available_at` int(10) UNSIGNED NOT NULL,
    `created_at` int(10) UNSIGNED NOT NULL,
    PRIMARY KEY (`id`),
    KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
