-- DRRRS Seed Data
-- Digital Road Repair Request System

-- Seed Divisions (from DivisionSeeder)
INSERT INTO divisions (name, name_bn, description, total_districts, created_at, updated_at) VALUES 
('Dhaka', 'ঢাকা', 'Capital division including Dhaka metropolitan area', 13, NOW(), NOW()),
('Chittagong', 'চট্টগ্রাম', 'Commercial capital and port city division', 11, NOW(), NOW()),
('Rajshahi', 'রাজশাহী', 'Educational hub and silk city division', 8, NOW(), NOW()),
('Khulna', 'খুলনা', 'Industrial and shrimp capital division', 10, NOW(), NOW()),
('Sylhet', 'সিলেট', 'Tea capital and spiritual division', 4, NOW(), NOW()),
('Barisal', 'বরিশাল', 'Rice bowl and river delta division', 6, NOW(), NOW()),
('Rangpur', 'রংপুর', 'Agricultural and northern division', 8, NOW(), NOW()),
('Mymensingh', 'ময়মনসিংহ', 'Educational and agricultural division', 4, NOW(), NOW());

-- Seed Users (from UserSeeder)
INSERT INTO users (name, email, password, role, phone, division, district, created_at, updated_at) VALUES 
-- Admin users (password: admin123)
('Admin Dhaka', 'admin@dhaka.gov.bd', '$2y$12$DtnHvCp8iYQ/h7zrK8.tG.JLr02s9RGz2ARmHB/jdXLsaJma2kKra', 'admin', '01911111111', 'Dhaka', 'Dhaka', NOW(), NOW()),
('Admin Chittagong', 'admin@chittagong.gov.bd', '$2y$12$DtnHvCp8iYQ/h7zrK8.tG.JLr02s9RGz2ARmHB/jdXLsaJma2kKra', 'admin', '01922222222', 'Chittagong', 'Chittagong', NOW(), NOW()),
-- Citizen users (password: citizen123)
('Sumaiya Akter Rothy', 'sumaiya.arthy@gmail.com', '$2y$12$vodIZuvPn.MWjd89h77VMeIKEeAeFyBAwQECHSHU8uUGtzgdG3QdO', 'citizen', '01711000001', 'Dhaka', 'Dhaka', NOW(), NOW()),
('Fatima Khatun', 'fatima@gmail.com', '$2y$12$vodIZuvPn.MWjd89h77VMeIKEeAeFyBAwQECHSHU8uUGtzgdG3QdO', 'citizen', '01711000002', 'Dhaka', 'Dhaka', NOW(), NOW()),
('Mohammad Ali', 'ali@gmail.com', '$2y$12$vodIZuvPn.MWjd89h77VMeIKEeAeFyBAwQECHSHU8uUGtzgdG3QdO', 'citizen', '01722000001', 'Chittagong', 'Chittagong', NOW(), NOW()),
('Rashida Begum', 'rashida@gmail.com', '$2y$12$vodIZuvPn.MWjd89h77VMeIKEeAeFyBAwQECHSHU8uUGtzgdG3QdO', 'citizen', '01733000001', 'Rajshahi', 'Rajshahi', NOW(), NOW()),
('Karim Uddin', 'karim@gmail.com', '$2y$12$vodIZuvPn.MWjd89h77VMeIKEeAeFyBAwQECHSHU8uUGtzgdG3QdO', 'citizen', '01744000001', 'Khulna', 'Khulna', NOW(), NOW()),
('Nasreen Akter', 'nasreen@gmail.com', '$2y$12$vodIZuvPn.MWjd89h77VMeIKEeAeFyBAwQECHSHU8uUGtzgdG3QdO', 'citizen', '01755000001', 'Sylhet', 'Sylhet', NOW(), NOW());

-- Seed Work Crews (from WorkCrewSeeder)
INSERT INTO work_crews (name, specialization, division, description, team_size, supervisor_name, supervisor_phone, status, created_at, updated_at) VALUES 
('Dhaka Road Repair Team Alpha', 'Pothole Repair & Road Maintenance', 'Dhaka', 'Specialized team for road surface repairs in Dhaka metropolitan area', 8, 'Md. Aminul Islam', '01911111111', 'active', NOW(), NOW()),
('Dhaka Emergency Response Unit', 'Emergency Road Repairs', 'Dhaka', 'Quick response team for urgent road repairs and traffic safety', 6, 'Shahidul Rahman', '01911111112', 'active', NOW(), NOW()),
('Chittagong Port Road Maintenance', 'Heavy Duty Road Repairs', 'Chittagong', 'Heavy equipment team for port area and industrial road repairs', 10, 'Abdul Karim', '01922222222', 'active', NOW(), NOW()),
('Chittagong Hill Track Team', 'Hill Road & Bridge Repairs', 'Chittagong', 'Specialized team for hilly terrain road maintenance', 7, 'Nur Mohammad', '01922222223', 'active', NOW(), NOW()),
('Rajshahi Highway Maintenance', 'Highway & Main Road Repairs', 'Rajshahi', 'Team focused on major highways and connecting roads', 9, 'Rafiqul Alam', '01933333333', 'active', NOW(), NOW()),
('Khulna Coastal Road Team', 'Coastal Road & Bridge Maintenance', 'Khulna', 'Specialized in coastal area road repairs and salt water damage', 8, 'Jahangir Hossain', '01944444444', 'active', NOW(), NOW()),
('Sylhet Tea Garden Road Team', 'Rural Road Maintenance', 'Sylhet', 'Focused on tea garden access roads and rural connectivity', 6, 'Mizanur Rahman', '01955555555', 'active', NOW(), NOW()),
('Barisal River Delta Team', 'Waterlogged Area Road Repairs', 'Barisal', 'Expert team for flood-prone and delta region road maintenance', 7, 'Abdur Rashid', '01966666666', 'active', NOW(), NOW()),
('Rangpur Agricultural Road Unit', 'Agricultural Road Maintenance', 'Rangpur', 'Maintaining roads crucial for agricultural transportation', 6, 'Mokbul Hossain', '01977777777', 'active', NOW(), NOW()),
('Mymensingh University Area Team', 'Educational Zone Road Maintenance', 'Mymensingh', 'Focused on roads around educational institutions and residential areas', 5, 'Nazrul Islam', '01988888888', 'active', NOW(), NOW());

-- Seed Road Reports (from RoadReportSeeder)
INSERT INTO road_reports (report_id, title, description, issue_type, priority, status, division, district, upazila, location, detailed_location, latitude, longitude, reporter_name, reporter_email, reporter_phone, estimated_cost, actual_cost, assigned_crew_id, reviewed_by, approved_at, started_at, completed_at, admin_notes, created_at, updated_at) VALUES 
('RPT-2024-001', 'Severe pothole on Dhaka-Chittagong Highway', 'Large pothole causing traffic jam and vehicle damage near Comilla bypass. Water accumulates during rain making it dangerous for motorcycles.', 'pothole', 'high', 'in_progress', 'Dhaka', 'Comilla', 'Sadar', 'Dhaka-Chittagong Highway, KM 85', 'Near Comilla bypass, opposite to Ispahani Tea Garden', 23.4607, 91.1809, 'Sumaiya Akter Rothy', 'sumaiya.arthy@gmail.com', '01711000001', 25000.00, NULL, 1, 1, '2024-01-15 10:00:00', '2024-01-16 08:00:00', NULL, 'High priority due to highway importance. Materials ordered.', NOW(), NOW()),
('RPT-2024-002', 'Road crack on Shahbagh intersection', 'Growing crack on the road surface near Shahbagh intersection affecting traffic flow. Needs immediate attention before monsoon.', 'crack', 'medium', 'approved', 'Dhaka', 'Dhaka', 'Shahbagh', 'Shahbagh Intersection', 'Near Dhaka University main gate, towards Matsya Bhavan', 23.7379, 90.3947, 'Fatima Khatun', 'fatima@gmail.com', '01711000002', 15000.00, NULL, 1, 1, '2024-01-17 14:00:00', NULL, NULL, 'Schedule work during low traffic hours.', NOW(), NOW()),
('RPT-2024-003', 'Broken street light creating safety hazard', 'Multiple street lights broken on Agrabad Access Road creating safety concerns for night travelers and pedestrians.', 'lighting', 'high', 'pending', 'Chittagong', 'Chittagong', 'Kotwali', 'Agrabad Access Road', 'From Agrabad Commercial Area to Port connecting road', 22.3475, 91.8123, 'Mohammad Ali', 'ali@gmail.com', '01722000001', 35000.00, NULL, NULL, NULL, NULL, NULL, NULL, 'Waiting for electrical department clearance.', NOW(), NOW()),
('RPT-2024-004', 'Road debris blocking traffic in Rajshahi city', 'Construction debris and fallen tree branches blocking half of the road on Rajshahi-Natore highway causing traffic congestion.', 'debris', 'urgent', 'completed', 'Rajshahi', 'Rajshahi', 'Sadar', 'Rajshahi-Natore Highway', 'Near Rajshahi University second gate', 24.3745, 88.6042, 'Rashida Begum', 'rashida@gmail.com', '01733000001', 8000.00, 7500.00, 5, 1, '2024-01-10 09:00:00', '2024-01-11 08:00:00', '2024-01-12 16:00:00', 'Emergency clearance completed successfully.', NOW(), NOW()),
('RPT-2024-005', 'Damaged road signage on Khulna-Jessore highway', 'Important directional signs damaged by storm on Khulna-Jessore highway. Travelers getting confused about routes.', 'signage', 'medium', 'in_progress', 'Khulna', 'Khulna', 'Sadar', 'Khulna-Jessore Highway', 'Near Gallanga Bridge, 25 KM from Khulna city', 22.8456, 89.5403, 'Karim Uddin', 'karim@gmail.com', '01744000001', 20000.00, NULL, 6, 1, '2024-01-12 11:00:00', '2024-01-14 07:00:00', NULL, 'New signage design approved by highway authority.', NOW(), NOW()),
('RPT-2024-006', 'Waterlogged road in Sylhet tea garden area', 'Road becomes completely waterlogged during rain affecting tea garden workers transportation. Urgent drainage work needed.', 'other', 'high', 'approved', 'Sylhet', 'Sylhet', 'Jaintiapur', 'Tea Garden Access Road', 'Malnichhera Tea Estate main access road', 25.1697, 91.9536, 'Nasreen Akter', 'nasreen@gmail.com', '01755000001', 45000.00, NULL, 7, 1, '2024-01-17 02:00:00', NULL, NULL, 'Coordinating with tea garden management for access.', NOW(), NOW());
