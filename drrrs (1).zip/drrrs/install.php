<?php

/**
 * Database Installation Script
 * Handles database setup and initial data seeding
 */

require_once 'config.php';
require_once 'includes/database.php';

$error = '';
$success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $host = $_POST['host'] ?? 'localhost';
    $port = $_POST['port'] ?? '3306';
    $username = $_POST['username'] ?? 'root';
    $password = $_POST['password'] ?? '';
    $database = $_POST['database'] ?? 'drrs_db';

    // Test connection
    $testDb = new Database();
    // Temporarily override config for testing
    $testDb->host = $host;
    $testDb->port = $port;
    $testDb->username = $username;
    $testDb->password = $password;
    $testDb->database = $database;

    $connectionResult = $testDb->testConnection();
    if ($connectionResult) {
        // Save database config (optional - will use defaults if can't save)
        saveDatabaseConfig($host, $port, $username, $password, $database);

        // Create database
        if ($testDb->createDatabase($database)) {
            // Connect to the new database
            if ($testDb->connectToDatabase($database)) {
                // Create tables
                $tableResult = createTables($testDb);
                if ($tableResult === true) {
                    // Seed data
                    $seedResult = seedData($testDb);
                    if ($seedResult === true) {
                        $success = "Installation completed successfully! Redirecting to application...";
                        // Redirect after 2 seconds
                        echo "<script>setTimeout(function(){ window.location.href = 'index.php'; }, 2000);</script>";
                    } else {
                        $error = $seedResult; // Use the actual error message
                    }
                } else {
                    $error = $tableResult; // Use the actual error message
                }
            } else {
                $error = "Error connecting to database. Error: " . $testDb->getLastError();
            }
        } else {
            $error = "Error creating database. Error: " . $testDb->getLastError();
        }
    } else {
        $error = "Database connection failed. Please check your credentials. Error: " . $testDb->getLastError();
    }
}

/**
 * Create database tables
 */
function createTables($db)
{
    $schemaFile = __DIR__ . '/database/schema.sql';

    if (!file_exists($schemaFile)) {
        return "Schema file not found: $schemaFile";
    }

    $sql = file_get_contents($schemaFile);

    // Split the SQL file into individual statements, but be more careful about semicolons
    $statements = [];
    $currentStatement = '';
    $lines = explode("\n", $sql);

    foreach ($lines as $line) {
        $line = trim($line);

        // Skip comments and empty lines
        if (empty($line) || strpos($line, '--') === 0) {
            continue;
        }

        $currentStatement .= $line . "\n";

        // If line ends with semicolon, we have a complete statement
        if (substr($line, -1) === ';') {
            $statements[] = trim($currentStatement);
            $currentStatement = '';
        }
    }

    // Add any remaining statement
    if (!empty(trim($currentStatement))) {
        $statements[] = trim($currentStatement);
    }

    foreach ($statements as $statement) {
        if (empty($statement)) {
            continue;
        }

        if (!$db->execute($statement)) {
            $error = "Failed to execute SQL statement. Error: " . $db->getLastError();
            error_log($error);
            return $error;
        }
    }

    return true;
}

/**
 * Seed initial data - Converted from Laravel seeders
 */
function seedData($db)
{
    $seedFile = __DIR__ . '/database/seed.sql';

    if (!file_exists($seedFile)) {
        return "Seed file not found: $seedFile";
    }

    $sql = file_get_contents($seedFile);

    // Split the SQL file into individual statements, but be more careful about semicolons
    $statements = [];
    $currentStatement = '';
    $lines = explode("\n", $sql);

    foreach ($lines as $line) {
        $line = trim($line);

        // Skip comments and empty lines
        if (empty($line) || strpos($line, '--') === 0) {
            continue;
        }

        $currentStatement .= $line . "\n";

        // If line ends with semicolon, we have a complete statement
        if (substr($line, -1) === ';') {
            $statements[] = trim($currentStatement);
            $currentStatement = '';
        }
    }

    // Add any remaining statement
    if (!empty(trim($currentStatement))) {
        $statements[] = trim($currentStatement);
    }

    foreach ($statements as $statement) {
        if (empty($statement)) {
            continue;
        }

        if (!$db->execute($statement)) {
            $error = "Failed to execute seed statement. Error: " . $db->getLastError();
            error_log($error);
            return $error;
        }
    }

    return true;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DRRRS Installation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
        }
    </style>
</head>

<body class="bg-gray-50 min-h-screen">
    <div class="container mx-auto px-4 py-8">
        <div class="max-w-md mx-auto bg-white rounded-lg shadow-md p-6">
            <div class="text-center mb-6">
                <h1 class="text-2xl font-bold text-gray-900">DRRRS Installation</h1>
                <p class="text-gray-600 mt-2">Database Setup and Configuration</p>
            </div>

            <?php if ($error): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                    <?php echo $success; ?>
                </div>
            <?php else: ?>
                <form method="POST" class="space-y-4">
                    <div>
                        <label for="host" class="block text-sm font-medium text-gray-700">Database Host</label>
                        <input type="text" id="host" name="host" value="localhost" required
                            class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                    </div>

                    <div>
                        <label for="port" class="block text-sm font-medium text-gray-700">Database Port</label>
                        <input type="text" id="port" name="port" value="3306" required
                            class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                    </div>

                    <div>
                        <label for="username" class="block text-sm font-medium text-gray-700">Database Username</label>
                        <input type="text" id="username" name="username" value="root" required
                            class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                    </div>

                    <div>
                        <label for="password" class="block text-sm font-medium text-gray-700">Database Password</label>
                        <input type="password" id="password" name="password"
                            class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                    </div>

                    <div>
                        <label for="database" class="block text-sm font-medium text-gray-700">Database Name</label>
                        <input type="text" id="database" name="database" value="drrs_db" required
                            class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                    </div>

                    <button type="submit"
                        class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        Install Database
                    </button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>